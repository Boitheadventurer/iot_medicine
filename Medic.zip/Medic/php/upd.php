<?php
    include 'conn.php';

    // Get values from ESP8266
    if (isset($_POST["UserID"]) && isset($_POST["Clect"]) && isset($_POST["key_get"]) ) {

        $id     = $_POST["UserID"];     // UserID
        $meal   = $_POST["Clect"];      // Meal
        $t      = $_POST["key_get"];    // Time from keypad setting mode

        $key_get = substr($t, 0, -1) . "00";       //Substr cut '*' out and add ':'

        if ($meal == "BBF") {
            $select = "tb_data_bf";
            $tt     = "time_bf";
        } else if ($meal == "LUN") {
            $select = "tb_data_lunch";
            $tt     = "time_lunch";
        } else if ($meal == "DNR") {
            $select = "tb_data_dn";
            $tt     = "time_dn";
        } else if ($meal == "BED") {
            $select = "tb_data_bb";
            $tt     = "time_bb";
        } else {
            $select = "Err";
            $tt     = "Err";
        }
    
        $sql = "UPDATE '$select' SET '$tt' = '$key_get' WHERE '$select'.id = '$id'";

        // Show response
        if (mysqli_query($conn, $sql)) { 
            echo "\nUserID = " . $id . 
                "\nMeal = " . $meal . 
                "\nTime_setting = " . $key_get;
        } else { 
            echo "\nError: " . $sql . "<br>" . mysqli_error($conn); 
        }
    }
?>