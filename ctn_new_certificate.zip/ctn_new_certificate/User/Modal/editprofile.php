<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div id="myModalProfile" class="modal fade bd-example-modal-epf" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-epf">
            <div class="modal-content">
                <form action="../User/data/data_ajax/Uploadimg.php" method="POST" enctype="multipart/form-data">
                    <h2>กิจกรรม</h2>
                    <p>ข้อมูลโดยละเอียด</p>
                    <div class="form-group_002">
                        <?php
                        include '../../dbconnect.php';
                        $conn = new mysqli($servername, $username, $password, $dbname);
                        $sql = "SELECT * FROM tb_member where member_code = '$_SESSION[username]'";
                        $result = $conn->query($sql);
                        $row = $result->fetch_array();
                        $img  = '../profile/' . $row["member_img"]; ?>
                        <div id="image_profile">
                            <img src="<?php echo $img ?>" alt="Avatar" class="User_profli_avatar">
                        </div>
                        <label>
                            <input id="profile" class="custom-file-input streched-link" name="file" type="file" accept="image/gif, image/jpeg, image/png">
                        </label>
                        <p class="small mb-0 mt-2"><b>Note : </b> Only JPG, JPEG, PNG & GIF files are allowe to uoload</p>
                        <div class="button">
                            <input type="submit" name="submit" value="Upload" id="saveprofile">
                        </div>
                    </div>
                </form>
            </div>
            <div class="row">
                <?php if (!empty($statusMsg)) { ?>
                    <div class="alert">
                        <?php echo $statusMsg; ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</body>

</html>