<?php
header("Content-type: text/css;charset:UTF-8");
include '../data/dbconnect.php';
$sql = mysqli_query($conn, 'SELECT count(*) AS theme FROM certi_bg');
$row = mysqli_fetch_array($sql);

$theme = $row['theme'];
?>

.slide-images-theme {
    display: flex;
    width: calc(250px* <?php echo $theme ?>*2);
    animation: scrolltheme 20s linear infinite;
}

@keyframes scrolltheme {
    0% {
        transform: translateX(0);
    }

    100% {
        transform: translateX(calc(-250px* <?php echo $theme ?>));
    }
}
<?php
header("Content-type: text/css;charset:UTF-8");
include '../data/dbconnect.php';
$sql = mysqli_query($conn, 'SELECT count(*) AS license FROM certi_license_tb');
$row = mysqli_fetch_array($sql);

$license = $row['license'];
?>
.slide-images-license {
    display: flex;
    width: calc(200px* <?php echo $license ?>*2);
    animation: scrolllicense 20s linear infinite;
}

@keyframes scrolllicense {
    0% {
        transform: translateX(0);
    }

    100% {
        transform: translateX(calc(-200px* <?php echo $license ?>));
    }
}