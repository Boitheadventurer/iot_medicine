<?php
include("../../../dbconnect.php");


session_start();
$statusMsg = "";

$targetDur = "../../../profile/";


if (isset($_POST['submit'])) {
    if (!empty($_FILES["file"]["name"])) {
        $fileName = basename($_FILES["file"]["name"]);
        $targetFilePath = $targetDur . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);


        $allowTypes = array('jpg', 'png', 'jpeg', 'gif', 'pdf');
        if (in_array($fileType, $allowTypes)) {
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)) {
                $sql = mysqli_query($conn, "UPDATE tb_member SET member_img = '$fileName' WHERE member_code = '$_SESSION[username]'");
                if ($sql) {
                    $statusMsg = "The file <b>" . $fileName . "</b>has been uploaded successfully."; 
                    header("location:../../index.php");
                    ?>
                    <script>
                        $(document).ready(function() {
                            $("main").load('user.php');
                            $("a:nth-child(1)").addClass('active');
                        });
                    </script>
                <?php
                } else {
                    $statusMsg = "File upload failed, please try again.";
                    header("location:../../index.php");

                ?>
                    <script>
                        $(document).ready(function() {
                            $("main").load('user.php');
                            $("a:nth-child(1)").addClass('active');
                        });
                    </script>
                <?php
                }
            } else {
                $statusMsg = "Sorry, there was an error uploadung your file.";
                header("location:../../index.php");

                ?>
                <script>
                    $(document).ready(function() {
                        $("main").load('user.php');
                        $("a:nth-child(1)").addClass('active');
                    });
                </script>
            <?php
            }
        } else {
            $statusMsg = "Sorry, only JPG, JPEG, PNG & GIF files are allowed to upload.";
            header("location:../../index.php");
            ?>
            <script>
                $(document).ready(function() {
                    $("main").load('user.php');
                    $("a:nth-child(1)").addClass('active');
                });
            </script>
        <?php
        }
    } else {
        $statusMsg = "Please select a file to upload.";
        header("location:../../index.php");

        ?>
        <script>
            $(document).ready(function() {
                $("main").load('user.php');
                $("a:nth-child(1)").addClass('active');
            });
        </script>
<?php
    }
}
