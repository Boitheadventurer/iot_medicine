<?php
include '../../dbconnect.php';
$count = 0;
if (isset($_POST["submit_file"])) {
    $file = $_FILES["file"]["tmp_name"];
    $file_open = fopen($file, "r");
    $member_code = $_POST['member_code'];
    while (($csv = fgetcsv($file_open, 1000, ",")) !== false) {
        $score0 = $csv[0];
        $score1 = $csv[1];
        $score2 = $csv[2];
        $score3 = $csv[3];
        $score4 = $csv[4];
    }
    echo $score0;
    echo $score1;
    echo $score2;
    echo $score3;
    echo $score4;
    $sql = "INSERT INTO `score_data_tb` (`id`, `member_code`, `1_score`, `2_score`, `3_score`, `4_score`, `5_score`, `average_rating`, `ac_status`, `id_certificate`) VALUES (NULL, '', '', '$score0', '$score1', '$score2', '$score3', '$score4', '0', '$member_code')";
    if ($conn->query($sql) == TRUE) { ?>
        <script>
            window.location.href = "http://localhost/web_certificate/Admin/index.php";
            $(document).ready(function() {
                $("main").load('user.php');
                $("a:nth-child(1)").addClass('active');
            });
        </script>
    <?php
    } else {
    ?>
        <script>
            window.location.href = "http://localhost/web_certificate/Admin/index.php";
            $(document).ready(function() {
                $("main").load('user.php');
                $("a:nth-child(1)").addClass('active');
            });
        </script>
<?php
    }
}
