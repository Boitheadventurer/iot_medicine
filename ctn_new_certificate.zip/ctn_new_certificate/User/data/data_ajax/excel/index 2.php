<?php include('../dbconnect.php'); ?>
<form class="" action="" method="post" enctype="multipart/form-data">
    <input type="file" name="excel" required value="">
    <button type="submit" name="import">imp</button>
</form>
<form>


    <table>
        <thead>
            <tr>
                <td>
                    test1
                </td>
                <td>
                    test2
                </td>
                <td>
                    3
                </td>
            </tr>

        </thead>
        <tbody>
            <tr>
                <!-- <td></td>
                <?php
                $i = 1;
                $rows = mysqli_query($conn, "SELECT * FROM test ");
                foreach ($rows as $row) :

                ?>
            <tr>

                <td><?php echo $row['test1'];  ?></td>
                <td><?php echo $row['test2']; ?></td>
                <td><?php echo $row['test3'];  ?></td>
                <td>
                    แก้ไข
                </td>
            </tr><?php endforeach; ?> -->
        </td>
        </tr>

        </tbody>
    </table>
</form>
<?php
if (isset($_POST['import'])) {
    $fileName = $_FILES['excel']['name'];
    $fileExtension = explode('.', $fileName);
    $fileExtension = strtolower(end($fileExtension));
    $newFileName = date("Y.m.d") . "-" . date("h.i.sa") . "." . $fileExtension;
    $target = "upload/" . $newFileName;
    move_uploaded_file($_FILES['excel']['tmp_name'], $target);
    error_reporting(0);
    ini_set('displayer_errors', 0);
    require "excelReader/excel_reader2.php";
    require "excelReader/SpreadsheetReader.php";
    $reader = new SpreadsheetReader($target);
    foreach ($reader as $key => $row) {
        $test1 = $row[0];
        $test2 = $row[1];
        $test3 = $row[2];
        $test4 = $row[3];
        echo $test1;
        echo $test2;
        echo $test3;
        echo $test4;
        $sql =  mysqli_query($connect, "INSERT INTO grade values ('0','$test1','$test2','$test3','$test4','1')");
        if ($sql) {
            echo 'success';
        }
    }
}

?>