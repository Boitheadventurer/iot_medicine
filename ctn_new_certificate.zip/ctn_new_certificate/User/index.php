<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: signin.php');
    exit();
}

if (isset($_SESSION['user_login'])) {
    $member_id = $_SESSION['user_login'];
    $code = $_SESSION['code'];
    $stmt = $conn->prepare("SELECT * FROM tb_member WHERE member_id = :member_id");
    $stmt->bindParam(':member_id', $member_id, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../image/CTN.png">
    <title>หน้าหลัก</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
        body {
            background-color: #e0e0e0;
        }

        *{
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        ::selection {
            color: #ffffff;
            background: #2A47D7;
        }


        .container {
            max-width: 1000px;
            width: 90%;
        }
        
    </style>
</head>

<body>
    <div class="container bg-light border rounded shadow mt-5 p-4">
        <h3>
            <?php echo "ยินดีต้อนรับกลับ!"; ?>
            <a href="../logout.php" type="button" class="logout float-right btn btn-danger mb-2"> ออกจากระบบ <i class="ri-door-open-line"></i> </a>
        </h3>
        <h6>
            <?php echo $row["member_title"] . " " . $row["member_firstname"] . " " .  $row["member_lastname"] . " รหัสประจำตัว " . $row["member_code"];?>
        </h6>
        <table class="table table-bordered table-hover rounded text-center">
            <thead class="thead-light">
                <tr>
                    <th>รหัส</th>
                    <th class="w-75">หัวข้อเกียร์ติบัตร</th>
                    <th>เช็คเกียร์ติบัตร</th>
                </tr>
            </thead>
            <tbody id="educationData">
                <?php
                // Query to get data from certi_license_tb2 table
                $stmt = $conn->query("SELECT * FROM certi_license_tb2");
                while ($r2 = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                    <tr>
                        <td><?php echo $r2['certi_id']; ?></td>
                        <td><?php echo $r2['textnature']; ?></td>
                        <td><a class="btn btn-info" href="certi_user.php?<?php echo $r2['certi_id']; ?>"> ดูผล <i class="ri-search-2-line"></i> </a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <table class="table table-bordered table-hover rounded text-center mt-3">
            <thead class="thead-light">
                <tr>
                    <th class="col-1">ลำดับที่</th>
                    <th class="col-3">เทอม</th>
                    <th class="col-3">ปีการศึกษา</th>
                    <th class="col-3">เกียร์ติบัตร</th>
                </tr>
            </thead>
            <tbody id="educationData">
                <?php
                // Query to get data from tb_search and tb_search2 tables
                $result = $conn->query("SELECT * FROM tb_search 
                                        INNER JOIN tb_search2 ON tb_search.search_id = tb_search2.search_id");

                    $row = $result->fetch(PDO::FETCH_ASSOC);
                    $year = $row["search_year"];
                    $term = $row["search_term"];
                    $group = $row["search2_group"];
                    $rank = $row["search2_rank"];
                    $type = $row["search2_type"];

                    // Query to get data from tb_member, tb_grade, and tb_student_level tables
                    $stmt = $conn->prepare("SELECT * FROM tb_member
                                            LEFT JOIN tb_grade ON tb_member.member_id = tb_grade.member_id
                                            LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                                            WHERE tb_member.member_id = '$member_id'");
                    $stmt->execute();

                    while ($grade_row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                        <tr>
                            <td><?php echo $grade_row['member_id']; ?></td>
                            <td><?php echo $grade_row['grade_term']; ?></td>
                            <td><?php echo $year; ?></td>
                            <td><?php echo $grade_row['grade_grade']; ?></td>
                        </tr>
                    <?php }
                    ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
