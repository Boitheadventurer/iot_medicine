$(document).ready(function () {
    $(document).on('click', 'a[data-role=deleteprojectmodal]', function () {
        var id = $(this).data('id');
        var detail = $('#' + id).children('td[data-target=detail]').text();
        var datestart = $('#' + id).children('td[data-target=datestart]').text();
        var dateend = $('#' + id).children('td[data-target=dateend]').text();


        $('#Ddetail').val(detail);
        $('#Ddatestart').val(datestart);
        $('#Ddateend').val(dateend);
        $('#Did').val(id);
    });
    $('#deleteproject').click(function () {
        var id = $('#Did').val();
        $.ajax({
            url: 'data/data_ajax/delete.php',
            method: 'post',
            data:
            {
                id: id,
            },

            success: function (response) {
                $('#' + id).closest('li').remove();
                $('#myModalDelete').modal('hide');
            }
        });
    });
});