var _URL = window.URL || window.webkitURL;
$("#profile").change(function (e) {
    var image, file;
    if ((file = this.files[0])) {
        image = new Image();
        image.onload = function () {
            src = this.src;
            $('#image_profile').html('<img src="' + src + '">');
            e.preventDefault();
        }
    };
    image.src = _URL.createObjectURL(file);
});