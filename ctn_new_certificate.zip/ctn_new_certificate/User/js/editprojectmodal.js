$(document).ready(function () {
    $(document).on('click', 'a[data-role=editprojectmodal]', function () {
        var id = $(this).data('id');
        var detail = $('#' + id).children('div[data-target=detail]').text();
        var datestart = $('#' + id).children('div[data-target=datestart]').text();
        var dateend = $('#' + id).children('div[data-target=dateend]').text();


        $('#Edetail').val(detail);
        $('#Edatestart').val(datestart);
        $('#Edateend').val(dateend);
        $('#Eid').val(id);
    });
    $('#saveproject').click(function () {
        var id = $('#Eid').val();
        var detail = $('#Edetail').val();
        var datestart = $('#Edatestart').val();
        var dateend = $('#Edateend').val();
        $.ajax({
            url: 'data/data_ajax/saveproject.php',
            method: 'post',
            data:
            {
                id: id,
                detail: detail,
                datestart: datestart,
                dateend: dateend,
            },
            success: function (response) {
                $('#' + id).children('div[data-target=detail]').text(detail);
                $('#' + id).children('div[data-target=dateend]').text(dateend);
                $('#' + id).children('div[data-target=datestart]').text(datestart);
                $('#myModalSave').modal('hide');
            }
        });
    });
});