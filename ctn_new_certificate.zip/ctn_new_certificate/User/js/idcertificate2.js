var _URL = window.URL || window.webkitURL;

$("#theme").change(function (e) {
    var image, file;
    if ((file = this.files[0])) {
        image = new Image();
        image.onload = function () {
            src = this.src;
            $('#background').html('<img src="' + src + '">');
            e.preventDefault();
        }
    };
    image.src = _URL.createObjectURL(file);
});



$("#logo1").change(function (e) {
    var image, file;
    if ((file = this.files[0])) {
        image = new Image();
        image.onload = function () {
            src = this.src;
            $('#Logo1').html('<img src="' + src + '">');
            $('#Logo1').css("padding", "0 5px");
            e.preventDefault();
        }
    };
    image.src = _URL.createObjectURL(file);
});

$("#logo2").change(function (e) {
    var image, file;
    if ((file = this.files[0])) {
        image = new Image();
        image.onload = function () {
            src = this.src;
            $('#Logo2').html('<img src="' + src + '">');
            $('#Logo2').css("padding", "0 5px");
            e.preventDefault();
        }
    };
    image.src = _URL.createObjectURL(file);
});





$("#signature_image_1").change(function (e) {
    var image, file;
    if ((file = this.files[0])) {
        image = new Image();
        image.onload = function () {
            src = this.src;
            $('#image_signature_1').html('<img id="image_1" src="' + src + '">');
            $('#image_1').css("margin", "0 6rem");
            e.preventDefault();
        }
    };
    image.src = _URL.createObjectURL(file);
});
let text_signature_1 = () => {
    document.getElementById('text_signature_1').innerHTML = document.getElementById('signature_1').value
}
let text_signature_po1 = () => {
    document.getElementById('text_signature_po1').innerHTML = document.getElementById('signature_po1').value
}
$("#signature_image_2").change(function (e) {
    var image, file;
    if ((file = this.files[0])) {
        image = new Image();
        image.onload = function () {
            src = this.src;
            $('#image_signature_2').html('<img id="image_2" src="' + src + '">');
            $('#image_2').css("margin", "0 6rem");
            e.preventDefault();
        }
    };
    image.src = _URL.createObjectURL(file);
});
let text_signature_2 = () => {
    document.getElementById('text_signature_2').innerHTML = document.getElementById('signature_2').value
}
let text_signature_po2 = () => {
    document.getElementById('text_signature_po2').innerHTML = document.getElementById('signature_po2').value
}
$("#signature_image_3").change(function (e) {
    var image, file;
    if ((file = this.files[0])) {
        image = new Image();
        image.onload = function () {
            src = this.src;
            $('#image_signature_3').html('<img id="image_3" src="' + src + '">');
            $('#image_3').css("margin", "0 6rem");
            e.preventDefault();
        }
    };
    image.src = _URL.createObjectURL(file);
});
let text_signature_3 = () => {
    document.getElementById('text_signature_3').innerHTML = document.getElementById('signature_3').value
}
let text_signature_po3 = () => {
    document.getElementById('text_signature_po3').innerHTML = document.getElementById('signature_po3').value
}




let preview1 = () => {
    document.getElementById('preview1').innerHTML = document.getElementById('text1').value
}
let previewname_MR = () => {
    document.getElementById('previewname_MR').innerHTML = document.getElementById('textname_MR').value
}
let previewname_f = () => {
    document.getElementById('previewname_f').innerHTML = document.getElementById('textname_f').value
}
let previewname_l = () => {
    document.getElementById('previewname_l').innerHTML = document.getElementById('textname_l').value
}
let previewterm = () => {
    document.getElementById('previewterm').innerHTML = document.getElementById('textterm').value
}
let previewyear = () => {
    document.getElementById('previewyear').innerHTML = document.getElementById('textyear').value
}
let previewnature = () => {
    document.getElementById('previewnature').innerHTML = document.getElementById('textnature').value
}
let previewD = () => {
    document.getElementById('previewD').innerHTML = document.getElementById('textD').value
}
let previewM = () => {
    document.getElementById('previewM').innerHTML = document.getElementById('textM').value
}
let previewY = () => {
    document.getElementById('previewY').innerHTML = document.getElementById('textY').value
}


$(document).ready(function () {
    document.getElementById('preview1').innerHTML = document.getElementById('text1').value
    document.getElementById('previewname_MR').innerHTML = document.getElementById('textname_MR').value
    document.getElementById('previewname_f').innerHTML = document.getElementById('textname_f').value
    document.getElementById('previewname_l').innerHTML = document.getElementById('textname_l').value
    document.getElementById('previewterm').innerHTML = document.getElementById('textterm').value
    document.getElementById('previewyear').innerHTML = document.getElementById('textyear').value
    document.getElementById('previewnature').innerHTML = document.getElementById('textnature').value
    document.getElementById('previewD').innerHTML = document.getElementById('textD').value
    document.getElementById('previewM').innerHTML = document.getElementById('textM').value
    document.getElementById('previewY').innerHTML = document.getElementById('textY').value
    document.getElementById('text_signature_3').innerHTML = document.getElementById('signature_3').value
    document.getElementById('text_signature_2').innerHTML = document.getElementById('signature_2').value
    document.getElementById('text_signature_1').innerHTML = document.getElementById('signature_1').value
    document.getElementById('text_signature_po3').innerHTML = document.getElementById('signature_po3').value
    document.getElementById('text_signature_po2').innerHTML = document.getElementById('signature_po2').value
    document.getElementById('text_signature_po1').innerHTML = document.getElementById('signature_po1').value
});


$('#reTheme').on('click', function (Upload) {
    var reTheme = $(this).data('id');
    var id = $(this).data('target');

    $.ajax({
        url: 'data/data_ajax/idcertificateupload_upvalue.php',
        method: 'post',
        data:
        {
            reTheme: reTheme,
            id: id
        },
        success: function (response) {
            location.reload(true);
        }
    });
});

$('#reLogo1').on('click', function (Upload) {
    var reLogo1 = $(this).data('id');
    var id = $(this).data('target');

    $.ajax({
        url: 'data/data_ajax/idcertificateupload_upvalue.php',
        method: 'post',
        data:
        {
            reLogo1: reLogo1,
            id: id
        },
        success: function (response) {
            location.reload(true);
        }
    });
});
$('#reLogo2').on('click', function (Upload) {
    var reLogo2 = $(this).data('id');
    var id = $(this).data('target');

    $.ajax({
        url: 'data/data_ajax/idcertificateupload_upvalue.php',
        method: 'post',
        data:
        {
            reLogo2: reLogo2,
            id: id
        },
        success: function (response) {
            location.reload(true);
        }
    });
});
$('#resignature_image_1').on('click', function (Upload) {
    var resignature_image_1 = $(this).data('id');
    var id = $(this).data('target');

    $.ajax({
        url: 'data/data_ajax/idcertificateupload_upvalue.php',
        method: 'post',
        data:
        {
            resignature_image_1: resignature_image_1,
            id: id
        },
        success: function (response) {
            location.reload(true);
        }
    });
});
$('#resignature_image_2').on('click', function (Upload) {
    var resignature_image_2 = $(this).data('id');
    var id = $(this).data('target');

    $.ajax({
        url: 'data/data_ajax/idcertificateupload_upvalue.php',
        method: 'post',
        data:
        {
            resignature_image_2: resignature_image_2,
            id: id
        },
        success: function (response) {
            location.reload(true);
        }
    });
});
$('#resignature_image_3').on('click', function (Upload) {
    var resignature_image_3 = $(this).data('id');
    var id = $(this).data('target');

    $.ajax({
        url: 'data/data_ajax/idcertificateupload_upvalue.php',
        method: 'post',
        data:
        {
            resignature_image_3: resignature_image_3,
            id: id
        },
        success: function (response) {
            location.reload(true);
        }
    });
});