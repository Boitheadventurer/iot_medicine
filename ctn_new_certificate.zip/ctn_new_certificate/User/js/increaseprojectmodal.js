$(document).ready(function () {
    $('#increaseproject').on('click', function () {
        var detail = $('#Idetail').val();
        var datestart = $('#Idatestart').val();
        var dateend = $('#Idateend').val();
        $.ajax({
            url: 'data/data_ajax/increase.php',
            method: 'post',
            data:
            {
                detail: detail,
                datestart: datestart,
                dateend: dateend
            },
            success: function (response) {
                $("main").load('project.php');
                $('#Idetail').val('').attr('value', '');
                $('#Idatestart').val('').attr('value', '');
                $('#Idateend').val('').attr('value', '');
                $('#myModalIncrease').modal('hide');
            }
        });

    });
});