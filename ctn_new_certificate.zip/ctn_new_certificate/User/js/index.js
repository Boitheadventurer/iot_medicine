$(document).ready(function () {
    $('span:nth-child(1)').click(function () {
        $('span:nth-child(1)').addClass('active');
        $('span:nth-child(2)').removeClass('active');
        $('html').removeClass('dark-theme-variables');
    });

    $('span:nth-child(2)').click(function () {
        $('span:nth-child(1)').removeClass('active');
        $('span:nth-child(2)').addClass('active');
        $('html').addClass('dark-theme-variables');

    });
});

$(document).ready(function () {
    $('#menu-btn').click(function () {
        $('aside').addClass('active');
    });

    $('#close-btn').click(function () {
        $('aside').removeClass('active');

    });
});

$(document).ready(function () {
    $(".menmu").click(function () {
        $($("main").load($(this).attr("href")));
        $("a").removeClass();
        $(this).addClass('active');
        return false;
    });
});


function updateTime() {
    var currentTime = new Date(),
        hours = currentTime.getHours(),
        minutes = currentTime.getMinutes(),
        seconds = currentTime.getSeconds();
  
    // Pad with leading zeros if needed
    if (hours < 10) {
      hours = '0' + hours;
    }
    if (minutes < 10) {
      minutes = '0' + minutes;
    }
    if (seconds < 10) {
      seconds = '0' + seconds;
    }
  
    // Update the clock with the new time
    $('#date').text(hours + ':' + minutes + ':' + seconds);
  }
  
  // Update the clock every second
  setInterval(updateTime, 100);