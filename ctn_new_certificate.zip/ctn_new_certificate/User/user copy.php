<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>


<body>
    <h1>COMPUTER TECHNIQUE</h1>
    <h3>User</h3>

    <div class="date" id="date"></div>
    <div class="User_insights">
        <div class="User_sales">
            <div class="User_middle">
                <?php
                session_start();
                include '../dbconnect.php';

                $session = $_SESSION['username'];
                $conn = new mysqli($servername, $username, $password, $dbname);
                $sql = "SELECT * 
                        FROM tb_member 
                        LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id 
                        where member_code = '$session'";
                $result = $conn->query($sql);
                $row = $result->fetch_array(); ?>
                <h2>โปรไฟล์</h2>
                <div class="User_profli">
                    <img src="../profile/<?php echo $row['member_img'] ?>" alt="Avatar" class="User_profli_avatar">
                </div>
                <a type="button" class="button" data-toggle="modal" data-target=".bd-example-modal-epf" data-role='editprofile' data-id="">แก้ไขโปรไฟล์</a>
                <div class="User_text">
                    <div class="user_text_mini">
                        <p>ชื่อ:</p>
                        <p><?php echo $row['member_title']; ?> <?php echo $row['member_firstname']; ?> <?php echo $row['member_lastname']; ?> </p>
                    </div>
                    <div class="user_text_mini">
                        <p>รหัส:</p>
                        <p><?php echo $row['member_code']; ?></p>
                    </div>
                    <div class="user_text_mini">
                        <p>ชั้นปี:</p>
                        <p><?php echo $row['student_num'] ?> / <?php echo $row['student_group'] ?></p>
                    </div>
                    <div class="user_text_mini">
                        <p>สถานะ:</p>
                        <p><?php echo $row['member_type'] ?></p>
                    </div>

                </div>
            </div>
        </div>
        <div class="User_sales">


        </div>
    </div>
    <div class="table-e">
        <h2>เกียรติบัตรโครงการเชิดชูเกียรติ</h2>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">ID</div>
                <div class="col col-2">ชื่อกิจกรรม</div>
                <div class="col col-4">print</div>
            </li>
            <ul class="overflow">
                <?php $acc = mysqli_query($conn, "SELECT tb_member.member_id,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_all_activities.acc_id,tb_all_activities.member_id,tb_all_activities.acc_1 + tb_all_activities.acc_2 + tb_all_activities.acc_3 AS  sum_acc,tb_all_activities.acc_term,tb_all_activities.acc_year,tb_student_level.member_id,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
    FROM tb_all_activities
    LEFT JOIN tb_member
    ON tb_member.member_id = tb_all_activities.member_id
    LEFT JOIN tb_student_level
    ON tb_member.member_id = tb_student_level.member_id
               where tb_member.member_code = '$_SESSION[username]'");
                while ($accrow = mysqli_fetch_array($acc)) {
                    $member_id = "$_SESSION[username]";
                    if ($accrow['sum_acc'] >= 3) { ?>
                        <li class="table-row">
                            <div class="col col-1">CTN01</div>
                            <div class="col col-2">โครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อภาคเรียน <?php echo $accrow['acc_term'] ?>/<?php echo $accrow['acc_year'] ?></div>
                            <div class="col col-4"><a type="button" class="button" href="idcertificate2.php?id=1&member_id=<?php echo $member_id ?>&acc_term=<?php echo $accrow['acc_term'] ?>&acc_year=<?php echo $accrow['acc_year'] ?>">Print</a></div>
                        </li>
                    <?php } else { ?>
                        <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                            <div class="col col-1">CTN01</div>
                            <div class="col col-2">โครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อภาคเรียน <?php echo $accrow['acc_term'] ?>/<?php echo $accrow['acc_year'] ?></div>
                            <div class="col col-4"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                        </li>
                    <?php } ?>
                <?php } ?>




                <?php $grade = mysqli_query($conn, "SELECT * FROM tb_member left join tb_grade on tb_member.member_id = tb_grade.member_id right join tb_student_level on tb_grade.member_id = tb_student_level.member_id where tb_member.member_code = '$_SESSION[username]'");
                while ($grade_grade = mysqli_fetch_array($grade)) {

                    if ($grade_grade['grade_grade'] >= 3.00) { ?>
                        <li class="table-row">
                            <div class="col col-1">CTN02</div>
                            <div class="col col-2">โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อภาคเรียน <?php echo $grade_grade['grade_term'] ?>/<?php echo $grade_grade['grade_year'] ?></div>
                            <div class="col col-4"><a type="button" class="button" href="idcertificate3.php?id=2&grade_term=<?php echo $grade_grade['grade_term'] ?>&grade_year=<?php echo $grade_grade['grade_year'] ?>&grade=<?php echo $grade_grade['grade_grade'] ?>">Print</a></div>
                        </li>
                    <?php } else { ?>
                        <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                            <div class="col col-1">CTN02</div>
                            <div class="col col-2">โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อภาคเรียน <?php echo $grade_grade['grade_term'] ?>/<?php echo $grade_grade['grade_year'] ?></div>
                            <div class="col col-4"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                        </li>
                    <?php } ?>
                <?php } ?>




                <?php $acc2 = mysqli_query($conn, "SELECT tb_member.member_id,tb_member.member_title,tb_member.member_firstname,tb_member.member_code,tb_member.member_lastname,tb_all_activities.acc_id,SUM(acc_1+acc_2+acc_3) AS sum_acc,tb_all_activities.acc_year,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year FROM tb_all_activities LEFT JOIN tb_member ON tb_member.member_id = tb_all_activities.member_id LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                WHERE tb_member.member_code = '$_SESSION[username]' GROUP BY tb_member.member_id;");
                $accrow2 = mysqli_fetch_array($acc2);
                if ($accrow2['sum_acc'] >= "16") { ?>
                    <li class="table-row">
                        <div class="col col-1">CTN03</div>
                        <div class="col col-2">โครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อปี</div>
                        <div class="col col-4"><a type="button" class="button" href="idcertificate4.php?id=3">Print</a></div>
                    </li>
                <?php } else { ?>
                    <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                        <div class="col col-1">CTN03</div>
                        <div class="col col-2">โครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อปี</div>
                        <div class="col col-4"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                    </li>
                <?php } ?>


                <?php $grade2 = mysqli_query($conn, "SELECT SUM(grade_grade)/6 AS grade FROM tb_member left join tb_grade on tb_member.member_id = tb_grade.member_id right join tb_student_level on tb_grade.member_id = tb_student_level.member_id where tb_member.member_code = '$_SESSION[username]' GROUP BY tb_member.member_id");
                $grade_grade2 = mysqli_fetch_array($grade2);
                if ($grade_grade2['grade'] >= 3.00) { ?>
                    <li class="table-row">
                        <div class="col col-1">CTN04</div>
                        <div class="col col-2">โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อปี</div>
                        <div class="col col-4"><a type="button" class="button" href="idcertificate5.php?id=4">Print</a></div>
                    </li>
                <?php } else { ?>
                    <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                        <div class="col col-1">CTN04</div>
                        <div class="col col-2">โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อปี</div>
                        <div class="col col-4"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                    </li>
                <?php } ?>

            </ul>
        </ul>
    </div>

    <div class="table-e">
        <h2>เกียรติบัตรโครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อภาคเรียน</h2>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">ID</div>
                <div class="col col-2">ชื่อกิจกรรม</div>
                <div class="col col-4">print</div>
            </li>
            <ul class="overflow">
                <?php $acc = mysqli_query($conn, "SELECT tb_member.member_id,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_all_activities.acc_id,tb_all_activities.member_id,tb_all_activities.acc_1 + tb_all_activities.acc_2 + tb_all_activities.acc_3 AS  sum_acc,tb_all_activities.acc_term,tb_all_activities.acc_year,tb_student_level.member_id,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
    FROM tb_all_activities
    LEFT JOIN tb_member
    ON tb_member.member_id = tb_all_activities.member_id
    LEFT JOIN tb_student_level
    ON tb_member.member_id = tb_student_level.member_id
               where tb_member.member_code = '$_SESSION[username]'");
                while ($accrow = mysqli_fetch_array($acc)) {
                    $member_id = "$_SESSION[username]";
                    if ($accrow['sum_acc'] >= 3) { ?>
                        <li class="table-row">
                            <div class="col col-1">CTN01</div>
                            <div class="col col-2">โครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อภาคเรียน <?php echo $accrow['acc_term'] ?>/<?php echo $accrow['acc_year'] ?></div>
                            <div class="col col-4"><a type="button" class="button" href="idcertificate2.php?id=1&member_id=<?php echo $member_id ?>&acc_term=<?php echo $accrow['acc_term'] ?>&acc_year=<?php echo $accrow['acc_year'] ?>">Print</a></div>
                        </li>
                    <?php } else { ?>
                        <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                            <div class="col col-1">CTN01</div>
                            <div class="col col-2">โครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อภาคเรียน <?php echo $accrow['acc_term'] ?>/<?php echo $accrow['acc_year'] ?></div>
                            <div class="col col-4"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                        </li>
                    <?php } ?>
                <?php } ?>
            </ul>
        </ul>
    </div>

    <div class="table-e">
        <h2>เกียรติบัตรโครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อปี</h2>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">ID</div>
                <div class="col col-2">ชื่อกิจกรรม</div>
                <div class="col col-4">print</div>
            </li>
            <ul class="overflow">
                <?php $acc2 = mysqli_query($conn, "SELECT tb_member.member_id,tb_member.member_title,tb_member.member_firstname,tb_member.member_code,tb_member.member_lastname,tb_all_activities.acc_id,SUM(acc_1+acc_2+acc_3) AS sum_acc,tb_all_activities.acc_year,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year FROM tb_all_activities LEFT JOIN tb_member ON tb_member.member_id = tb_all_activities.member_id LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                WHERE tb_member.member_code = '$_SESSION[username]' GROUP BY tb_member.member_id;");
                $accrow2 = mysqli_fetch_array($acc2);
                if ($accrow2['sum_acc'] >= "16") { ?>
                    <li class="table-row">
                        <div class="col col-1">CTN03</div>
                        <div class="col col-2">โครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อปี</div>
                        <div class="col col-4"><a type="button" class="button" href="idcertificate4.php?id=3">Print</a></div>
                    </li>
                <?php } else { ?>
                    <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                        <div class="col col-1">CTN03</div>
                        <div class="col col-2">โครงการเชิดชูเกียรติผู้มีความประพฤติดีต่อปี</div>
                        <div class="col col-4"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                    </li>
                <?php } ?>
            </ul>
        </ul>
    </div>

    <div class="table-e">
        <h2>เกียรติบัตรโครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อภาคเรียน</h2>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">ID</div>
                <div class="col col-2">ชื่อกิจกรรม</div>
                <div class="col col-4">print</div>
            </li>
            <ul class="overflow">
                <?php $grade = mysqli_query($conn, "SELECT * FROM tb_member left join tb_grade on tb_member.member_id = tb_grade.member_id right join tb_student_level on tb_grade.member_id = tb_student_level.member_id where tb_member.member_code = '$_SESSION[username]'");
                while ($grade_grade = mysqli_fetch_array($grade)) {

                    if ($grade_grade['grade_grade'] >= 3.00) { ?>
                        <li class="table-row">
                            <div class="col col-1">CTN02</div>
                            <div class="col col-2">โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อภาคเรียน <?php echo $grade_grade['grade_term'] ?>/<?php echo $grade_grade['grade_year'] ?></div>
                            <div class="col col-4"><a type="button" class="button" href="idcertificate3.php?id=2&grade_term=<?php echo $grade_grade['grade_term'] ?>&grade_year=<?php echo $grade_grade['grade_year'] ?>&grade=<?php echo $grade_grade['grade_grade'] ?>">Print</a></div>
                        </li>
                    <?php } else { ?>
                        <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                            <div class="col col-1">CTN02</div>
                            <div class="col col-2">โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อภาคเรียน <?php echo $grade_grade['grade_term'] ?>/<?php echo $grade_grade['grade_year'] ?></div>
                            <div class="col col-4"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                        </li>
                    <?php } ?>
                <?php } ?>
            </ul>
        </ul>
    </div>

    <div class="table-e">
        <h2>โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อปี</h2>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">ID</div>
                <div class="col col-2">ชื่อกิจกรรม</div>
                <div class="col col-4">print</div>
            </li>
            <ul class="overflow">
                <?php $grade2 = mysqli_query($conn, "SELECT SUM(grade_grade)/6 AS grade FROM tb_member left join tb_grade on tb_member.member_id = tb_grade.member_id right join tb_student_level on tb_grade.member_id = tb_student_level.member_id where tb_member.member_code = '$_SESSION[username]' GROUP BY tb_member.member_id");
                $grade_grade2 = mysqli_fetch_array($grade2);
                if ($grade_grade2['grade'] >= 3.00) { ?>
                    <li class="table-row">
                        <div class="col col-1">CTN04</div>
                        <div class="col col-2">โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อปี</div>
                        <div class="col col-4"><a type="button" class="button" href="idcertificate5.php?id=4">Print</a></div>
                    </li>
                <?php } else { ?>
                    <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                        <div class="col col-1">CTN04</div>
                        <div class="col col-2">โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีต่อปี</div>
                        <div class="col col-4"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                    </li>
                <?php } ?>

            </ul>
        </ul>
    </div>

    <div class="table-e">
        <h2>เกียรติบัตรกิจกรรมเสริม</h2>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">ID</div>
                <div class="col col-2">ชื่อกิจกรรม</div>
                <div class="col col-3">วันที่เริ่มกิจกรรม</div>
                <div class="col col-4">วันหมดกิจกรรม</div>
                <div class="col col-8">Print</div>
            </li>
            <ul class="overflow">
                <?php
                include '../dbconnect.php';


                $table2 = mysqli_query($conn, "SELECT * FROM certi_tb INNER JOIN certi_data_tb
                 ON certi_tb.id_certificate = certi_data_tb.id_certificate
                  WHERE certi_data_tb.member_code = '$_SESSION[username]' ORDER BY certi_tb.id_certificate ASC");
                while ($table_2 = mysqli_fetch_array($table2)) { ?>
                    <?php if ($table_2['ac_status'] == "1") { ?>
                        <li class="table-row">
                            <div class="col col-1"><?php echo $table_2['id_certificate']; ?></div>
                            <div class="col col-2" data-target="detail"><?php echo $table_2['detail']; ?></div>
                            <div class="col col-3" data-target="datestart"><?php echo $table_2['datestart']; ?></div>
                            <div class="col col-4" data-target="dateend"><?php echo $table_2['dateend']; ?></div>
                            <div class="col col-8"><a type="button" class="button" href="idcertificate.php?id=<?php echo $table_2['id_certificate'] ?>">Print</a></div>
                        </li>
                    <?php } else { ?>
                        <li class="table-row" style="background: rgba(0, 0, 0, 0.05); box-shadow:none;">
                            <div class="col col-1"><?php echo $table_2['id_certificate']; ?></div>
                            <div class="col col-2" data-target="detail"><?php echo $table_2['detail']; ?></div>
                            <div class="col col-3" data-target="datestart"><?php echo $table_2['datestart']; ?></div>
                            <div class="col col-4" data-target="dateend"><?php echo $table_2['dateend']; ?></div>
                            <div class="col col-8"><a type="button" class="button" href="" style="display: none;">Print</a></div>
                        </li>
                    <?php } ?>
                <?php  } ?>
            </ul>
        </ul>
    </div>
</body>

</html>