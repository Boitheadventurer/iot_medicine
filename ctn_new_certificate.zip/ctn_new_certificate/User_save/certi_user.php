<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: signin.php');
    exit();
}

if (isset($_SESSION['user_login'])) {
    $member_id = $_SESSION['user_login'];
    $stmt = $conn->prepare("SELECT * FROM tb_member WHERE member_id = :member_id");
    $stmt->bindParam(':member_id', $member_id, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}



$stmt_member = $conn->prepare("SELECT * FROM tb_member
LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
WHERE tb_member.member_id = '$member_id'");
$stmt_member->execute();

 ($row2 = $stmt_member->fetch(PDO::FETCH_ASSOC));
    $mlevel = $row2["student_level"];
    /*
    echo $mlevel;
    */
    if($mlevel == "ปวส"){
        $vlevel = "4";
    }else if($mlevel == "ปวช"){
        $vlevel = "6";
    }else if($mlevel == "ปวสม6"){
        $vlevel = "6";
    }
    /*
    echo $vlevel;
    */
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../image/CTN.png">
    <title>เกียรติบัตรออนไลน์</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!--sweet alert-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!--Jquery-->

    <!-- RemixIcon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
        body {
            background-color: #e0e0e0;
        }

        *{
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        ::selection {
            color: #ffffff;
            background: #2A47D7;
        }

        .container-s {
            background-color: #ffffff;
            padding: 30px;
            width: 90%;
            max-width: 1000px;
            margin: auto;
        }
        
        .cur {
            cursor: no-drop;
        }
    </style>
</head>

<body>
    <?php if (isset($_GET['CTN01'])) { ?>
        <div class="container-s bg-light shadow border rounded mt-5">
            <a href="index.php" class="back_b btn btn-warning mb-3" type="button"> <i class="ri-arrow-left-fill"></i> ย้อนกลับ </a>
            <h4 class="mb-3">เกียรติบัตรโครงการเชิดชูเกียรติผู้มีความประพฤติดีระดับภาคเรียน </h4>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>รหัส</span>
                    <span>ชื่อกิจกรรม</span>
                    <span>ผลลัพธ์</span>
                </li>
                <?php
                $stmt_search = $conn->prepare("SELECT * FROM tb_search");
                $stmt_search->execute();

                ($row_search = $stmt_search->fetch(PDO::FETCH_ASSOC));
                $year = $row_search["search_year"];
                $term = $row_search["search_term"];

                $stmt_member = $conn->prepare("SELECT * FROM tb_member
                        LEFT JOIN tb_all_activities ON tb_member.member_id = tb_all_activities.member_id
                        LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                        WHERE tb_member.member_id = '$member_id'");
                $stmt_member->execute();

                while ($row2 = $stmt_member->fetch(PDO::FETCH_ASSOC)) {
                    $accrow = $row2["acc_1"];
                    if ($accrow >= 1) { ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>CTN01</span>
                            <span class="pr-5">โครงการเชิดชูเกียรติผู้มีความประพฤติดีระดับภาคเรียน <?php 
                                                                                        echo $row2["acc_term"];
                                                                                        echo ' / ';
                                                                                        echo $row2["acc_year"]; ?></span>
                            <a class="btn btn-primary" href="idcertificate2.php?id=2&acc_term=<?php echo $term; ?>&acc_year=<?php echo $row2["acc_year"]; ?>&grade=<?php echo $row2["acc_term"]; ?>">พิมพ์ <i class="ri-printer-fill"></i> </a>
                        </li>
                    <?php } else { ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>CTN01</span>
                            <span>โครงการเชิดชูเกียรติผู้มีความประพฤติดีระดับภาคเรียน <?php echo $row2["acc_term"];
                                                                                echo ' / ';
                                                                                echo $row2["acc_year"]; ?></span>
                            <button class="cur btn btn-secondary" disabled aria-disabled="true" href="idcertificate2.php?id=2&acc_term=<?php echo $term; ?>&acc_year=<?php echo $row2["acc_year"]; ?>&grade=<?php echo $row2["acc_term"]; ?>">ไม่ผ่านเกณฑ์ <i class="ri-close-circle-line"></i> </button>
                        </li>
                <?php } } ?>
            </ul>
        </div>
    <?php } else if (isset($_GET['CTN02'])) { ?>
        <div class="container-s mt-5">
        <a href="index.php" class="back_b btn btn-warning mb-3" type="button"> <i class="ri-arrow-left-fill"></i> ย้อนกลับ </a>
            <h4 class="mb-3">เกียรติบัตรโครงการเชิดชูเกียรติผู้มีผลการเรียนดีระดับภาคเรียน</h4>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>รหัส</span>
                    <span>ชื่อกิจกรรม</span>
                    <span>ผลลัพธ์</span>
                </li>
                <?php
                $stmt_search = $conn->prepare("SELECT * FROM tb_search");
                $stmt_search->execute();

                ($row_search = $stmt_search->fetch(PDO::FETCH_ASSOC));
                $year = $row_search["search_year"];
                $term = $row_search["search_term"];

                $stmt_member = $conn->prepare("SELECT * FROM tb_member
                        LEFT JOIN tb_grade ON tb_member.member_id = tb_grade.member_id
                        LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                        WHERE tb_member.member_id = '$member_id'");
                $stmt_member->execute();

                while ($row2 = $stmt_member->fetch(PDO::FETCH_ASSOC)) {
                    $grade = $row2["grade_grade"];
                    if ($grade >= 3.00) { ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>CTN02</span>
                            <span class="pr-5">โครงการเชิดชูเกียรติผู้มีผลการเรียนดีระดับภาคเรียน <?php 
                                                                                        echo $row2["grade_term"];
                                                                                        echo ' / ';
                                                                                        echo $row2["grade_year"]; ?></span>
                            <a class="btn btn-primary" href="idcertificate3.php?id=2&grade_term=<?php echo $term; ?>&grade_year=<?php echo $year; ?>&grade=<?php echo $grade; ?>">พิมพ์ <i class="ri-printer-fill"></i> </a>
                        </li>
                    <?php } else { ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>CTN03</span>
                            <span>โครงการเชิดชูเกียรติผู้มีผลการเรียนดีระดับภาคเรียน</span>
                            <button class="cur  btn btn-secondary" disabled aria-disabled="true">ไม่ผ่านเกณฑ์ <i class="ri-close-circle-line"></i> </button>
                        </li>
                <?php } } ?>
            </ul>
        </div>
    <?php } else if (isset($_GET['CTN03'])) { ?>
        <div class="container-s mt-5">
        <a href="index.php" class="back_b btn btn-warning mb-3" type="button"> <i class="ri-arrow-left-fill"></i> ย้อนกลับ </a>
            <h4 class="mb-3">เกียรติบัตรโครงการเชิดชูเกียรติผู้มีความประพฤติดีระดับปีการศึกษา</h4>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>รหัส</span>
                    <span>ชื่อกิจกรรม</span>
                    <span>ผลลัพธ์</span>
                </li>
                <?php
                $stmt_search = $conn->prepare("SELECT * FROM tb_search");
                $stmt_search->execute();

                ($row_search = $stmt_search->fetch(PDO::FETCH_ASSOC));
                $year = $row_search["search_year"];
                $term = $row_search["search_term"];

                $stmt_member = $conn->prepare("SELECT acc_1, count(*) AS acc_1 FROM tb_member
                        LEFT JOIN tb_all_activities ON tb_member.member_id = tb_all_activities.member_id
                        LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                        WHERE tb_member.member_id = '$member_id'
                        AND tb_all_activities.acc_1 = '1'");
                $stmt_member->execute();

                while ($row2 = $stmt_member->fetch(PDO::FETCH_ASSOC)) {
                    /*echo $row2["acc_1"];*/

                    $accrow = $row2["acc_1"];
                    if ($accrow >= $vlevel) { ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>CTN03</span>
                            <span class="pr-5">โครงการเชิดชูเกียรติผู้มีความประพฤติดีระดับปีการศึกษา</span>
                            <a class="btn btn-primary" href="idcertificate4.php?id=3">พิมพ์ <i class="ri-printer-fill"></i> </a>
                        </li>
                    <?php } else { ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>CTN03</span>
                            <span>โครงการเชิดชูเกียรติผู้มีความประพฤติดีระดับปีการศึกษา</span>
                            <button class="cur btn btn-secondary" disabled aria-disabled="true">ไม่ผ่านเกณฑ์ <i class="ri-close-circle-line"></i> </button>
                        </li>
                <?php } } ?>
            </ul>
        </div>
    <?php } else if (isset($_GET['CTN04'])) { ?>
        <div class="container-s mt-5">
        <a href="index.php" class="back_b btn btn-warning mb-3" type="button"> <i class="ri-arrow-left-fill"></i> ย้อนกลับ </a>
            <h4 class="mb-3">เกียรติบัตรโครงการเชิดชูเกียรติผู้มีผลการเรียนดีระดับปีการศึกษา</h4>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>รหัส</span>
                    <span>ชื่อกิจกรรม</span>
                    <span>ผลลัพธ์</span>
                </li>
                <?php
                $stmt_search = $conn->prepare("SELECT * FROM tb_search");
                $stmt_search->execute();

                ($row_search = $stmt_search->fetch(PDO::FETCH_ASSOC));
                $year = $row_search["search_year"];
                $term = $row_search["search_term"];

                $stmt_member = $conn->prepare("SELECT * FROM tb_member
                        LEFT JOIN tb_grade ON tb_member.member_id = tb_grade.member_id
                        LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                        WHERE tb_member.member_id = '$member_id' ORDER BY tb_grade.grade_id  DESC LIMIT 1");
                $stmt_member->execute();

                $row2 = $stmt_member->fetch(PDO::FETCH_ASSOC);
                $grade_avg = $row2["grade_sum_grade"];
                /*echo $row2["grade_sum_grade"];*/


                $stmt_member2 = $conn->prepare("SELECT grade_id, count(*) AS grade_id FROM tb_member
                LEFT JOIN tb_grade ON tb_member.member_id = tb_grade.member_id
                LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                WHERE tb_member.member_id = '$member_id'");
                $stmt_member2->execute();

                ($row2 = $stmt_member2->fetch(PDO::FETCH_ASSOC));
                // echo $row2["grade_id"];

                $gnum = $row2["grade_id"];

                if ($grade_avg >= 3.00 && $gnum >= $vlevel) { ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span>CTN02</span>
                        <span class="pr-5">โครงการเชิดชูเกียรติผู้มีผลการเรียนดีระดับปีการศึกษา</span>
                        <a class="btn btn-primary" href="idcertificate5.php?id=4">พิพม์ <i class="ri-printer-fill"></i> </a>
                    </li>
                <?php } else { ?>
                    <li class=" list-group-item d-flex justify-content-between align-items-center">
                        <span>CTN03</span>
                        <span>โครงการเชิดชูเกียรติผู้มีผลการเรียนดีระดับปีการศึกษา</span>
                        <button class="cur btn btn-secondary" disabled aria-disabled="true">ไม่ผ่านเกณฑ์ <i class="ri-close-circle-line"></i>  </button>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } else { ?>
        <div class="container mt-5 border rounded p-3 shadow">
            ไม่มีข้อมูลที่ต้องการ
        </div>
    <?php } ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>