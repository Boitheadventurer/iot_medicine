<?php
include '../db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../image/CTN.png">
    <title>จัดการข้อมูล ระดับชั้น</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!--sweet alert-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!--Jquery-->

    <!-- RemixIcon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
        body {
            background-color: #e0e0e0;
        }

        *{
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        ::selection {
            color: #ffffff;
            background: #2A47D7;
        }

        .form-container {
            background-color: #ffffff;
            display: none;
            width: 80%;
            max-width: 550px;
        }

        .form-container h2 {
            margin-bottom: 30px;
        }

        .form-group label {
            font-weight: bold;
            text-align: left;
            /* ชิดซ้าย */
        }

        .form-group {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .form-group label {
            flex: 1;
            margin-right: 10px;
        }

        .form-group input,
        .form-group select,
        .form-group .form-control-static {
            flex: 2;
            padding-left: 10px;
        }

        .container-custom {
            background-color: #ffffff;
            padding: 30px;
            width: 90%;
            max-width: 1000px;
            margin: auto;
        }

        .hero {
            width: 40%;
        }

        td {
            font-size: large;
        }

        td, td{
            min-width: 50px;
        }

        @media only screen and (max-width: 650px) {
            .back_b{
                display: none;
            }
        }
    </style>
</head>

<body>

    <?php if (isset($_GET['term'])) {
        $id = $_GET['term'];
    ?>

        <div class="container-custom shadow rounded my-5">
            <?php $headshow = $conn->query("select * from tb_search INNER JOIN tb_search2 ON tb_search.search_id = tb_search2.search_id  where tb_search.search_id = '$id'");
            $headshow->execute();
            $hs = $headshow->fetch();
            ?>
            <h5>
                <a href="index.php" class="text-primary">หน้าหลัก</a> &nbsp; / &nbsp; <a href="add_term.php" class="text-primary">ปีการศึกษา</a> &nbsp; / &nbsp; <u class="text-muted">ระดับชั้น</u>
                <a href="add_term.php" class="float-right back_b btn btn-warning" type="button"> <i class="ri-arrow-left-fill"></i> ย้อนกลับ </a>
            </h5>
            <div class="text-center mt-4">
                <h3>ข้อมูลปีการศึกษา <?php echo $hs["search_year"]; ?> ภาคเรียนที่ <?php echo  $hs["search_term"]?></h3>
                <a class="btn btn-info mb-3 mt-2" data-bs-toggle="modal" data-bs-target="#levelModal" id="send_level" type="button" href="add_level.php?level=<?php echo $id ?>&term=<?php echo $id ?>"> <i class="ri-pencil-fill"></i> เพิ่มข้อมูล</a>
            </div>
                <div class="table-responsive">
                <table class="table table-hover table-bordered text-center order">
                    <thead class="thead-light">
                        <tr>
                            <th>ระดับ</th>
                            <th>ชั้นปี</th>
                            <th>กลุ่ม</th>
                            <th class="hero">การดำเนินการ</th>
                        </tr>
                    </thead>
                    <tbody id="educationData">
                        <?php foreach ($conn->query("select * from tb_search 
                        INNER JOIN tb_search2 ON tb_search.search_id = tb_search2.search_id  where tb_search.search_id = '$id' ORDER BY tb_search2.search2_rank ,tb_search2.search2_group") as $r) { 
                            $syear = $r["search_year"];
                            $sterm = $r["search_term"];
                            $slevel = $r["search2_type"];
                            $snum = $r["search2_rank"];
                            $sgroup = $r["search2_group"];
                        ?>
                            <tr>
                                <td><?php echo $r['search2_type']; ?></td>
                                <td><?php echo $r['search2_rank']; ?></td>
                                <td><?php echo $r['search2_group']; ?></td>
                                <td>
                                <?php 
                                    $delin = " ".$slevel." ปี ".$snum ." กลุ่ม ".$sgroup;
                                ?>
                                <?php
                                    $y = $conn->query("SELECT * FROM tb_student_level ORDER BY student_year DESC LIMIT 1");
                                    $yy = $y->fetch();
                                    $ys = $yy['student_year'];
                                    $loki = $ys - $syear;
                                    $mobias = $syear + $loki;
                                    $sumnum = $r['search2_rank'];
                                    if($sumnum >= 3){
                                        $loki1 = 0;
                                    }else{
                                        $loki1 = $loki;
                                    }
                                    $check_grade = $conn->query("select * from tb_grade 
                                    left join tb_student_level on tb_student_level.member_id = tb_grade.member_id 
                                    where grade_level = '$slevel' AND grade_num = '$snum' AND grade_term = '$sterm' AND grade_year = '$syear' AND student_group = '$sgroup'");
                                    if ($check_grade->rowCount() == 0) { ?>
                                    <a class="btn btn-success" href="save-grade.php?level=<?php echo $r['search2_type']; ?>&num=<?php echo $r['search2_rank'] + $loki1; ?>&group=<?php echo $r['search2_group']; ?>&term=<?php echo $r['search_term']; ?>&year=<?php echo $r['search_year']; ?>&terms=<?php echo $id ?>&preyear=<?php echo $mobias ?>&sumnum=<?php echo $sumnum?>" role="button"> <i class="ri-file-add-fill"></i> เพิ่ม</a> 
                                    <a class="btn btn-warning edit-btn" href="add_level.php?term=<?php echo $id; ?>&levele=<?php echo $r['search2_id']; ?>" data-bs-toggle="modal" data-bs-target="#editModal" type="button" id="edit_term"> <i class="ri-edit-2-fill"></i> แก้ไข</a>
                                    <a class="btn btn-danger delete-btn" data-id="<?php echo $delin; ?>" data-id2="<?php echo $r["search2_id"];?>" type="submit"><i class="ri-delete-bin-2-fill"></i> ลบ</a>
                                <?php } else { ?>
                                    <a class="btn btn-secondary" href="edit-grade.php?level=<?php echo $r['search2_type']; ?>&num=<?php echo $r['search2_rank'] + $loki1; ?>&group=<?php echo $r['search2_group']; ?>&term=<?php echo $r['search_term']; ?>&year=<?php echo $r['search_year']; ?>&terms=<?php echo $id ?>&preyear=<?php echo $mobias ?>&sumnum=<?php echo $sumnum?>" role="button"> <i class="ri-search-2-line"></i> เพิ่มแล้ว</a>
                                    <a class="btn btn-warning edit-btn" href="add_level.php?term=<?php echo $id; ?>&levele=<?php echo $r['search2_id']; ?>" data-bs-toggle="modal" data-bs-target="#editModal" type="button" id="edit_term"> <i class="ri-edit-2-fill"></i> แก้ไข</a>
                                    <a class="btn btn-danger delete-btn" data-id="<?php echo $delin; ?>" type="submit" data-id2="<?php echo $r["search2_id"];?>" ><i class="ri-delete-bin-2-fill"></i> ลบ </a>
                                <?php } ?>
                                </td>
                            </tr>
                    </tbody>
                <?php } ?>
                </table>
                </div>
            <?php } ?>
        </div>


    <!-- Bootstrap JS and dependencies -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!----Sweet Alert Del--->
    <script>
        $('.delete-btn').click(function(e){
            var userId= $(this).data('id');
            var delid= $(this).data('id2');
            e.preventDefault();
            deleteConfirm(userId,delid);
        })

        function deleteConfirm(userId,delid){
            Swal.fire({
                title:'คุณกำลังจะลบข้อมูล',
                text:'คุณต้องการลบข้อมูล '+userId+' หรือไม่?',  /* คุณต้องการลบข้อมูล (ปวช) ชั้นปี (3) กลุ่ม (1)*/
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#E85050',
                cancelButtonText: 'ยกเลิก',
                confirmButtonText: 'ใช่ ลบเลย',
                showLoaderOnConfirm: true,
                preConfirm: function(){
                    return new Promise(function(resolve){
                        $.ajax({
                            url: 'add_level.php',
                            type: 'GET',
                            data: 'del='+ delid,
                        })
                        .done(function(){
                            Swal.fire({
                                title: 'สำเร็จ',
                                text: 'ลบข้อมูลสำเร็จ',
                                icon: 'success'
                            }).then(()=> {
                                document.location.href = 'add_level.php?term=<?php echo $id?>';
                            })
                        })
                        .fail(function(){
                            Swal.fire('เกิดข้อผิดพลาด','ไม่สามารถลบข้อมูลได้','error');
                            window.location.reload();
                        })
                }) 
                }
            });
        }
    </script>


    <?php


    if (isset($_GET['del'])) {
        $search2_id = $_GET['del'];

        $sid2 = $conn->prepare("SELECT * FROM tb_search2 
        LEFT JOIN tb_search ON tb_search.search_id = tb_search2.search_id
        WHERE search2_id = '$search2_id'");
        $sid2->execute();
        $sids2 = $sid2->fetch();
        $level = $sids2['search2_type'];
        $num = $sids2['search2_rank'];
        $group = $sids2['search2_group'];
        $year = $sids2['search_year'];
        $term = $sids2['search_term'];

        foreach ($conn->query("SELECT * FROM tb_grade
        LEFT JOIN tb_student_level ON tb_student_level.member_id = tb_grade.member_id 
        WHERE tb_grade.grade_level = '$level' AND tb_grade.grade_num = '$num' AND tb_student_level.student_group = '$group' AND tb_grade.grade_term = '$term' AND tb_grade.grade_year = '$year'") as $rg) {
        $gradest = $rg['grade_id'];
        $stmt1 = $conn->prepare("DELETE FROM tb_grade WHERE grade_id = '$gradest'");
        $stmt1->execute();
        }

        $stmt = $conn->prepare("DELETE FROM tb_search2 WHERE search2_id=:search2_id");
        $stmt->bindValue(':search2_id', $search2_id, PDO::PARAM_STR);
        $stmt->execute();
    } ?>

<?php 
    if (isset($_POST['editt'])) {
        $type = $_POST['search2_type'];
        $rank = $_POST['search2_rank'];
        $group = $_POST['search2_group'];
        $id2 = $_POST['search2_id'];
        $id1 = $_POST['search_id'];

        
        $check_rank= $conn->prepare("SELECT * FROM tb_search2 WHERE search_id = :search_id");
        $check_rank->bindParam(":search_id", $id1);
        $check_rank->execute();
        $row2 = $check_rank->fetch(PDO::FETCH_ASSOC);

        if ($row2['search2_type'] == $type && $row2['search2_rank'] == $rank && $row2['search2_group'] == $group) {
            echo "<script>
             window.stop()
            Swal.fire({
                title: 'ไม่สามารถเเก้ไขข้อมูลได้',
                text: 'มีข้อมูลดังกล่าวอยู่เเล้ว',
                icon: 'error',
                confirmButtonColor:'#3085d6',
                confirmButtonText: 'ตกลง'
            }).then(()=> {
            document.location.href = 'add_level.php?term=$id1';
        })
            </script>";
        }else{  
        $conn->exec("UPDATE tb_search2 SET search2_type='$type', search2_rank='$rank'  , search2_group='$group' WHERE search2_id = '$id2'");
        echo "<script>
            window.stop()
            Swal.fire({
                title: 'สำเร็จ',
                text: 'เเก้ไขข้อมูลสำเร็จ',
                icon: 'success',
                confirmButtonColor:'#3085d6',
                confirmButtonText: 'ตกลง',
            }).then(()=> {
            document.location.href = 'add_level.php?term=$id1';
        })
            </script>";
    }
}
?>

<?php
    if (isset($_POST['insert'])) {
        $search2_type = $_POST['search2_type'];
        $search2_rank = $_POST['search2_rank'];
        $search2_group = $_POST['search2_group'];
        $search_id = $_POST['search_id'];

        $check_term= $conn->prepare("SELECT * FROM tb_search2 WHERE search_id = :search_id AND search2_type = :search2_type AND search2_rank = :search2_rank AND search2_group = :search2_group");
        $check_term->bindParam(":search_id", $search_id);
        $check_term->bindParam(":search2_type", $search2_type);
        $check_term->bindParam(":search2_rank", $search2_rank);
        $check_term->bindParam(":search2_group", $search2_group);
        $check_term->execute();
        $row = $check_term->fetch(PDO::FETCH_ASSOC);

        if ($row['search2_type'] == $search2_type && $row['search2_rank'] == $search2_rank && $row['search2_group'] == $search2_group) {
            echo "<script>
            window.stop()
            Swal.fire({
                title: 'ไม่สามารถเพิ่มข้อมูลได้',
                text: 'มีข้อมูลดังกล่าวอยู่เเล้ว',
                icon: 'error',
                confirmButtonColor:'#3085d6',
                confirmButtonText: 'ตกลง'
            }).then(()=> {
        document.location.href = 'add_level.php?term=$id';
        })  
            </script>";
        }else{    
        $conn->exec("INSERT INTO tb_search2(search2_type,search2_rank,search2_group,search_id) 
        VALUES('$search2_type','$search2_rank','$search2_group','$search_id')");
        echo "<script>
        window.stop()
        Swal.fire({
            title: 'สำเร็จ',
            text: 'ทำการเพิ่มข้อมูลสำเร็จ',
            icon: 'success',
            confirmButtonColor:'#3085d6',
            confirmButtonText: 'ตกลง',
        }).then(()=> {
        document.location.href = 'add_level.php?term=$id';
        })  
        </script>";
        }
        }
    ?>


     <!----------------------- เเสดง Modal เพิ่มชั้นปี---------------------->
     <?php if (isset($_GET['level'])) {
        $id = $_GET['level']; ?>
        <script>
            $(function() {
                $('#levelModal').modal('show');
            });
        </script>
    <?php } ?>

    <div class="modal fade" id="levelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ฟอร์มเพิ่มข้อมูล</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php foreach ($conn->query("select * from tb_search where search_id ='$id'") as $row) { ?>
                        <h2 class="text-center mb-2">ปีการศึกษา <?php echo $row['search_year']; ?> ภาคเรียนที่ <?php echo $row['search_term']; ?> </h2>
                        <form method="post">
                            <input type="hidden" name="search_id" id="search_id" value="<?php echo $row['search_id']; ?>">
                        <?php } ?>
                        <div class="form-group">
                            <label for="level">ระดับ</label>
                            <select class="form-control" id="search2_type" name="search2_type" required>
                                <option value="">เลือกระดับ</option>
                                <option value="ปวช">ปวช.</option>
                                <option value="ปวส">ปวส.</option>
                                <option value="ปวสม6">ปวส ม.6</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="grade">ชั้นปีที่</label>
                            <select class="form-control" id="search2_rank" name="search2_rank" required>
                                <option value="">เลือกชั้นปี</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="academic_year">กลุ่ม</label>
                            <select class="form-control" id="search2_group" name="search2_group" required>
                                <option value="">เลือกกลุ่ม</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                        <button type="submit" name="insert" class="btn btn-info btn-block">ส่งข้อมูล</button>
                        <button type="button" class="btn btn-danger btn-block mt-3" data-dismiss="modal" aria-label="Close">ยกเลิก</button>
                        </form>
                </div>
            </div>
        </div>
    </div>

    <!----------------------- เเสดง Modal เเก้ไข ชั้นปี---------------------->

    <?php if (isset($_GET['levele'])) {
        $elev = $_GET['levele'];
        $ide = $_GET['term']; ?>
        <script>
            $(function() {
                $('#editModal').modal('show');
            });
        </script>
    <?php } ?>

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ฟอร์มเเก้ไขข้อมูล</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php foreach ($conn->query("select * from tb_search2 where search2_id ='$elev'") as $row) { 
                        $rank = $row['search2_rank'];
                        $type= $row['search2_type'];
                        $group =$row['search2_group'];?>
                        <h2 class="text-center mb-2"><?php echo $row['search2_type']; ?> ปี <?php echo $row['search2_rank']; ?> กลุ่ม <?php echo $row['search2_group']; ?></h2>
                        <form method="post">
                            <input type="hidden" name="search2_id" id="search2_id" value="<?php echo $row['search2_id']; ?>">
                            <input type="hidden" name="search_id" id="search_id" value="<?php echo $row['search_id']; ?>">
                        <?php } ?>
                        <div class="form-group">
                            <label for="level">ระดับ</label>
                            <select class="form-control" id="search2_type" name="search2_type">
                                <option value="ปวช" <?php if($type == 'ปวช'){echo "selected";}?> >ปวช.</option>
                                <option value="ปวส" <?php if($type =='ปวส'){echo "selected";}?> >ปวส.</option>
                                <option value="ปวสม6" <?php if($type == 'ปวสม6'){echo "selected";}?> >ปวส ม.6</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="grade">ชั้นปีที่</label>
                            <select class="form-control" id="search2_rank" name="search2_rank">
                                <option value="1" <?php if($rank == '1'){echo 'selected';}?> >1</option>
                                <option value="2" <?php if($rank == '2'){echo 'selected';}?> >2</option>
                                <option value="3" <?php if($rank == '3'){echo 'selected';}?> >3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="academic_year">กลุ่ม</label>
                            <select class="form-control" id="search2_group" name="search2_group">
                                <option value="1" <?php if($group == '1'){echo 'selected';}?>>1</option>
                                <option value="2" <?php if($group == '2'){echo 'selected';}?>>2</option>
                                <option value="3" <?php if($group == '3'){echo 'selected';}?>>3</option>
                                <option value="4" <?php if($group == '4'){echo 'selected';}?>>4</option>
                            </select>
                        </div>
                        <button type="submit" name="editt" class="btn btn-warning btn-block">บันทึกข้อมูล</button>
                        <button type="button" class="btn btn-danger btn-block mt-3" data-dismiss="modal" aria-label="Close">ยกเลิก</button>
                        </form>
                </div>
            </div>
        </div>
    </div>

</body>

</html>