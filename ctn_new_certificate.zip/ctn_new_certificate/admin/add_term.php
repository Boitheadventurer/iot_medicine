<?php
include '../db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../image/CTN.png">
    <title>จัดการข้อมูล ปีการศึกษา</title>


    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!--sweet alert-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!--Jquery-->

    <!-- RemixIcon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">

    <!--Import sweet plugin-->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
        body {
            background-color: #e0e0e0;
        }

        *{
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        ::selection {
            color: #ffffff;
            background: #2A47D7;
        }

        .form-container {
            background-color: #ffffff;
            display: none;
            width: 80%;
            max-width: 550px;
        }

        .form-group label {
            font-weight: bold;
            text-align: left;
        }

        .form-group {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .form-group label {
            flex: 1;
            margin-right: 10px;
        }

        .form-group input,
        .form-group select {
            flex: 2;
        }

        .container-custom {
            background-color: #ffffff;
            padding: 30px;
            width: 90%;
            max-width: 1000px;
            margin: auto;
        }

        .hero{
            width: 40%;
        }

        td {
            font-size: large;
        }

        td, td{
            min-width: 150px;
        }
        
        @media only screen and (max-width: 550px) {
            .back_b{
                display: none;
            }
        }
    </style>
</head>

<body>
    <!--Toggle Form-->
    <div class="container-custom border rounded shadow my-5">
            <h5>
                <a href="index.php" class="text-primary">หน้าหลัก</a> &nbsp; / &nbsp; <u class="text-muted">ปีการศึกษา</u>
                <a href="index.php" class="float-right back_b btn btn-warning" type="button"> <i class="ri-arrow-left-fill"></i> ย้อนกลับ </a>
            </h5>
            <div class="row justify-content-center mt-4">
                <div class="form-container border rounded shadow my-3 p-4" id="form-container">
                    <h2 class="text-center mb-3">ฟอร์มเก็บข้อมูลการศึกษา</h2>
                    <form method="post">
                        <div class="form-group">
                            <label for="term">ภาคเรียน</label>
                            <select class="form-control" id="search_term" name="search_term" required>
                                <option value="">เลือกภาคเรียน</option>
                                <option value="1">ภาคเรียนที่ 1</option>
                                <option value="2">ภาคเรียนที่ 2</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="academic_year">ปีการศึกษา</label>
                            <input type="text" class="form-control" id="search_year" name="search_year" placeholder="เช่น 2566" required>
                        </div>
                        <button type="submit" name="insert" class="btn btn-info btn-block">ส่งข้อมูล</button>
                        <button type="button" class="btn btn-danger btn-block mt-3" onclick="toggleForm()">ยกเลิก</button>
                    </form>
                </div>
            </div>

        <div class="text-center my-3">
            <h3>จัดการข้อมูลปีการศึกษา</h3> 
            <button class="btn btn-info mb-3 mt-2" onclick="toggleForm()"> <i class="ri-pencil-fill"></i> เพิ่มข้อมูล </button>
        </div>
        <input type="text" id="searchInput" onkeyup="searchTable()" class="form-control mb-2" placeholder="ค้นหาปีการศึกษา...">
        <div class="table-responsive">
        <table id="myTable" class="table table-bordered table-hover text-center">
            <thead class="thead-light">
                <tr>    
                    <th>ปีการศึกษา</th>
                    <th>ภาคเรียนที่</th>
                    <th class="hero">การดำเนินการ</th>
                </tr>
            </thead>
            <tbody id="educationData">
                <?php foreach ($conn->query("select * from tb_search ORDER BY search_year ASC,search_term") as $r) {    
                    $sid1 = $r["search_id"];

                    $t = $r['search_term'];
                    $y = $r['search_year'];
                ?>
                    <tr>                                         
                        <td><?php echo $r['search_year']; ?></td>
                        <td><?php echo $r['search_term']; ?></td>
                        <?php 
                            $delin = " ปีการศึกษา ".$y." เทอม ".$t;
                        ?>
                        <td>
                            <?php
                            $result2 = $conn->query("select * from tb_search2 where search_id = '$sid1'");
                            if ($result2->rowCount() == 0) { ?>
                                <a class="btn btn-success" href="add_term.php?term=<?php echo $r['search_id']; ?>" data-bs-toggle="modal" data-bs-target="#termModal" type="button" id="send_term"> <i class="ri-file-add-fill"></i> เพิ่ม</a>
                                <a class="btn btn-danger delete-btn"  data-id="<?php echo $delin; ?>" data-id2="<?php  echo $sid1; ?>" type="button"> <i class="ri-delete-bin-2-fill"></i> ลบ</a>
                            <?php } else { ?>
                                <a class="btn btn-info" href="add_level.php?term=<?php echo $r['search_id']; ?>" role="button"> <i class="ri-file-chart-fill"></i> ตรวจสอบ</a>
                                <a class="btn btn-warning edit-btn" href="add_term.php?terme=<?php echo $r['search_id']; ?>" data-bs-toggle="modal" data-bs-target="#editModal" type="button" id="edit_term"> <i class="ri-edit-2-fill"></i> เเก้ไข</a>
                                <a class="btn btn-danger delete-btn" data-id="<?php echo $delin; ?>"  data-id2="<?php  echo $sid1; ?>" type="submit"> <i class="ri-delete-bin-2-fill"></i> ลบ </a>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        </div>

        <script>
            function searchTable() {
            var input, filter, table, tr, td, i, j, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toLowerCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            for (i = 1; i < tr.length; i++) {
                tr[i].style.display = "none";
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                if (td[j]) {
                    txtValue = td[j].textContent || td[j].innerText;
                    if (txtValue.toLowerCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                    break;
                    }
                }}
            }}
        </script>
    </div>

        <!--Toggle Form-->

    <!-- Bootstrap JS and dependencies -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <!-- Custom Script -->
    <script>
        function toggleForm() {
            var formContainer = document.getElementById("form-container");
            if (formContainer.style.display === "none" || formContainer.style.display === "") {
                formContainer.style.display = "block";
            } else {
                formContainer.style.display = "none";
            }
        }
    </script>

    <!---------------------------------- C R U D สำหรับปีการศึกษา -------------------------------------->

     <!-- Sweetalert การลบข้อมูล-->
    <script>
        $('.delete-btn').click(function(e){
            var userId= $(this).data('id');
            var delid= $(this).data('id2');
            e.preventDefault();
            deleteConfirm(userId,delid);
        })

        function deleteConfirm(userId,delid){
            Swal.fire({
                title:'คุณกำลังจะลบข้อมูล',
                text:'คุณต้องการลบข้อมูล '+userId+' หรือไม่?',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#E85050',
                confirmButtonText: 'ลบข้อมูล',
                cancelButtonText: 'ยกเลิก',
                showLoaderOnConfirm: true,
                preConfirm: function(){
                    return new Promise(function(resolve){
                        $.ajax({
                            url: 'add_term.php',
                            type: 'GET',
                            data: 'del='+ delid,
                        })
                        .done(function(){
                            Swal.fire({
                                title: 'สำเร็จ',
                                text: 'ลบข้อมูลสำเร็จ',
                                icon: 'success'
                            }).then(()=> {
                                document.location.href = 'add_term.php';
                            })
                        })
                        .fail(function(){
                            Swal.fire('เกิดข้อผิดพลาด','ไม่สามารถลบข้อมูลได้','error');
                            window.location.reload();
                        })
                }) 
                }
            });
        }
    </script>

    <?php
    if (isset($_GET['del'])) {
        $search_id = $_GET['del'];

        foreach ($conn->query("SELECT * FROM tb_search2 LEFT JOIN tb_search ON tb_search.search_id = tb_search2.search_id WHERE tb_search2.search_id = '$search_id'") as $s2id) {
        $level = $s2id['search2_type'];
        $num = $s2id['search2_rank'];
        $group = $s2id['search2_group'];
        $year = $s2id['search_year'];
        $term = $s2id['search_term'];

        foreach ($conn->query("SELECT * FROM tb_grade
        LEFT JOIN tb_student_level ON tb_student_level.member_id = tb_grade.member_id 
        WHERE tb_grade.grade_level = '$level' AND tb_grade.grade_num = '$num' AND tb_student_level.student_group = '$group' AND tb_grade.grade_term = '$term' AND tb_grade.grade_year = '$year'") as $rg) {
        $gradest = $rg['grade_id'];
        $stmt1 = $conn->prepare("DELETE FROM tb_grade WHERE grade_id = '$gradest'");
        $stmt1->execute();
        }
    }

        $stmt2 = $conn->prepare("DELETE FROM tb_search2 WHERE search_id=:search_id");
        $stmt2->bindValue(':search_id', $search_id, PDO::PARAM_STR);
        $stmt2->execute();

        $stmt = $conn->prepare("DELETE FROM tb_search WHERE search_id=:search_id");
        $stmt->bindValue(':search_id', $search_id, PDO::PARAM_STR);
        $stmt->execute();
        
    }

    if (isset($_POST['insert'])) {
        $search_term = $_POST['search_term'];
        $search_year = $_POST['search_year'];

        $check_term= $conn->prepare("SELECT * FROM tb_search WHERE search_term = :search_term AND search_year = :search_year");
        $check_term->bindParam(":search_term", $search_term);
        $check_term->bindParam(":search_year", $search_year);
        $check_term->execute();
        $row = $check_term->fetch(PDO::FETCH_ASSOC);

        if ($row['search_term'] == $search_term && $row['search_year'] == $search_year) {
            echo "<script>
            Swal.fire({
                title: 'ไม่สามารถเพิ่มข้อมูลได้',
                text: 'มีข้อมูลดังกล่าวอยู่เเล้ว',
                icon: 'error',
                confirmButtonColor:'#3085d6',
                confirmButtonText: 'ตกลง'
            })
            </script>";
        }else{    
        $conn->exec("INSERT INTO tb_search(search_term,search_year) VALUES('$search_term','$search_year')");
        echo "<script>
            Swal.fire({
                title: 'สำเร็จ',
                text: 'ทำการเพิ่มข้อมูลสำเร็จ',
                icon: 'success',
                confirmButtonColor:'#3085d6',
                confirmButtonText: 'ตกลง',
            }).then(()=> {
            document.location.href = 'add_term.php';
        })
            </script>";
        }
    }

    if (isset($_POST['insert2'])) {
        $search2_type = $_POST['search2_type'];
        $search2_rank = $_POST['search2_rank'];
        $search2_group = $_POST['search2_group'];
        $search_id = $_POST['search_id'];
        $conn->exec("INSERT INTO tb_search2(search2_type,search2_rank,search2_group,search_id) VALUES('$search2_type','$search2_rank','$search2_group','$search_id')");
        echo "<script>
            window.stop()
            Swal.fire({
                title: 'สำเร็จ',
                text: 'บันทึกชั้นปีสำเร็จ',
                icon: 'success',
                confirmButtonColor:'#3085d6',
                confirmButtonText: 'ตกลง',
            }).then(()=> {
            document.location.href = 'add_level.php?term=$search_id';
        })
        </script>";
    }
    ?>

    <?php
    if (isset($_POST['editt'])) {
        $search_year = $_POST['edit_year'];
        $search_term = $_POST['edit_term'];
        $search_id = $_POST['search_id'];

        
        $check_term= $conn->prepare("SELECT * FROM tb_search WHERE search_term = :search_term AND search_year = :search_year");
        $check_term->bindParam(":search_term", $search_term);
        $check_term->bindParam(":search_year", $search_year);
        $check_term->execute();
        $row = $check_term->fetch(PDO::FETCH_ASSOC);

        if ($row['search_term'] == $search_term && $row['search_year'] == $search_year) {
            echo "<script>
             window.stop()
            Swal.fire({
                title: 'ไม่สามารถเเก้ไขข้อมูลได้',
                text: 'มีข้อมูลดังกล่าวอยู่เเล้ว',
                icon: 'error',
                confirmButtonColor:'#3085d6',
                confirmButtonText: 'ตกลง'
            }).then(()=> {
            document.location.href = 'add_term.php';
        })
            </script>";
        }else{  

        $conn->exec("UPDATE tb_search SET search_year='$search_year', search_term='$search_term' WHERE search_id = '$search_id'");
        echo "<script>
            window.stop()
            Swal.fire({
                title: 'สำเร็จ',
                text: 'เเก้ไขข้อมูลสำเร็จ',
                icon: 'success',
                confirmButtonColor:'#3085d6',
                confirmButtonText: 'ตกลง',
            }).then(()=> {
            document.location.href = 'add_term.php';
        })
            </script>";
    }
}
    ?>

    <!----------------------- เเสดง Modal Add ชั้นปี---------------------->
    <?php if (isset($_GET['term'])) {
        $id = $_GET['term']; ?>
        <script>
            $(function() {
                $('#termModal').modal('show');
            });
        </script>
    <?php } ?>

    <div class="modal fade" id="termModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ฟอร์มเพิ่มข้อมูล</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php foreach ($conn->query("select * from tb_search where search_id ='$id'") as $row) { ?>
                        <h2 class="text-center">ปีการศึกษา <?php echo $row['search_year']; ?> ภาคเรียนที่ <?php echo $row['search_term']; ?> </h2>
                        <form method="post">
                            <input type="hidden" name="search_id" id="search_id" value="<?php echo $row['search_id']; ?>">
                        <?php } ?>
                        <div class="form-group">
                            <label for="level">ระดับ</label>
                            <select class="form-control" id="search2_type" name="search2_type" required>
                                <option value="">เลือกระดับ</option>
                                <option value="ปวช">ปวช.</option>
                                <option value="ปวส">ปวส.</option>
                                <option value="ปวสม6">ปวส ม.6</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="grade">ชั้นปี</label>
                            <select class="form-control" id="search2_rank" name="search2_rank" required>
                                <option value="">เลือกชั้นปี</option>
                                <option value="1">ปีที่ 1</option>
                                <option value="2">ปีที่ 2</option>
                                <option value="3">ปีที่ 3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="academic_year">กลุ่ม</label>
                            <select class="form-control" id="search2_group" name="search2_group" required>
                                <option value="">เลือกกลุ่ม</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                        <button type="submit" name="insert2" class="btn btn-info btn-block">ส่งข้อมูล</button>
                        <button type="button" class="btn btn-danger btn-block mt-3" data-dismiss="modal" aria-label="Close">ยกเลิก</button>
                        </form>
                </div>
            </div>
        </div>
    </div>


    <!----------------------- เเสดง Modal เเก้ไข เทอม---------------------->

    <?php if (isset($_GET['terme'])) {
        $ide = $_GET['terme']; ?>
        <script>
            $(function() {
                $('#editModal').modal('show');
            });
        </script>
    <?php } ?>

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ฟอร์มเเก้ไขข้อมูล</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php foreach ($conn->query("select * from tb_search where search_id ='$ide'") as $row) { ?>
                    <h2 class="text-center mb-3">ปีการศึกษา <?php echo $row['search_year']; ?> ภาคเรียนที่ <?php echo $row['search_term']; ?> </h2>
                    <form method="post">
                        <input type="hidden" name="search_id" id="search_id" value="<?php echo $row['search_id']; ?>">
                    <?php } ?>
                    <div class="form-group">
                        <label for="level">ปีการศึกษา</label>
                        <input type="text" class="form-control" name="edit_year" value="<?php echo $row['search_year'];?>">
                    </div>
                    <div class="form-group">
                        <label for="grade">เทอม</label>
                        <input type="text" class="form-control" name="edit_term" value="<?php echo $row['search_term'];?>">
                    </div>
                    <button type="submit" name="editt" class="btn btn-warning btn-block">บันทึกการแก้ไข</button>
                    <button type="button" class="btn btn-danger btn-block mt-3" data-dismiss="modal" aria-label="Close">ยกเลิก</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>

</html>