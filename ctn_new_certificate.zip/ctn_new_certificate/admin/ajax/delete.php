<?php
include("../../conn.php");


if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $result = mysqli_query($conn, "DELETE FROM certi_tb WHERE id_certificate = '$id'");
    $resul2 = mysqli_query($conn, "DELETE FROM certi_license_tb WHERE id = '$id'");

    if ($result) {
        echo 'data delete';
    }
}
