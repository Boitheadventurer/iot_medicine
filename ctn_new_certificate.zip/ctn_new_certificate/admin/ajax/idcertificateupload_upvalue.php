<?php
include("../../dbconnect.php");




$reTheme = $_POST['reTheme'];
$reLogo1 = $_POST['reLogo1'];
$reLogo2 = $_POST['reLogo2'];
$resignature_image_1 = $_POST['resignature_image_1'];
$resignature_image_2 = $_POST['resignature_image_2'];
$resignature_image_3 = $_POST['resignature_image_3'];
$id = $_POST['id'];


if (isset($_POST['reTheme'])) {
    mysqli_query($conn, "UPDATE `certi_license_tb` SET `theme` = '' WHERE `certi_license_tb`.`id` = '$id'");
}

if (isset($_POST['reLogo1'])) {
    mysqli_query($conn, "UPDATE `certi_license_tb` SET `logo1` = '' WHERE `certi_license_tb`.`id` = '$id'");
}
if (isset($_POST['reLogo2'])) {
    mysqli_query($conn, "UPDATE `certi_license_tb` SET `logo2` = '' WHERE `certi_license_tb`.`id` = '$id'");
}

if (isset($_POST['resignature_image_1'])) {
    mysqli_query($conn, "UPDATE `certi_license_tb` SET `signature_image_1` = '' WHERE `certi_license_tb`.`id` = '$id'");
}
if (isset($_POST['resignature_image_2'])) {
    mysqli_query($conn, "UPDATE `certi_license_tb` SET `signature_image_2` = '' WHERE `certi_license_tb`.`id` = '$id'");
}
if (isset($_POST['resignature_image_3'])) {
    mysqli_query($conn, "UPDATE `certi_license_tb` SET `signature_image_3` = '' WHERE `certi_license_tb`.`id` = '$id'");
}
