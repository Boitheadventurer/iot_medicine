<?php
include("../../conn.php");


if (isset($_POST['submit'])) {

    $id = $_GET['id'];
    $theme = '../../theme/';
    $logo = '../../logo/';
    $image_signature = '../../image_signature/';

    $Stheme = $_POST['selectTheme'];
    if ($Stheme == 'none') {
        if (!empty($_FILES["theme"]["name"])) {
            $filename1 = $_FILES["theme"]["name"];
            $filepath1 = $theme . $filename1;
            $filetype1 = pathinfo($filepath1, PATHINFO_EXTENSION);

            if (is_uploaded_file($_FILES["theme"]["tmp_name"])) {
                $moved1 = move_uploaded_file($_FILES["theme"]["tmp_name"], $filepath1);
                if ($moved1) {
                    $filename1_upload_1 = mysqli_query($conn, "UPDATE certi_license_tb2 SET theme = '$filename1' WHERE id = '$id'");
                    echo "sucess";
                } else {
                    echo 'failed';
                }
            }
        }
    } else {
        $filename1_upload_1 = mysqli_query($conn, "UPDATE certi_license_tb2 SET theme = '$Stheme' WHERE id = '$id'");
    }

    $Slogo1 = $_POST['selectLogo1'];
    if ($Slogo1 == 'none') {
        if (!empty($_FILES["logo1"]["name"])) {
            $filename2 = $_FILES["logo1"]["name"];
            $filepath2 = $logo . $filename2;
            $filetype2 = pathinfo($filepath2, PATHINFO_EXTENSION);
            $file_tmp2 = $_FILES["logo1"]["tmp_name"];

            if (is_uploaded_file($file_tmp2)) {
                $moved2 = move_uploaded_file($file_tmp2, $filepath2);
                if ($moved2) {
                    $filename1_upload_2 = mysqli_query($conn, "UPDATE certi_license_tb2 SET logo1 = '$filename2' WHERE id = '$id'");
                    echo "sucess";
                } else {
                    echo 'failed';
                }
            }
        }
    } else {
        $filename1_upload_2 = mysqli_query($conn, "UPDATE certi_license_tb2 SET logo1 = '$Slogo1' WHERE id = '$id'");
    }


    $Slogo2 = $_POST['selectLogo2'];
    if ($Slogo2 == 'none') {
        if (!empty($_FILES["logo2"]["name"])) {
            $filename3 = $_FILES["logo2"]["name"];
            $filepath3 = $logo . $filename3;
            $filetype3 = pathinfo($filepat3, PATHINFO_EXTENSION);
            $file_tmp3 = $_FILES["logo2"]["tmp_name"];

            if (is_uploaded_file($file_tmp3)) {
                $moved3 = move_uploaded_file($file_tmp3, $filepath3);
                if ($moved3) {
                    $filename1_upload_3 = mysqli_query($conn, "UPDATE certi_license_tb2 SET logo2 = '$filename3' WHERE id = '$id'");
                    echo "sucess";
                } else {
                    echo 'failed';
                }
            }
        }
    } else {
        $filename1_upload_3 = mysqli_query($conn, "UPDATE certi_license_tb2 SET logo2 = '$Slogo2' WHERE id = '$id'");
    }



    if (!empty($_FILES["signature_image_1"]["name"])) {
        $filename4 = $_FILES["signature_image_1"]["name"];
        $filepath4 = $image_signature . $filename4;
        $filetype4 = pathinfo($filepath4, PATHINFO_EXTENSION);
        $file_tmp4 = $_FILES["signature_image_1"]["tmp_name"];

        if (is_uploaded_file($file_tmp4)) {
            $moved4 = move_uploaded_file($file_tmp4, $filepath4);
            if ($moved4) {
                $filename1_upload_4 = mysqli_query($conn, "UPDATE certi_license_tb2 SET signature_image_1 = '$filename4' WHERE id = '$id'");
                echo "sucess";
            } else {
                echo 'failed';
            }
        }
    }


    if (!empty($_FILES["signature_image_2"]["name"])) {
        $filename5 = $_FILES["signature_image_2"]["name"];
        $filepath5 = $image_signature . $filename5;
        $filetype5 = pathinfo($filepath5, PATHINFO_EXTENSION);
        $file_tmp5 = $_FILES["signature_image_2"]["tmp_name"];

        if (is_uploaded_file($file_tmp5)) {
            $moved5 = move_uploaded_file($file_tmp5, $filepath5);
            if ($moved5) {
                $filename1_upload_5 = mysqli_query($conn, "UPDATE certi_license_tb2 SET signature_image_2 = '$filename5' WHERE id = '$id'");
                echo "sucess";
            } else {
                echo 'failed';
            }
        }
    }


    if (!empty($_FILES["signature_image_3"]["name"])) {
        $filename6 = $_FILES["signature_image_3"]["name"];
        $filepath6 = $image_signature . $filename6;
        $filetype6 = pathinfo($filepath6, PATHINFO_EXTENSION);
        $file_tmp6 = $_FILES["signature_image_3"]["tmp_name"];

        if (is_uploaded_file($file_tmp6)) {
            $moved6 = move_uploaded_file($file_tmp6, $filepath6);
            if ($moved6) {
                $filename1_upload_6 = mysqli_query($conn, "UPDATE certi_license_tb2 SET signature_image_3 = '$filename6' WHERE id = '$id'");
                echo "sucess";
            } else {
                echo 'failed';
            }
        }
    }

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $text1 = $_POST['text1'];
        $certi_id = $_POST['certi_id'];
        $textname_MR = $_POST['textname_MR'];
        $textname_f = $_POST['textname_f'];
        $textname_l = $_POST['textname_l'];
        $textnature = $_POST['textnature'];
        $text4 = $_POST['text4'];
        $text5 = $_POST['text5'];
        $textD = $_POST['textD'];
        $textM = $_POST['textM'];
        $textY = $_POST['textY'];
        $signature_1 = $_POST['signature_1'];
        $signature_2 = $_POST['signature_2'];
        $signature_3 = $_POST['signature_3'];
        $signature_po1 = $_POST['signature_po1'];
        $signature_po2 = $_POST['signature_po2'];
        $signature_po3 = $_POST['signature_po3'];


        $check = mysqli_query($conn, "select * from certi_license_tb2 where id = $id ");
        $checkrow = mysqli_num_rows($check);
        if ($checkrow > 0) {
            $result01 = mysqli_query($conn, "UPDATE certi_tb SET certi_license_tb2 = '$id' WHERE id_certificate = '$id'");
            $result1 = mysqli_query($conn, "UPDATE certi_license_tb2 SET
                text1 = '$text1',
                certi_id = '$certi_id',
                textname_MR = '$textname_MR',
                textname_f = '$textname_f',
                textname_l = '$textname_l',
                textnature = '$textnature',
                text4 = '$text4',
                text5 = '$text5',
                textD = '$textD',
                textM = '$textM',
                textY = '$textY',
                signature_1 = '$signature_1',
                signature_2 = '$signature_2',
                signature_3 = '$signature_3',
                signature_po1 = '$signature_po1',
                signature_po2 = '$signature_po2',
                signature_po3 = '$signature_po3'
                WHERE id = '$id'");
        } else {
            $result02 = mysqli_query($conn, "UPDATE certi_tb SET certi_license_tb2 = '$id' WHERE id_certificate = '$id'");
            $result2 = mysqli_query($conn, "insert into certi_license_tb2 value
                ('$id',
                '',
                '',
                '',
                '$text1',
                '$certi_id',
                '$textname_MR',
                '$textname_f',
                '$textname_l',
                '$textnature',
                '$text4',
                '$text5',
                '$textD',
                '$textM',
                '$textY',
                '',
                '$signature_1',
                '$signature_po1',
                '',
                '$signature_2',
                '$signature_po2',
                '',
                '$signature_3',
                '$signature_po3'
                )");
        }
        header("location:../certificate3.php?id=" . $id);
    }
}
