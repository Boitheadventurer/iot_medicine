<?php
include("../../conn.php");


$detail = $_POST['detail'];
$datestart = $_POST['datestart'];
$dateend = $_POST['dateend'];

$result = mysqli_query($conn, "INSERT INTO 
    certi_tb
    ( 
        detail, 
        datestart, 
        dateend,
        certi_license_tb
      
    ) 
        VALUES 
    ( 
            '$detail', 
            '$datestart', 
            '$dateend',
            ''
    )
");

if ($result) {
    echo 'data insert';
}
?>