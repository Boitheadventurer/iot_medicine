<?php
include("../../conn.php");

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $detail = $_POST['detail'];
    $datestart = $_POST['datestart'];
    $dateend = $_POST['dateend'];

    $result = mysqli_query($conn, "UPDATE certi_tb SET

    detail = '$detail',
    datestart = '$datestart',
    dateend = '$dateend'

    WHERE id_certificate = '$id'");

    if ($result) {
        echo 'data update';
    }
}
