<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/certistyle.css?v=<?php echo filemtime('css/certistyle.css'); ?>" />
    <link rel="stylesheet" href="css/print.css?v=<?php echo filemtime('css/print.css'); ?>" />
    <title>Document</title>


</head>

<body>
    <div class="connan">
        <header>
            <?php
            include '../conn.php';
            $id = $_GET['id'];
            $table = mysqli_query($conn, "SELECT * FROM certi_license_tb2 WHERE id = '$id'");
            $row = mysqli_fetch_array($table);
            ?>
            <form action="ajax/imgupload3.php?id=<?php echo $id ?>" method="POST" enctype="multipart/form-data">
                <div class="menu settings">
                    <ul class="menu-list">
                    <a class="button" href="index.php" style="margin-right: 20rem"><b>กลับ</b></a>
                    <br>
                        <h1>ธีม</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>เลือกธีมเกียรติบัตร</h3>
                                <div class="input_type_file">
                                    <input name="theme" id="theme" type="file">
                                    <a id="reTheme" data-id="reTheme" data-target="<?php echo $id ?>">ลบ</a>
                                </div>
                                <select class="select" name="selectTheme" id="selectTheme" onchange="this.form.submit()">
                                    <option value="none">กรุณาเลือกธีม</option>
                                    <option value="1.png">Theme1</option>
                                    <option value="2.png">Theme2</option>
                                    <option value="3.png">Theme3</option>
                                    <option value="4.png">Theme4</option>
                                    <option value="5.png">Theme5</option>
                                    <option value="6.png">Theme6</option>
                                    <option value="7.png">Theme7</option>
                                    <option value="8.png">Theme8</option>
                                    <option value="9.png">Theme9</option>
                                    <option value="10.png">Theme10</option>
                                </select>
                                <button type="submit" name="submit" id="save_certificate" class="button" data-id="<?php echo $id ?>">Save Certificate</button>
                            </div>
                        </li>
                    </ul>
                    <ul class="menu-list">
                        <h1>รหัสเกียรติบัตร</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>เลขที่</h3>
                                <input type="text" oninput="previewcerti_id()" name="certi_id" id="certi_id" data-target="certi_id" value="<?php echo $row['certi_id']; ?>">
                            </div>
                        </li>
                    </ul>
                    <ul class="menu-list">
                        <h1>Logo</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>Logo1</h3>
                                <div class="input_type_file">
                                    <input name="logo1" id="logo1" type="file">
                                    <a id="reLogo1" data-id="reLogo1" data-target="<?php echo $id ?>">ลบ</a>
                                </div>
                                <select class="select" name="selectLogo1" id="selectLogo1" onchange="this.form.submit()">
                                    <option value="none">ไม่เลือก</option>
                                    <option value="logo_computer.png">เทคนิคคอมพิวเตอร์</option>
                                    <option value="technic1.webp">เทคนิคแพร่</option>
                                </select>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>Logo2</h3>
                                <div class="input_type_file">
                                    <input name="logo2" id="logo2" type="file">
                                    <a id="reLogo2" data-id="reLogo2" data-target="<?php echo $id ?>">ลบ</a>
                                </div>
                                <select class="select" name="selectLogo2" id="selectLogo2" onchange="this.form.submit()">
                                    <option value="none">ไม่เลือก</option>
                                    <option value="logo_computer.png">เทคนิคคอมพิวเตอร์</option>
                                    <option value="technic1.webp">เทคนิคแพร่</option>
                                </select>
                            </div>
                        </li>
                    </ul>
                    <ul class="menu-list">
                        <h1>ข้อมุลเกียรติบัตร</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ชื่อหน่วยงาน</h3>
                                <input type="text" oninput="preview1()" name="text1" id="text1" data-target="text1" placeholder="วิทยาลัยเทคนิคแพร่" value="<?php echo $row['text1']; ?>">
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ชื่อนามสกุล</h3>
                                <div class="menu-input">
                                    <input type="text" oninput="" id="textname_MR" name="textname_MR" value="นาย" placeholder="คำนำ">
                                    <input type="text" oninput="" id="textname_f" name="textname_f" value="ศุภวิชญ์" placeholder="ชื่อ">
                                    <input type="text" oninput="" id="textname_l" name="textname_l" value="ร่องพืช" placeholder="นามสกุล">
                                    <!-- <input type="text" style="" oninput="previewname_MR()" id="textname_MR" name="textname_MR" value="นาย" placeholder="คำนำ">
                                    <input type="text" style="" oninput="previewname_f()" id="textname_f" name="textname_f" value="ศุภวิชญ์" placeholder="ชื่อ">
                                    <input type="text" style="" oninput="previewname_l()" id="textname_l" name="textname_l" value="ร่องพืช" placeholder="นามสกุล"> -->
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>รางวัลที่ได้</h3>
                                <input type="text" oninput="previewnature()" id="textnature" name="textnature" placeholder="เป็นผู้มีความประพฤติดี" value="<?php echo $row['textnature']; ?>">
                            </div>
                        </li>
                        <li class="menu-item" style="display: none;">
                            <div class="menu-input">
                                <h3>test</h3>
                                <input type="number" oninput="previewterm()" id="text4" name="text4" placeholder="ภาคเรียน" value="<?php echo $row['text4']; ?>">
                            </div>
                        </li>
                        <li class="menu-item" style="display: none;">
                            <div class="menu-input">
                                <h3>test</h3>
                                <input type="number" oninput="previewyear()" id="text5" name="text5" placeholder="ปีการศึกษา" value="<?php echo $row['text5']; ?>">
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ให้ไว้ ณ</h3>
                                <div class="menu-input">
                                    <input type="number" oninput="previewD()" id="textD" name="textD" placeholder="วันที่" value="<?php echo $row['textD']; ?>">
                                    <input type="text" oninput="previewM()" id="textM" name="textM" placeholder="เดือน" value="<?php echo $row['textM']; ?>">
                                    <input type="number" oninput="previewY()" id="textY" name="textY" placeholder="ปี" value="<?php echo $row['textY']; ?>">
                                </div>
                            </div>
                        </li>
                    </ul>
                    <ul class="menu-list">
                        <h1>ลายเซ็น</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ลายเซ็นที่1</h3>
                                <div class="menu-input">
                                    <div class="input_type_file">
                                        <input type="file" id="signature_image_1" name="signature_image_1" placeholder="รูปลายเซ็น">
                                        <a id="resignature_image_1" data-id="resignature_image_1" data-target="<?php echo $id ?>">ลบ</a>
                                    </div>
                                    <input type="text" oninput="text_signature_1()" id="signature_1" name="signature_1" placeholder="ชื่อเจ้าของลายเซ็น" value="<?php echo $row['signature_1']; ?>">
                                    <input type="text" oninput="text_signature_po1()" id="signature_po1" name="signature_po1" placeholder="ตำแหน่ง" value="<?php echo $row['signature_po1']; ?>">
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ลายเซ็นที่2</h3>
                                <div class="menu-input">
                                    <div class="input_type_file">
                                        <input type="file" id="signature_image_2" name="signature_image_2" placeholder="รูปลายเซ็น">
                                        <a id="resignature_image_2" data-id="resignature_image_2" data-target="<?php echo $id ?>">ลบ</a>
                                    </div>
                                    <input type="text" oninput="text_signature_2()" id="signature_2" name="signature_2" placeholder="ชื่อเจ้าของลายเซ็น" value="<?php echo $row['signature_2']; ?>">
                                    <input type="text" oninput="text_signature_po2()" id="signature_po2" name="signature_po2" placeholder="ตำแหน่ง" value="<?php echo $row['signature_po2']; ?>">
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ลายเซ็นที่3</h3>
                                <div class="menu-input">
                                    <div class="input_type_file">
                                        <input type="file" id="signature_image_3" name="signature_image_3" placeholder="รูปลายเซ็น">
                                        <a id="resignature_image_3" data-id="resignature_image_3" data-target="<?php echo $id ?>">ลบ</a>
                                    </div>
                                    <input type="text" oninput="text_signature_3()" id="signature_3" name="signature_3" placeholder="ชื่อเจ้าของลายเซ็น" value="<?php echo $row['signature_3']; ?>">
                                    <input type="text" oninput="text_signature_po3()" id="signature_po3" name="signature_po3" placeholder="ตำแหน่ง" value="<?php echo $row['signature_po3']; ?>">
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <button type="submit" name="submit" id="save_certificate" class="button" data-id="<?php echo $id ?>">Save Certificate</button>
                                <a class="button" href="index.php"><b>กลับ</b></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </form>
        </header>
        <main>
            <div class="layout">
                <div class="page">
                    <div id="print-form">
                        <div class="form-img">
                            <div class="background" id="background">
                                <?php
                                if ($row['theme'] == '') { ?>
                                    <img src="../theme/Illustration2.png" alt="">
                                <?php } else { ?>
                                    <img src="../theme/<?php echo $row['theme'] ?>" alt="">
                                <?php } ?>
                            </div>
                            <div class="text" name="text" id="previewcerti_id"></div>
                            <div class="print_certificate">
                                <div class="print_certificate_head" id="print_certificate_head">
                                    <div class="image_Logo" id="Logo1">
                                        <?php
                                        if ($row['logo1'] == '') { ?>

                                        <?php } else { ?>
                                            <img src="../logo/<?php echo $row['logo1'] ?>" alt="" style="margin: 0 5px;">
                                        <?php } ?>
                                    </div>
                                    <div class="image_Logo" id="Logo2">
                                        <?php
                                        if ($row['logo2'] == '') { ?>

                                        <?php } else { ?>
                                            <img src="../logo/<?php echo $row['logo2'] ?>" alt="" style="margin: 0 5px;">
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="print_certificate_body">
                                    <div class="text" name="text" id="preview1"><?php $row['text1'] ?></div>
                                    <div class="text" name="text">มอบเกียรติบัตรฉบับนี้ให้ไว้เพื่อแสดงว่า</div>
                                    <div class="name_MR_F_L">
                                        <div class="text" name="text" id="previewname_MR"></div>
                                        <div class="text" name="text" id="previewname_f"></div>
                                        <div class="text" name="text" id="previewname_l"></div>
                                    </div>

                                    <div class="text" name="text" id="previewnature"></div>
                                    <div class="text" name="text">ตลอดหลักสูตรประกาศนียบัตรวิชาชีพ (ปวช.)/ตลอดหลักสูตรประกาศนียบัตรวิชาชีพชั้นสูง (ปวส.)</div>
                                    <!-- <div class="text" name="text">ตลอดหลักสูตรประกาศนียบัตรวิชาชีพชั้นสูง (ปวส.)</div> -->

                                    <div class="termD_M_Y">
                                        <div class="text" name="text">ให้ไว้ ณ วันที่</div>
                                        <div class="text" name="text" id="previewD"></div>
                                        <div class="text" name="text">เดือน</div>
                                        <div class="text" name="text" id="previewM"></div>
                                        <div class="text" name="text">พ.ศ.</div>
                                        <div class="text" name="text" id="previewY"></div>
                                    </div>
                                </div>
                                <div class="print_certificate_end">
                                    <div class="signature">
                                        <div class="signature_t_i">
                                            <div id="image_signature_1" class="image_signature">
                                                <?php
                                                if ($row['signature_image_1'] == '') { ?>

                                                <?php } else { ?>
                                                    <img id="image_1" src="../image_signature/<?php echo $row['signature_image_1'] ?>" alt="" style="margin: 0 6rem;">
                                                <?php } ?>
                                            </div>
                                            <div id="text_signature_1" class="text_signature"></div>
                                            <div id="text_signature_po1" class="text_signature"></div>
                                        </div>
                                        <div class="signature_t_i">
                                            <div id="image_signature_2" class="image_signature">
                                                <?php
                                                if ($row['signature_image_2'] == '') { ?>

                                                <?php } else { ?>
                                                    <img id="image_2" src="../image_signature/<?php echo $row['signature_image_2'] ?>" alt="" style="margin: 0 6rem;">
                                                <?php } ?>
                                            </div>
                                            <div id="text_signature_2" class="text_signature"></div>
                                            <div id="text_signature_po2" class="text_signature"></div>
                                        </div>
                                        <div class="signature_t_i">
                                            <div id="image_signature_3" class="image_signature">
                                                <?php
                                                if ($row['signature_image_3'] == '') { ?>

                                                <?php } else { ?>
                                                    <img id="image_3" src="../image_signature/<?php echo $row['signature_image_3'] ?>" alt="" style="margin: 0 6rem;">
                                                <?php } ?>
                                            </div>
                                            <div id="text_signature_3" class="text_signature"></div>
                                            <div id="text_signature_po3" class="text_signature"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>
    <script src="js/idcertificate3.js?v=<?php echo filemtime('js/idcertificate3.js'); ?>"></script>
    <script>
        $(document).ready(function() {
            const areaToPrint = document.getElementById('print-form');
            areaToPrint.addEventListener('click', function() {
                print();
            });
        });
    </script>
</body>

</html>