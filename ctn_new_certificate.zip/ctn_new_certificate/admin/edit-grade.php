<?php
include '../conn.php'; 
error_reporting(0);
?>
<?php
if (isset($_GET['level'])){
    $level = $_GET['level'];
    $group = $_GET['group'];
    $num = $_GET['num'];
    $year = $_GET['year'];
    $term = $_GET['term'];
    $terms = $_GET['terms'];
    $sumnum = $_GET['sumnum'];
    $preyear = $_GET['preyear'];
    $chkyear = date('Y') + 543 - $year;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../image/CTN.png">
    <title>Responsive Table Example</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!--sweet alert-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!--Jquery-->

    <!-- RemixIcon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
        body{
            background-color: #e0e0e0;
        }

        *{
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        ::selection {
            color: #ffffff;
            background: #2A47D7;
        }

        .container-s{
            max-width: 1000px;
            padding: 30px;
            width: 90%;
            margin: auto;
        }

        .str{
            width: auto;
            max-width: 550px;
            justify-content: center;
            align-items: center;
            margin: auto;
        }

        .dpnum{
            min-width: 125px;
        }

        .dpname{
            min-width: 275px;
        }

        .dpgrade{
            min-width: 110px;
        }

        @media only screen and (max-width: 710px) {
            .back_b{
                display: none;
            }
        }

    </style>
</head>

<body>

    <div class="container-s bg-light shadow border rounded my-5">
        <h5>
            <a href="index.php" class="text-primary">หน้าหลัก</a> &nbsp; / &nbsp; 
            <a href="add_term.php" class="text-primary">ปีการศึกษา</a> &nbsp; / &nbsp; 
            <a href="add_level.php?term=<?php echo $terms ?>" class="text-primary">ระดับชั้น</a> &nbsp; / &nbsp; 
            <u class="text-muted">ผลการเรียน</u>
            <a href="add_level.php?term=<?php echo $terms ?>" class="back_b btn btn-warning float-right" type="button"><i class="ri-arrow-left-fill"></i> ย้อนกลับ</a>
        </h5>
        <form name="chk_activities" action="insert/grade_inn.php" method="post">
        <h3 class="text-center my-4">แก้ไขผลการเรียน</h3>
        <h4 class="text-center">
            ปีการศึกษา <?php echo $year;?> <br> 
            <?php echo $level;?> ปีที่ <?php echo $sumnum;?> ภาคเรียนที่ <?php echo $term;?>
        </h4>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <div class="str">
                    <!-- Value Get -->
                            <input name="save_level" class="form-control mb-3" value="<?php echo $level;?>" hidden>
                            <input name="save_num" class="form-control mb-3" value="<?php echo $sumnum;?>" hidden>
                            <input name="save_term" class="form-control mb-3" value="<?php echo $term;?>" hidden>
                            <input name="save_year" class="form-control mb-3" value="<?php echo $year;?>" hidden>
                    <!-- End Value Get -->
                    </div>
                    <thead class="thead-light">
                        <tr class="text-center">
                            <th class="col-1">ลำดับ</th>
                            <th class="dpnum">รหัสประจำตัว</th>
                            <th class="dpname">ชื่อ - สกุล</th>
                            <th class="dpgrade col-2">เกรดเทอมนี้</th>
                            <th class="dpgrade col-2">เกรดสะสม</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if (isset($level) && isset($group)) {
                                $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year,tb_grade.grade_grade,tb_grade.grade_sum_grade
                                FROM tb_member
                                LEFT JOIN tb_student_level
                                ON tb_member.member_id = tb_student_level.member_id
                                LEFT JOIN tb_grade
                                ON tb_member.member_id = tb_grade.member_id
                                WHERE tb_member.member_firstname != '' AND tb_grade.grade_level = '$level' AND tb_grade.grade_num = '$sumnum' AND tb_student_level.student_group = '$group' AND tb_grade.grade_year = '$year' AND tb_grade.grade_term = '$term' ORDER BY tb_member.member_code ASC";
                                $result = $conn->query($sql);

                            if ($result->num_rows >= 1) {
                                $num_rows = mysqli_num_rows($result);
                                for ($i=0; $i<$num_rows; $i++){
                                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td hidden>
                                <input type="text" name="terms" value="<?php echo $terms ?>" />
                                <input type="text" name="member_id[]" value="<?php echo $row['member_id']; ?>" />
                            </td>
                            <td class="text-center"><?php echo $i+1; ?></td>
                            <td class="text-center"><?php echo $row['member_code']; ?></td>
                            <td class="pl-5"><?php echo $row['member_title']; echo"   "; echo $row['member_firstname']; echo"   "; echo $row['member_lastname']; ?></td>
                            <td align="center">
                                <input type="number" name="this_term[]" class="form-control" placeholder="0.00" required value="<?php echo $row['grade_grade'];?>" step="0.01" min="0" max="4" oninput="validateAndFormat(this)"/>
                            </td>
                            <td align="center">
                                <input type="number" name="sum_term[]" class="form-control" placeholder="0.00" required value="<?php echo $row['grade_sum_grade'];?>" step="0.01" min="0" max="4" oninput="validateAndFormat(this)" />
                            </td>
                        </tr>
                        <?php break;}}}} ?>
                    </tbody>
                </table>
                <input type="submit" class="btn btn-info w-100" name="submit" value="บันทึก" />
            </div>
        </form>
    </div>

    <script>
        function validateAndFormat(input) {
            let value = input.value.replace(/[^0-9]/g, ''); // Remove non-numeric characters

            if (value.length > 1) {
                value = value.slice(0, 1) + '.' + value.slice(1, 3); // Insert decimal point after the first digit
            }
            const numericValue = parseFloat(value);
            if (numericValue < 0 || numericValue > 4) {
                input.value = '';
                return;
            }
            if (value.indexOf('.') === -1 ) {
                input.value = '';
            }
            input.value = value;
        }
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
