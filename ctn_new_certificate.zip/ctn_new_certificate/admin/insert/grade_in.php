
<?php
include '../../conn.php'; 
if (isset($_POST['submit'])) {
    $id = $_POST['member_id'];
    $level = $_POST['save_level'];
    $num = $_POST['save_num'];
    $term = $_POST['save_term'];
    $year = $_POST['save_year'];
    $thisterm = $_POST['this_term'];
    $sumterm = $_POST['sum_term'];

    $sql = mysqli_query($conn,"INSERT INTO tb_grade(member_id,grade_level,grade_num,grade_term,grade_year,grade_grade,grade_sum_grade) 
        VALUES('$id','$level','$num','$term','$year','$thisterm','$sumterm')");

 if($sql=TRUE){
    echo "<script>
            alert('บันทึกเกรดสำเร็จ  !!');
            location.href='../save-grade.php';   
        </script>";
 }
}
?>