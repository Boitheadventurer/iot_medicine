<?php
include '../../conn.php'; 
  if (isset($_POST['submit'])) {
   $terms= $_POST["terms"];
   $all = count($_POST["member_id"]);
   for ($i = 0; $i < $all; $i++) {
    if($_POST["this_term"][$i]=="" || $_POST["sum_term"][$i]==""){
     $_POST["this_term"][$i]=0;
     $_POST["sum_term"][$i]=0;
    }
    

      $level =  $_POST["save_level"];
      $num =  $_POST["save_num"];
      $term =  $_POST["save_term"];
      $year =  $_POST["save_year"];
      $id = $_POST["member_id"][$i];
      /*
     $grad = $this->useful_model->get_where_custom_order5('tb_grade', 'grade_level', $_POST['save_level'], 'grade_num', $_POST['save_num'], 'grade_term', $_POST['save_term'], 'grade_year', $_POST['save_year'],'member_id',$_POST["member_id"][$i], 'grade_id asc')->row();
    */
     $grade = "SELECT * FROM tb_grade WHERE grade_level = '$level' AND grade_num = '$num' AND grade_term = '$term' AND grade_year = '$year' AND member_id = '$id'";
     $result_grade = $conn->query($grade);
     $row_grade = $result_grade->fetch_assoc();
     $grades = $row_grade['grade_id'];
     if($grades != ""){
      $data = array(
       $thisterm = $_POST["this_term"][$i],
       $sumterm = $_POST["sum_term"][$i],
       $level = $_POST["save_level"]
      );
      $sql = mysqli_query($conn,"UPDATE tb_grade SET grade_grade='$thisterm',grade_sum_grade='$sumterm',grade_level='$level' WHERE grade_id = '$grades'");
     }

     
     else{
      $data = array(
        $thisterm = $_POST["this_term"][$i],
        $sumterm = $_POST["sum_term"][$i],
        $level =  $_POST["save_level"],
        $num =  $_POST["save_num"],
        $term =  $_POST["save_term"],
        $year =  $_POST["save_year"],
        $id = $_POST["member_id"][$i]
      );

      $sql = mysqli_query($conn,"INSERT INTO tb_grade(member_id,grade_level,grade_num,grade_term,grade_year,grade_grade,grade_sum_grade) 
        VALUES('$id','$level','$num','$term','$year','$thisterm','$sumterm')");
     }
    
   }

   echo "<script>alert('บันทึกเกรด เรียบร้อยแล้ว');
           location.href='../add_level.php?term=$terms'; 
   </script>";
} 
 ?>