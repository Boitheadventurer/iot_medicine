<!DOCTYPE html>
<html lang="th">
<?php  
 include '../conn.php';
?>
 <?php
    if (isset($_POST['search']))  {

        //$data['student'] = $this->useful_model->get_where_custom_order5('tb_student_level', 'student_major', $this->input->post('major'), 'student_level', $this->input->post('level'), 'student_num', $this->input->post('num'), 'student_group', $this->input->post('group'), 'student_year', $this->input->post('year'), 'student_id asc')->result_array();
    
        $major = $_POST["major"];
        $level = $_POST["level"];
        $num = $_POST["num"];
        $group = $_POST["group"];
        $year = $_POST["year"];

        $student = "SELECT * FROM tb_student_level WHERE student_major ='$major' AND student_level = '$level' AND student_num = '$num' AND student_group = '$group' AND student_year = '$year'";
        
    }
    ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        nav.menu .menu1 a {
            color: #F00;
        }

        .submenu-xs li:nth-child(1) {}
    </style>
    <title>ค้นหานักเรียน นักศึกษา</title>
</head>

<body>
    <div class="container my-5">
        <div class="card">
            <div class="card-header text-center">
                <b>ค้นหานักเรียน นักศึกษา</b>
            </div>
            <div class="card-body">
                <form name="add_student" action="" method="post" class="add_student">
                    <div class="form-group row">
                        <label for="major" class="col-sm-2 col-form-label">สาขางาน</label>
                        <div class="col-sm-10">
                            <select name="major" id="major" class="form-control">
                                <?php if (isset($_POST['major'])) { ?>
                                    <option value="<?php echo $_POST['major']; ?>"><?php echo $_POST['major']; ?></option>
                                <?php } ?>
                                <option value="เทคนิคคอมพิวเตอร์">เทคนิคคอมพิวเตอร์</option>
                                <option value="คอมพิวเตอรซอฟต์แวร์์">คอมพิวเตอรซอฟต์แวร์์</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="level" class="col-sm-2 col-form-label">ระดับ</label>
                        <div class="col-sm-10">
                            <select name="level" id="level" class="form-control">
                                <?php if (isset($_POST['level'])) { ?>
                                    <option value="<?php echo $_POST['level']; ?>"><?php echo $_POST['level']; ?></option>
                                <?php } ?>
                                <option value="ปวช">ปวช.</option>
                                <option value="ปวส">ปวส.</option>
                                <option value="ปวสม6">ปวส.ม.6</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="num" class="col-sm-2 col-form-label">ชั้นปี</label>
                        <div class="col-sm-10">
                            <select name="num" id="num" class="form-control">
                                <?php if (isset($_POST['num'])) { ?>
                                    <option value="<?php echo $_POST['num']; ?>"><?php echo $_POST['num']; ?></option>
                                <?php } ?>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="group" class="col-sm-2 col-form-label">กลุ่ม</label>
                        <div class="col-sm-10">
                            <select name="group" id="group" class="form-control">
                                <?php if (isset($_POST['group'])) { ?>
                                    <option value="<?php echo $_POST['group']; ?>"><?php echo $_POST['group']; ?></option>
                                <?php } ?>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="term" class="col-sm-2 col-form-label">เทอม</label>
                        <div class="col-sm-10">
                            <select name="term" id="term" class="form-control">
                                <?php if (isset($_POST['term'])) { ?>
                                    <option value="<?php echo $_POST['term']; ?>"><?php echo $_POST['term']; ?></option>
                                <?php } ?>
                                <option value="1">1</option>
                                <option value="2">2</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="year" class="col-sm-2 col-form-label">ปีการศึกษา</label>
                        <div class="col-sm-10">
                            <select name="year" id="year" class="form-control">
                                <?php if (isset($_POST['year'])) { ?>
                                    <option value="<?php echo $_POST['year']; ?>"><?php echo $_POST['year']; ?></option>
                                <?php } ?>
                                <option value="<?php echo date('Y') + 542; ?>"><?php echo date('Y') + 542; ?></option>
                                <option value="<?php echo date('Y') + 543; ?>"><?php echo date('Y') + 543; ?></option>
                                <option value="<?php echo date('Y') + 544; ?>"><?php echo date('Y') + 544; ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="code" class="col-sm-2 col-form-label">รหัสกลุ่ม</label>
                        <div class="col-sm-10">
                            <input type="text" name="code" id="code" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="sub_code" class="col-sm-2 col-form-label">รหัสวิชา</label>
                        <div class="col-sm-10">
                            <input type="text" name="sub_code" id="sub_code" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="sub_name" class="col-sm-2 col-form-label">ชื่อวิชา</label>
                        <div class="col-sm-10">
                            <input type="text" name="sub_name" id="sub_name" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="teacher" class="col-sm-2 col-form-label">อ.ผู้สอน</label>
                        <div class="col-sm-10">
                            <input type="text" name="teacher" id="teacher" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10 offset-sm-2">
                            <button type="submit" name="search" class="btn btn-primary">ค้นหา</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php if (isset($_POST['search'])) { ?>
            <div class="text-center my-4">
                <button class="btn btn-secondary" onclick="printDiv('print_page')">พิมพ์</button>
            </div>
            <div id="print_page" class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th colspan="8" class="text-center">
                                <h1>แบบสรุปกิจกรรมประจำปีการศึกษา <?php if (isset($_POST['year'])) {
                                                                        echo $_POST['year'];
                                                                    } ?></h1>
                            </th>
                        </tr>
                        <tr>
                            <th colspan="8" class="text-center">รายชื่อนักศึกษา สาขางาน<?php if (isset($_POST['major'])) {
                                                                                            echo $_POST['major'];
                                                                                        } ?>&nbsp;&nbsp;&nbsp; ระดับ <?php if (isset($_POST['level'])) {
                                                                                                                            echo $_POST['level'];
                                                                                                                        } ?>.<?php if (isset($_POST['num'])) {
                                                                                                                                                                                                                                            echo $_POST['num'];
                                                                                                                                                                                                                                        } ?> &nbsp;&nbsp; กลุ่ม <?php if (isset($_POST['group'])) {
                                                                                                                                                                                                                                                                                                                            echo $_POST['group'];
                                                                                                                                                                                                                                                                                                                        } ?></th>
                        </tr>
                        <tr>
                            <th colspan="8" class="text-center">ภาคเรียนที่ <?php echo $_POST['term']; ?> &nbsp;&nbsp;&nbsp; ปีการศึกษา <?php if (isset($_POST['year'])) {
                                                                                                                                            echo $_POST['year'];
                                                                                                                                        } ?></th>
                        </tr>
                        <tr>
                            <th colspan="8" class="text-center">วิชา <?php if (isset($_POST['sub_name'])) {
                                                                            echo $_POST['sub_name'];
                                                                        } ?></th>
                        </tr>
                        <tr>
                            <th>ลำดับ</th>
                            <th>รหัสประจำตัว</th>
                            <th>ชื่อ - สกุล</th>
                            <th>หน้าเสาธง</th>
                            <!-- <th>ทำความดี</th>
                            <?php if ($_POST['level'] == "ปวช" && $_POST['num'] == '1') { ?>
                                <th>ทำเวร</th>
                            <?php } elseif ($_POST['level'] == "ปวส" && $_POST['num'] == '1') { ?>
                                <th>ตรวจเวร</th>
                            <?php } ?>
                            <th>วันพุธ</th> -->
                            <th>ลงทะเบียนแก้กิจกรรม</th>
                        </tr>
                    </thead>
                    <tbody>
                        
   
                        <?php
                        /**echo $student; **/
                        $i = 0;
                        if (isset($student)) {
                            foreach ($conn->query($student) as $r_1) {
                                $rmember = $r_1['member_id'];
                                $rterm = $_POST["term"];
                                $ryear = $_POST["year"];
                                $std_check = "SELECT * FROM tb_all_activities WHERE member_id = '$rmember' AND acc_term ='$rterm' AND acc_year = '$ryear'  ";  
                                echo $std_check;
                                foreach ($conn->query($std_check) as $r) {
                                    $i++;
                                    $memberr = $r['member_id'];
                                    $stu_name1 = "SELECT * FROM tb_member WHERE member_id = '$memberr'";
                                    $stu_name = $conn->query($stu_name1);
                                    $stu_name = $stu_name->fetch_assoc();
                                    // ธนาคารความดี
                                    $good_num = "SELECT * FROM tb_good_record WHERE member_id = '$memberr' AND good_term = '$rterm' AND good_year = '$ryear' AND good_status = '1'";
                                    $good_sum = $conn->query($good_num);
                                    $count_good = mysqli_num_rows($good_sum);
                                    if ($count_good >= 3) {
                                        $count_good = 1;
                                    } else {
                                        $count_good = 0;
                                    }
                                    if ($r['acc_good'] == '0' && $count_good == '1') {
                                        $data = array(
                                            'acc_good' => $count_good
                                        );
                                        $this->useful_model->_update('tb_all_activities', 'acc_id', $r['acc_id'], $data);
                                        $racc_id = $r['acc_id'];
                                        $sql = mysqli_query($conn,"UPDATE _tb_all_activities SET acc_id='$racc_id' WHERE grade_id = '$grades'");
                                    }
                        ?>
                                    <tr>
                                        <td class="text-center"><?php echo $i; ?><input type="hidden" name="member_id[]" value="<?php echo $r['member_id']; ?>" /></td>
                                        <td><?php echo $stu_name['member_code']; ?></td>
                                        <td><?php echo $stu_name['member_title']; echo $stu_name['member_firstname']; echo " ";  echo $stu_name['member_lastname']; ?></td>
                                        <td class="text-center">
                                            <b class="text-success"><?php if ($r['acc_1'] == '1') {
                                                                        echo "ผ่าน";
                                                                    } else {; ?></b><b class="text-danger"><?php echo "ไม่ผ่าน";
                                                                                                        } ?></b>
                                        </td>
                                        <!-- <td class="text-center">
                                            <b class="text-success"><?php if ($r['acc_good'] == '1') {
                                                                        echo "ผ่าน";
                                                                    } else {; ?></b><b class="text-danger"><?php echo "ไม่ผ่าน";
                                                                                                        } ?></b>
                                        </td>
                                        <?php if ($_POST['num'] == '1') { ?>
                                            <td class="text-center">
                                                <b class="text-success"><?php if ($r['acc_2'] == '1') {
                                                                            echo "ผ่าน";
                                                                        } else {; ?></b><b class="text-danger"><?php echo "ไม่ผ่าน";
                                                                                                            } ?></b>
                                            </td>
                                        <?php } ?>
                                        <td class="text-center">
                                            <b class="text-success"><?php if ($r['acc_3'] == '1') {
                                                                        echo "ผ่าน";
                                                                    } else {; ?></b><b class="text-danger"><?php echo "ไม่ผ่าน";
                                                                                                        } ?></b>
                                        </td>-->
                                        <td class="text-center">
                                            <?php if ($_POST['num'] == '1') { ?>
                                                <b class="text-success"><?php if ($r['acc_1'] == '1' && $r['acc_2'] == '1' && $r['acc_3'] == '1') {
                                                                            echo "ผ่าน";
                                                                        } elseif ($r['acc_status'] == '1') {
                                                                            echo "ผ่าน";
                                                                        } else {; ?></b><b class="text-danger"><?php echo "ไม่ผ่าน";
                                                                                                            } ?></b>
                                            <?php } else { ?>
                                                <b class="text-success"><?php if ($r['acc_1'] == '1' && $r['acc_3'] == '1') {
                                                                            echo "ผ่าน";
                                                                        } elseif ($r['acc_status'] == '1') {
                                                                            echo "ผ่าน";
                                                                        } else {; ?></b><b class="text-danger"><?php echo "ไม่ผ่าน";
                                                                                                            } ?></b>
                                            <?php } ?>
                                        </td> 
                                    </tr>
                        <?php }
                            }
                        }
                        ?>
                        <tr style="border-bottom:1px solid #B6B5B5;">
                            <td colspan="8"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php } ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        function printDiv(divId) {
            var printContents = document.getElementById(divId).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    </script>


</body>

</html>