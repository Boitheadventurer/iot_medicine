<!DOCTYPE html>
<html lang="th">
<?php
include '../conn.php';
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        nav.menu .menu1 a {
            color: #F00;
        }

        .submenu-xs li:nth-child(1) {}

        @media print {
            @page {
                size: A4;
                margin: 50px 50px 150px 50px;
            }

            body {
                background-color: #fff;
            }

            div {
                page-break-after: always;
            }

            .container-custom {
                width: 100%;
            }

            .btn {
                display: none;
            }

            .btn-container {
                display: none;
            }
        }
    </style>
    <title>ค้นหานักเรียน นักศึกษา</title>
</head>

<body>
    <div class="container my-5">
        <div class="card">
            <div class="card-header text-center">
                <b>ค้นหานักเรียน นักศึกษา</b>
            </div>
            <div class="card-body">
                <form name="add_student" action="" method="post" class="add_student">
                    <div class="form-group row">
                    </div>
                    <div class="form-group row">
                        <label for="level" class="col-sm-2 col-form-label">ระดับ</label>
                        <div class="col-sm-10">
                            <select name="level" id="level" class="form-control">
                                <?php if (isset($_POST['level'])) { ?>
                                    <option value="<?php echo $_POST['level']; ?>"><?php echo $_POST['level']; ?></option>
                                <?php } ?>
                                <option value="ปวช">ปวช.</option>
                                <option value="ปวส">ปวส.</option>
                                <option value="ปวสม6">ปวส.ม.6</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="num" class="col-sm-2 col-form-label">ชั้นปี</label>
                        <div class="col-sm-10">
                            <select name="num" id="num" class="form-control">
                                <?php if (isset($_POST['num'])) { ?>
                                    <option value="<?php echo $_POST['num']; ?>"><?php echo $_POST['num']; ?></option>
                                <?php } ?>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="group" class="col-sm-2 col-form-label">กลุ่ม</label>
                        <div class="col-sm-10">
                            <select name="group" id="group" class="form-control">
                                <?php if (isset($_POST['group'])) { ?>
                                    <option value="<?php echo $_POST['group']; ?>"><?php echo $_POST['group']; ?></option>
                                <?php } ?>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="term" class="col-sm-2 col-form-label">เทอม</label>
                        <div class="col-sm-10">
                            <select name="term" id="term" class="form-control">
                                <?php if (isset($_POST['term'])) { ?>
                                    <option value="<?php echo $_POST['term']; ?>"><?php echo $_POST['term']; ?></option>
                                <?php } ?>
                                <option value="1">1</option>
                                <option value="2">2</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10 offset-sm-2">
                            <button type="submit" name="search" class="btn btn-primary">ค้นหา</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>


        <?php if (isset($_POST['search'])) {

            $i = 1;
            $level = $_POST["level"];
            $num = $_POST["num"];
            $group = $_POST["group"];
          //  $year = $_POST["year"];
            $term = $_POST["term"];

        ?>
            <!-- <div class="text-center my-4">
                <button class="btn btn-secondary" onclick="printDiv('print_page')">พิมพ์</button>
            </div> -->
            <div id="print_page" class="table-responsive mt-5">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th colspan="8" class="text-center">
                                <h1>รายชื่อนักเรียนนักศึกษา</h1>
                            </th>
                        </tr>
                        <tr>
                            <th colspan="8" class="text-center">ระดับ <?php if (isset($_POST['level'])) {
                                                                            echo $_POST['level'];
                                                                        } ?><?php if (isset($_POST['num'])) {
                                                                                    echo $_POST['num'];
                                                                                } ?> &nbsp;&nbsp; กลุ่ม <?php if (isset($_POST['group'])) {
                                                                                                            echo $_POST['group'];
                                                                                                        } ?></th>
                        </tr>
                        <tr>
                            <th colspan="8" class="text-center">ภาคเรียนที่ <?php echo $_POST['term']; ?> &nbsp;&nbsp;&nbsp; ปีการศึกษา <?php if (isset($_POST['year'])) {
                                                                                                                                            echo $_POST['year'];
                                                                                                                                        } ?></th>
                        </tr>
                        <tr>
                            <th class="text-center">ลำดับ</th>
                            <th>รหัสประจำตัว</th>
                            <th>ชื่อ - สกุล</th>
                            <th class="text-center">เช็คชื่อ</th>
                            <!-- <th>ลงทะเบียนแก้กิจกรรม</th> -->
                        </tr>
                    </thead>
                    <tbody>


                        <?php

                        foreach ($conn->query("SELECT * FROM tb_student_level ORDER BY student_year DESC LIMIT 1;") as $row1) {

                            $year = $row1["student_year"];

                          //echo $yyear;
                        }


                        foreach ($conn->query("SELECT * FROM tb_member 
                        INNER JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id 
                        WHERE tb_student_level.student_level = '$level' AND tb_student_level.student_year = '$year' AND tb_student_level.student_num = '$num' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year' AND tb_member.member_id = tb_student_level.member_id GROUP BY tb_member.member_id;") as $row) {

                        //    echo $row["member_id"];
                        //    echo $row["student_year"];
                        //    echo $row["student_num"];


                        ?>
                            <tr>
                                <td class="text-center"><?php echo $i++; ?></td>
                                <td><?php echo $row['member_code']; ?></td>
                                <td><?php echo $row['member_title'];
                                    echo $row['member_firstname'];
                                    echo " ";
                                    echo $row['member_lastname'];
                                    ?></td>
                                    <td><input class="form-control" type="checkbox" name="" id=""></td>

                           
                            </tr>
                        <?php } ?>


                    </tbody>
                </table>
            </div>
        <?php } ?>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        function printDiv(divId) {
            var printContents = document.getElementById(divId).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    </script>


</body>

</html>