<?php if (isset($_GET['level'])) {
        $id = $_GET['level']; ?>
        <script>
            $(function() {
                $('#levelModal').modal('show');
            });
        </script>
    <?php } ?>

    <div class="modal fade" id="levelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ฟอร์มเพิ่มข้อมูล</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php foreach ($conn->query("select * from tb_search where search_id ='$id'") as $row) { ?>
                        <h2 class="text-center mb-2">ปีการศึกษา <?php echo $row['search_year']; ?> ภาคเรียนที่ <?php echo $row['search_term']; ?> </h2>
                        <form method="post">
                            <input type="hidden" name="search_id" id="search_id" value="<?php echo $row['search_id']; ?>">
                        <?php } ?>
                        <div class="form-group">
                            <label for="level">ระดับ</label>
                            <select class="form-control" id="search2_type" name="search2_type" required>
                                <option value="">เลือกระดับ</option>
                                <option value="ปวช">ปวช.</option>
                                <option value="ปวส">ปวส.</option>
                                <option value="ปวสม6">ปวส ม.6</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="grade">ชั้นปีที่</label>
                            <select class="form-control" id="search2_rank" name="search2_rank" required>
                                <option value="">เลือกชั้นปี</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="academic_year">กลุ่ม</label>
                            <select class="form-control" id="search2_group" name="search2_group" required>
                                <option value="">เลือกกลุ่ม</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                        <button type="submit" name="insert" class="btn btn-info btn-block">ส่งข้อมูล</button>
                        <button type="button" class="btn btn-danger btn-block mt-3" data-dismiss="modal" aria-label="Close">ยกเลิก</button>
                        </form>
                </div>
            </div>
        </div>
    </div>