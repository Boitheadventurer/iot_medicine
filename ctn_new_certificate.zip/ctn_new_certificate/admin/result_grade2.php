<?php
include '../db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลการศึกษา</title>

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container-custom {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 70%;
            margin: auto;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
            border: none;
            min-width: 120px;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .table td .btn {
            min-width: 80px;
            margin-bottom: 5px;
        }

        .gold {
            background-color: #ffd700;
        }

        .silver {
            background-color: #c0c0c0;
        }

        .bronze {
            background-color: #cd7f32;
        }


        .btn-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }


        @media print {
            @page {
                size: A4;
                margin: 50px 50px 150px 50px;
            }

            body {
                background-color: #fff;
            }

            div {
                page-break-after: always;
            }

            .container-custom {
                width: 100%;
            }

            .btn {
                display: none;
            }

            .btn-container {
                display: none;
            }

            .table {
                .gold {
                    background-color: #ffd700 !important;
                }

                .silver {
                    background-color: #c0c0c0 !important;
                }

                .bronze {
                    background-color: #cd7f32 !important;
                }
            }
        }
    </style>
</head>

<body>
    <div class="container-custom mt-5">
        <div class="btn-container">
            <a type="button" class="btn btn-warning" href="index.php"">กลับ</a>
            <button class=" btn btn-primary" onclick="window.print()"> พิมพ์ <img src="image/print.png" alt="" width="20" height="20"> </button>
        </div>

        <?php
        foreach ($conn->query("SELECT * FROM tb_search 
        INNER JOIN tb_search2 ON tb_search.search_id = tb_search2.search_id WHERE tb_search.search_id = tb_search2.search_id") as $row) {
            $year = $row["search_year"];
            $term = $row["search_term"];
            $group = $row["search2_group"];
            $rank = $row["search2_rank"];
            $type = $row["search2_type"];
        ?>

            <div class="text-center mb-5">
                <h2>สรุปผลผู้มีผลการเรียนดี</h2>
                <h3>ภาคเรียนที่ <?php echo $row['search_term']; ?> ปีการศึกษา <?php echo $row['search_year']; ?></h3>
                <div class="mb-3">
                    <p class="mb-1"><?php echo $row['search2_type']; ?> <?php echo $row['search2_rank']; ?> กลุ่ม <?php echo $row['search2_group']; ?></p>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ลำดับ</th>
                                <th>รหัส</th>
                                <th>ชื่อ</th>
                                <th>นามสกุล</th>
                                <th>เกรด</th>
                                <th>ระดับ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $conn->query("SELECT * FROM tb_member
                            LEFT JOIN tb_grade ON tb_member.member_id = tb_grade.member_id
                            LEFT JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id
                            WHERE tb_grade.grade_year = '$year'
                            AND tb_grade.grade_num = '$rank'
                            AND tb_student_level.student_group = '$group'
                            AND tb_grade.grade_term = '$term'
                            AND tb_grade.grade_level = '$type'");

                            $index = 1;
                            foreach ($stmt as $row_m) {
                                $grade = $row_m['grade_grade'];
                                $medal = '';
                                $medal_class = '';

                                if ($grade >= 3.80) {
                                    $medal = 'เหรียญทอง';
                                    $medal_class = 'gold';
                                } else if ($grade >= 3.40) {
                                    $medal = 'เหรียญเงิน';
                                    $medal_class = 'silver';
                                } else if ($grade >= 3.00) {
                                    $medal = 'เหรียญทองแดง';
                                    $medal_class = 'bronze';
                                } else {
                                    $medal = 'ไม่มีรางวัล';
                                }
                            ?>
                                <tr>
                                    <td><?php echo $index++; ?></td>
                                    <td><?php echo $row_m['member_code']; ?></td>
                                    <td><?php echo $row_m['member_title']; ?> <?php echo $row_m['member_firstname']; ?></td>
                                    <td><?php echo $row_m['member_lastname']; ?></td>
                                    <td><?php echo $grade; ?></td>
                                    <td class="<?php echo $medal_class; ?>"><?php echo $medal; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php } ?>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>

    <!-- Custom Script -->
    <script>
        function toggleForm() {
            var formContainer = document.getElementById("form-container");
            if (formContainer.style.display === "none" || formContainer.style.display === "") {
                formContainer.style.display = "block";
            } else {
                formContainer.style.display = "none";
            }
        }
    </script>
</body>

</html>