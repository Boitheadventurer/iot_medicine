<?php
include '../conn.php'; 
error_reporting(0);
?>
<?php
if (isset($_GET['level'])){
    $level = $_GET['level'];
    $group = $_GET['group'];
    $num = $_GET['num'];
    $year = $_GET['year'];
    $term = $_GET['term'];
    $terms = $_GET['terms'];
    $sumnum = $_GET['sumnum'];
    $preyear = $_GET['preyear'];
    $chkyear = date('Y') + 543 - $year;
        
        if($level == 'ปวช' && $year != $preyear && $sumnum == '3' || $level == 'ปวส' && $year != $preyear && $sumnum == '2'){
                $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                FROM tb_member
                LEFT JOIN tb_student_level
                ON tb_member.member_id = tb_student_level.member_id
                WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year' ORDER BY tb_member.member_code ASC";
                $resultH = $conn->query($sqlH);
                $Headsec = $resultH->fetch_assoc();
                $check_std = $Headsec['member_id'];
        }
        else if($level == 'ปวส' && $chkyear > '1' && $sumnum == '1'){
            $sumnum2 = $sumnum + 1;
            $yearsum = $year + 1;
            $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
            FROM tb_member
            LEFT JOIN tb_student_level
            ON tb_member.member_id = tb_student_level.member_id
            WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$yearsum' ORDER BY tb_member.member_code ASC";
            $resultH = $conn->query($sqlH);
            $Headsec = $resultH->fetch_assoc();
            $check_std = $Headsec['member_id'];
            }
        else if( $level == 'ปวช' && $year != $preyear && $sumnum == '2'){
            $sumnum2 = $sumnum + 1;
            $year2 = $year + 1;
            $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
            FROM tb_member
            LEFT JOIN tb_student_level
            ON tb_member.member_id = tb_student_level.member_id
            WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year2' ORDER BY tb_member.member_code ASC";
            $resultH = $conn->query($sqlH);
            $Headsec = $resultH->fetch_assoc();
            $check_std = $Headsec['member_id'];
         }

         else if( $level == 'ปวช' && $year != $preyear && $sumnum == '1'){
            $yearcheck = date('Y') + 543 - $year;
            if($yearcheck == '1'){
            $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
            FROM tb_member
            LEFT JOIN tb_student_level
            ON tb_member.member_id = tb_student_level.member_id
            WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$num' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$preyear' ORDER BY tb_member.member_code ASC";
            $resultH = $conn->query($sqlH);
            $Headsec = $resultH->fetch_assoc();
            $check_std = $Headsec['member_id'];
            }
            else {
                $sumnum2 = $sumnum + 2;
                $year2 = $year + 2;
                $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                FROM tb_member
                LEFT JOIN tb_student_level
                ON tb_member.member_id = tb_student_level.member_id
                WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year2' ORDER BY tb_member.member_code ASC";
                $resultH = $conn->query($sqlH);
                $Headsec = $resultH->fetch_assoc();
                $check_std = $Headsec['member_id'];
            }
         }

         else if( $level == 'ปวสม6' && $year != $preyear && $sumnum == '1'){
            $yearcheck = date('Y') + 543 - $year;
            if($yearcheck == '1'){
            $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
            FROM tb_member
            LEFT JOIN tb_student_level
            ON tb_member.member_id = tb_student_level.member_id
            WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$num' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$preyear' ORDER BY tb_member.member_code ASC";
            $resultH = $conn->query($sqlH);
            $Headsec = $resultH->fetch_assoc();
            $check_std = $Headsec['member_id'];
            }
            else {
                $sumnum2 = $sumnum + 1;
                $year2 = $year + 1;
                $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                FROM tb_member
                LEFT JOIN tb_student_level
                ON tb_member.member_id = tb_student_level.member_id
                WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year2' ORDER BY tb_member.member_code ASC";
                $resultH = $conn->query($sqlH);
                $Headsec = $resultH->fetch_assoc();
                $check_std = $Headsec['member_id'];
            }
         }
         
        else if( $level == 'ปวสม6' && $year != $preyear && $sumnum == '2'){
            $sumnum2 = $sumnum + 0;
            $year2 = $year + 0;
            $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
            FROM tb_member
            LEFT JOIN tb_student_level
            ON tb_member.member_id = tb_student_level.member_id
            WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year2' ORDER BY tb_member.member_code ASC";
            $resultH = $conn->query($sqlH);
            $Headsec = $resultH->fetch_assoc();
            $check_std = $Headsec['member_id'];
        }

        else {
            $sqlH = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
        FROM tb_member
        LEFT JOIN tb_student_level
        ON tb_member.member_id = tb_student_level.member_id
        WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$num' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$preyear' ORDER BY tb_member.member_code ASC";
        $resultH = $conn->query($sqlH);
        $Headsec = $resultH->fetch_assoc();
        $check_std = $Headsec['member_id'];
        }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Table Example</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background-color: #E7E7E7;
            margin: 0;
            padding-bottom: 100px;
        }

        .navbar-brand img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }

        .nav-link {
            color: #000;
            font-weight: bold;
        }

        .nav-link:hover {
            color: #007bff;
        }

        .welcom_img {
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: auto;
            margin-top: 20px;
        }

        .welcom_img form {
            margin-bottom: 20px;
        }

        .welcom_img table {
            width: 100%;
        }

        .welcom_img td, .welcom_img th {
            padding: 10px;
        }

        .welcom_img select, .welcom_img input[type="text"], .welcom_img input[type="submit"] ,a{
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
        }

        .welcom_img input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }


        .welcom_img input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .footer {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .footer p {
            margin-bottom: 0;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .important-content {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
        }

        .content {
            display: flex;
            flex-direction: column;
            align-items: left;
            text-align: left;
        }
    </style>
</head>

<body>

    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <div class="welcom_img">
                    <form name="chk_activities" action="insert/grade_inn.php" method="post">
                        <div class="table-responsive">
                        <a href="add_level.php?term=<?php echo $terms ?>" class="btn btn-warning mt-2" type="button">กลับ</a>
                            <table class="table table-bordered">
                                <h3 align="center" style="color: black;">บันทึกผลการเรียน นักศึกษา</h3>
                                <tr class = "table-secondary">
                               
                                    <td colspan="5" align="center">
                                    <?php 
                                        if ($check_std == null) { ?>
                                        <span class="btn btn-danger btn-sm">ไม่พบข้อมูล นักศึกษา</span>
                                    <?php } else { ?>
                                        <p style="color: red;">*****กรุณาเลือกข้อมูลให้ตรงกับเทอมที่ต้องการบันทึก*****</p>
                                        ระดับ
                                        <input name="save_level" class="form-control d-inline-block w-auto pe-2" type="text" value="<?php echo $Headsec['student_level'];?>" readonly>
                                        </input>
                                        ชั้นปี
                                        <input name="save_num" class="form-control d-inline-block w-auto pe-2" value="<?php echo $sumnum;?>" readonly>
                                        </input>
                                        ภาคเรียน
                                        <input name="save_term" class="form-control d-inline-block w-auto pe-2" value="<?php echo $term;?>" readonly >
                                        </input>
                                        ปี
                                        <input name="save_year" class="form-control d-inline-block w-auto pe-2" value="<?php echo $year;?>" readonly>
                                        </input>
                                    </td>
                                </tr>
                                <tr>
                                    <th width="5%" align="center">ลำดับ</th>
                                    <th width="15%" align="center">รหัสประจำตัว</th>
                                    <th width="30%" align="center">ชื่อ - สกุล</th>
                                    <th width="10%" align="center">เกรดเทอมนี้</th>
                                    <th width="10%" align="center">เกรดสะสม</th>
                                </tr>
                                <?php
                                if (isset($level) && isset($group)) {
                                if($level == 'ปวช' && $year != $preyear && $sumnum == '3'){ 
                                        $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                        FROM tb_member
                                        LEFT JOIN tb_student_level
                                        ON tb_member.member_id = tb_student_level.member_id
                                        WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year' ORDER BY tb_member.member_code ASC";
                                        $result = $conn->query($sql);
    
                                }
                                else if( $level == 'ปวส' && $year != $preyear && $sumnum == '2'){ 
                                        $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                        FROM tb_member
                                        LEFT JOIN tb_student_level
                                        ON tb_member.member_id = tb_student_level.member_id
                                        WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year' ORDER BY tb_member.member_code ASC";
                                        $result = $conn->query($sql);
                                }
                                else if($level == 'ปวส' && $chkyear > '1' && $sumnum == '1'){
                                    $sumnum2 = $sumnum + 1;
                                    $yearsum = $year + 1;
                                    $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                    FROM tb_member
                                    LEFT JOIN tb_student_level
                                    ON tb_member.member_id = tb_student_level.member_id
                                    WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$yearsum' ORDER BY tb_member.member_code ASC";
                                    $result = $conn->query($sql);
                                    }
                                else if( $level == 'ปวช' && $year != $preyear && $sumnum == '2'){ 
                                    $sumnum2 = $sumnum + 1;
                                    $year2 = $year + 1;
                                    $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                    FROM tb_member
                                    LEFT JOIN tb_student_level
                                    ON tb_member.member_id = tb_student_level.member_id
                                    WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year2' ORDER BY tb_member.member_code ASC";
                                    $result = $conn->query($sql);
                            }
                            else if( $level == 'ปวช' && $year != $preyear && $sumnum == '1'){ 
                                $yearcheck = date('Y') + 543 - $year;
                                if($yearcheck == '1'){
                                    $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                    FROM tb_member
                                    LEFT JOIN tb_student_level
                                    ON tb_member.member_id = tb_student_level.member_id
                                    WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$num' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$preyear' ORDER BY tb_member.member_code ASC";
                                    $result = $conn->query($sql);
                                }else {
                                    $sumnum2 = $sumnum + 2;
                                    $year2 = $year + 2;
                                    $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                    FROM tb_member
                                    LEFT JOIN tb_student_level
                                    ON tb_member.member_id = tb_student_level.member_id
                                    WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year2' ORDER BY tb_member.member_code ASC";
                                    $result = $conn->query($sql);
                                }
                            }
                            else if( $level == 'ปวสม6' && $year != $preyear && $sumnum == '1'){
                                $sumnum2 = $sumnum + 1;
                                $year2 = $year + 1;
                                $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                FROM tb_member
                                LEFT JOIN tb_student_level
                                ON tb_member.member_id = tb_student_level.member_id
                                WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year2' ORDER BY tb_member.member_code ASC";
                                $result = $conn->query($sql);
                            }

                            else if( $level == 'ปวสม6' && $year != $preyear && $sumnum == '2'){
                                $sumnum2 = $sumnum + 0;
                                $year2 = $year + 0;
                                $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                FROM tb_member
                                LEFT JOIN tb_student_level
                                ON tb_member.member_id = tb_student_level.member_id
                                WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum2' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year2' ORDER BY tb_member.member_code ASC";
                                $result = $conn->query($sql);
                            }

                            else if( $level == 'ปวสม6' && $year != $preyear && $sumnum == '3'){
                                $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                FROM tb_member
                                LEFT JOIN tb_student_level
                                ON tb_member.member_id = tb_student_level.member_id
                                WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$sumnum' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$year' ORDER BY tb_member.member_code ASC";
                                $result = $conn->query($sql);
                            }

                            else{ 
                                    $sql = "SELECT tb_member.member_id,tb_member.member_code,tb_member.member_title,tb_member.member_firstname,tb_member.member_lastname,tb_student_level.student_level,tb_student_level.student_num,tb_student_level.student_group,tb_student_level.student_year
                                    FROM tb_member
                                    LEFT JOIN tb_student_level
                                    ON tb_member.member_id = tb_student_level.member_id
                                    WHERE tb_member.member_firstname != '' AND tb_student_level.student_level = '$level' AND tb_student_level.student_num = '$num' AND tb_student_level.student_group = '$group' AND tb_student_level.student_year = '$preyear' ORDER BY tb_member.member_code ASC";
                                    $result = $conn->query($sql);
                            }
                                

                                    if ($result->num_rows >= 1) {
                                        $num_rows = mysqli_num_rows($result);
                                        for ($i=0; $i<$num_rows; $i++){
                                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td hidden>
                                        <input type="text" name="terms" value="<?php echo $terms ?>" />
                                        <input type="text" name="member_id[]" value="<?php echo $row['member_id']; ?>" />
                                    </td>
                                    <td><?php echo $i+1; ?></td>
                                    <td><?php echo $row['member_code']; ?></td>
                                    <td><?php echo $row['member_title']; echo"   "; echo $row['member_firstname']; echo"   "; echo $row['member_lastname']; ?></td>
                                    <td align="center">
                                        <input type="text" name="this_term[]" class="form-control" placeholder="0.00" required value=""/>
                                    </td>
                                    <td align="center">
                                        <input type="text" name="sum_term[]" class="form-control" placeholder="0.00" required value=""/>
                                    </td>
                                </tr>
                                <?php break;}}}} ?>
                                <tr>
                                    <td colspan="5" align="center" class="table">
                                        <input type="submit" class="btn btn-lg btn-primary" name="submit" value="บันทึก" />
                                        <a href="add_level.php?term=<?php echo $terms ?>" class="btn btn-lg btn-warning" type="button">กลับ</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </form>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></script>
</body>

</html>
