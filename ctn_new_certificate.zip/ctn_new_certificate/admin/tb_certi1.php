<body>
    <div class="container shadow-sm bg-light rounded p-4 mt-4">
    <h1 class="mb-4">เกียรติบัตรเชิดชูเกียรติ</h1>
        <div class="table-responsive">
        <table class="table table-striped table-bordered bg-light" id="tb-certi1">
            <thead class="text-center">
                <tr>
                    <th> Id </th>
                    <th> ชื่อกิจกรรม </th>
                    <th> เพิ่มผลการเรียน </th>
                    <th> สร้างเกียรติบัตรเเละปริ้นท์ </th>
                </tr>
            </thead>
            <tbody class="text-center">
                <tr>
                    <td> CTN01 </td>
                    <td>โครงการเชิดชูเกียรติผู้มีความประพฤติดีระดับภาคเรียน</td>
                    <td> <a type="button" class="btn btn-info" href="add_term.php"><i class="ri-file-add-line"></i> เพิ่มผลการเรียน </a></td> 
                    <td> <a type="button" class="btn btn-info" href="certificate1.php?id=1"><i class="ri-printer-line"></i> สร้างเกียรติบัตร & พิมพ์</a> </td>
                </tr>
                <tr>
                    <td> CTN02 </td>
                    <td>โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีระดับภาคเรียน</td>
                    <td> <a type="button" class="btn btn-info" href="save-grade.php"><i class="ri-file-add-line"></i> เพิ่มผลการเรียน </a></td> 
                    <td> <a type="button" class="btn btn-info" href="certificate2.php?id=2"><i class="ri-printer-line"></i> สร้างเกียรติบัตร & พิมพ์</a> </td>
                </tr>
                <tr>
                    <td> CTN03 </td>
                    <td>โครงการเชิดชูเกียรติผู้มีความประพฤติดีระดับปีการศึกษา</td>
                    <td> <a type="button" class="btn btn-info" href="save-grade.php"><i class="ri-file-add-line"></i> เพิ่มผลการเรียน </a></td> 
                    <td> <a type="button" class="btn btn-info" href="certificate3.php?id=3"><i class="ri-printer-line"></i> สร้างเกียรติบัตร & พิมพ์</a> </td>
                </tr>
                <tr>
                    <td> CTN04 </td>
                    <td>โครงการเชิดชูเกียรติผู้มีมีผลการเรียนดีระดับปีการศึกษา</td>
                    <td> <a type="button" class="btn btn-info" href="save-grade.php"><i class="ri-file-add-line"></i> เพิ่มผลการเรียน </a></td> 
                    <td> <a type="button" class="btn btn-info" href="certificate4.php?id=4"><i class="ri-printer-line"></i> สร้างเกียรติบัตร & พิมพ์</a> </td>
                </tr>
            </tbody>
        </table>
        </div>
    </div>
    <script src="tb_script.js"></script>
</body>