<body>
    <div class="container shadow-sm bg-light rounded p-4 my-4">
        <h1>เกียรติบัตรกิจกรรมกลาง</h1>
        <a class="btn btn-info text-light mb-2 g" data-bs-toggle="modal" data-bs-target="#subModal" type="button"><i class="ri-file-add-line"></i> เพิ่มกิจกรรม</a>
        <div class="table-responsive">
        <table class="table table-striped table-bordered bg-light" id="tb-certi1">
            <thead class="text-center">
                <tr>
                    <th> Id</th>
                    <th> ชื่อกิจกรรม </th>
                    <th> วันที่เริ่มกิจกรรม</th>
                    <th> วันหมดกิจกรรม</th>
                    <th class="w-50"> ดำเนินการ</th>
                </tr>
            </thead>
            <tbody class="text-center">
            <?php
                include '../conn.php';

                $table = mysqli_query($conn, 'SELECT * FROM certi_tb ');
                while ($row = mysqli_fetch_array($table)) { ?>
                <tr>
                    <td> <?php echo $row['id_certificate']; ?> </td>
                    <td> <?php echo $row['detail']; ?> </td>
                    <td> <?php echo $row['datestart']; ?> </td>
                    <td> <?php echo $row['dateend']; ?> </td>
                    <td> 
                        <a type="button" class="btn btn-info" href="subcerti.php?id=<?php echo $row['id_certificate']; ?>"><i class="ri-printer-line"></i> สร้างเกียรติบัตร & พิมพ์</a>
                        <a type="button" class="btn btn-warning" href="member_check.php?id=<?php echo $row['id_certificate']; ?>"><i class="ri-file-chart-line"></i> เช็คชื่อ</a>
                        <a type="button" class="btn btn-warning" href="index.php?id=<?php echo $row['id_certificate']; ?>"><i class="ri-edit-2-fill"></i> เเก้ไข</a>
                        <a type="button" class="btn btn-danger text-light delete-btn" data-id="<?php echo $row['id_certificate']; ?>" data-id2="<?php echo $row['detail']; ?>"><i class="ri-close-circle-line"></i> ลบ</a>
                    </td>
                </tr>
                <?php  } ?>
            </tbody>
        </table>
        </div>
    </div>

    <script src="tb_script.js"></script>
    <!--------------------Modal เพิ่มกิจกรรมกลาง------------------->
 <div class="modal fade" id="subModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูล กิจกรรมกลาง</h5>
                </div>
                <div class="modal-body">
                    <form method="post" action="">
                        <div class="form-group">
                            <label for="level">ชื่อกิจกรรม</label>
                            <input type="text" class="form-control" name="detail" required>
                        </div>
                        <div class="form-group">
                            <label for="grade">วันที่เริ่มกิจกรรม</label>
                            <input type="date" class="form-control" name="datestart" required>
                        </div>
                        <div class="form-group">
                            <label for="grade">จบกิจกรรม</label>
                            <input type="date" class="form-control" name="dateend" required>
                        </div>
                        <button type="submit" name="subin" class="btn btn-info btn-block">บันทึกข้อมูล</button>
                        <button type="button" class="btn btn-secondary btn-block" data-bs-dismiss="modal" aria-label="Close">ยกเลิก</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<!----Sweet Alert Del--->
 <script>
        $('.delete-btn').click(function(e){
            var Id= $(this).data('id');
            var de= $(this).data('id2');
            e.preventDefault();
            deleteConfirm(Id,de);
        })

        function deleteConfirm(Id,de){
            Swal.fire({
                title:'คุณกำลังจะลบข้อมูล',
                text:'คุณต้องการลบข้อมูล '+de+' หรือไม่?',  /* คุณต้องการลบข้อมูล (ปวช) ชั้นปี (3) กลุ่ม (1)*/
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#E85050',
                cancelButtonText: 'ยกเลิก',
                confirmButtonText: 'ใช่ ลบเลย',
                showLoaderOnConfirm: true,
                preConfirm: function(){
                    return new Promise(function(resolve){
                        $.ajax({
                            url: 'index.php',
                            type: 'GET',
                            data: 'delsub='+ Id,
                        })
                        .done(function(){
                            Swal.fire({
                                title: 'สำเร็จ',
                                text: 'ลบข้อมูลสำเร็จ',
                                icon: 'success'
                            }).then(()=> {
                                document.location.href = 'index.php';
                            })
                        })
                        .fail(function(){
                            Swal.fire('เกิดข้อผิดพลาด','ไม่สามารถลบข้อมูลได้','error');
                            window.location.reload();
                        })
                }) 
                }
            });
        }
</script>

<!------- insert Sub certi--------->
<?php
if(isset($_POST['subin'])){
$detail = $_POST['detail'];
$datestart = $_POST['datestart'];
$dateend = $_POST['dateend'];

$result = mysqli_query($conn, "INSERT INTO certi_tb( detail, datestart, dateend, certi_license_tb) VALUES ( '$detail', '$datestart', '$dateend','')");

echo "<script>alert('บันทึกข้อมูลกิจกกรรมสำเร็จ');
           location.href='index.php'; 
   </script>";

}
?>


<!--------------------Modal เเก้ไขกิจกรรมกลาง------------------->

<?php if (isset($_GET['id'])) {
    $subid = $_GET['id'];
    $sub = "SELECT * FROM certi_tb WHERE id_certificate = '$subid'";
    $result_sub = $conn->query($sub);
    $row_sub = $result_sub->fetch_assoc();
    $subn = $row_sub['detail'];
    $subs = $row_sub['datestart'];
    $sube = $row_sub['dateend'];
    ?>
    <script>
        $(function() {
            $('#editSub').modal('show');
        });
    </script>
<?php } ?>

<div class="modal fade" id="editSub" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">เเก้ข้อมูล กิจกรรมกลาง</h5>
            </div>
            <div class="modal-body">
                <form method="post" action="">
                    <input type="text" class="form-control" name="subid" value="<?php echo $subid ?>" required hidden>
                    <div class="form-group">
                        <label for="level">ชื่อกิจกรรม</label>
                        <input type="text" class="form-control" name="detail" value="<?php echo $subn ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="grade">วันที่เริ่มกิจกรรม</label>
                        <input type="date" class="form-control" name="datestart" value="<?php echo $subs ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="grade">จบกิจกรรม</label>
                        <input type="date" class="form-control" name="dateend" value="<?php echo $sube ?>" required>
                    </div>
                    <button type="submit" name="subedit" class="btn btn-warning btn-block">บันทึกการแก้ไข</button>
                    <button type="button" class="btn btn-secondary btn-block" data-bs-dismiss="modal" aria-label="Close">ยกเลิก</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!------- edit Sub certi--------->
    <?php
        if (isset($_POST['subedit'])) {
        $id = $_POST['subid'];
        $detail = $_POST['detail'];
        $datestart = $_POST['datestart'];
        $dateend = $_POST['dateend'];

        $result = mysqli_query($conn, "UPDATE certi_tb SET detail = '$detail', datestart = '$datestart', dateend = '$dateend' WHERE id_certificate = '$id'");
        
        echo "<script>alert('เเก้ไขข้อมูลกิจกกรรมสำเร็จ');
            location.href='index.php'; 
            </script>";
    }
    ?>

<!----- Del subcerti-------->
<?php 

if (isset($_GET['delsub'])) {
    $id = $_GET['delsub'];
    $result = mysqli_query($conn, "DELETE FROM certi_tb WHERE id_certificate = '$id'");
    $resul2 = mysqli_query($conn, "DELETE FROM certi_license_tb WHERE id = '$id'");

}
?>


</body>