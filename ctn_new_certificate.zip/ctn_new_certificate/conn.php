<?php
     $servername = "localhost";
     $username = "root";
     $password = "";
     $dbname = "ctnphrae_certificate";

    //$servername = "localhost";
    //$username = "ctnphrae_ctn";
    //$password = "ctnphrae@2020";
    //$dbname = "ctnphrae_ctn";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }else{
        // echo 'success';
    }
?>