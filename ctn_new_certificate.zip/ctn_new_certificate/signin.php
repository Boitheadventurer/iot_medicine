<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            font-family: 'Arial', sans-serif;
        }

        .card {
            border-radius: 15px;
        }

        .card-body {
            padding: 2rem;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        .card-header img {
            width: 50px;
            height: 50px;
        }

        .card-header {
            text-align: center;
            background-color: white;
            border: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-4 p-3 shadow">
                    <div class="card-header mt-3">
                        <img src="image/CTN.jpg" alt="CTN Logo" class="rounded img-fluid">
                        <h3 class="mt-3">เข้าสู่ระบบ</h3>
                    </div>
                    <div class="card-body">
                        <form action="signin_db.php" method="post">
                            <?php if (isset($_SESSION['error'])) { ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php
                                    echo $_SESSION['error'];
                                    unset($_SESSION['error']);
                                    ?>
                                </div>
                            <?php } ?>
                            <?php if (isset($_SESSION['success'])) { ?>
                                <div class="alert alert-success" role="alert">
                                    <?php
                                    echo $_SESSION['success'];
                                    unset($_SESSION['success']);
                                    ?>
                                </div>
                            <?php } ?>
                            <div class="mb-3">
                                <label for="member_code" class="form-label">รหัสนักศึกษา</label>
                                <input type="text" class="form-control" id="member_code" name="member_code" placeholder="Username" required>
                            </div>
                            <div class="mb-3">
                                <label for="member_password" class="form-label">รหัสผ่าน</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="member_password" name="member_password" placeholder="Password" required>
                                    <button class="btn btn-outline-secondary" type="button" id="password-toggle-btn"><img src="image/eye-slash.svg" alt=""></i></button>
                                </div>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" name="signin" class="btn btn-primary">เข้าสู่ระบบ</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        document.getElementById('password-toggle-btn').addEventListener('click', function() {
            const passwordField = document.getElementById('member_password');
            const currentType = passwordField.getAttribute('type');
            const newType = currentType === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', newType);
            // Change button icon
            this.innerHTML = currentType === 'password' ? '<img src="image/eye.svg" alt="">' : '<img src="image/eye-slash.svg" alt="">';
        });
    </script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>