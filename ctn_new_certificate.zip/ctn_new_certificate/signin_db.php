<?php 

    session_start();
    require_once 'config/db.php';

    if (isset($_POST['signin'])) {
        $member_code = $_POST['member_code'];
        $member_password = $_POST['member_password'];

      
        if (empty($member_code)) {
            $_SESSION['error'] = 'กรุณากรอกรหัสนะกศึกษา';
            header("location: signin.php");
        } else if (empty($member_password)) {
            $_SESSION['error'] = 'กรุณากรอกรหัสผ่าน';
            header("location: signin.php");
        } else if (strlen($_POST['member_code']) > 20 || strlen($_POST['member_code']) < 5) {
            $_SESSION['error'] = 'รหัสผ่านต้องมีความยาว 11 ตัวอักษร';
            header("location: signin.php");
        } else {
            try {

                $check_data = $conn->prepare("SELECT * FROM tb_member WHERE member_code = :member_code");
                $check_data->bindParam(":member_code", $member_code);
                $check_data->execute();
                $row = $check_data->fetch(PDO::FETCH_ASSOC);

                if ($check_data->rowCount() > 0) {

                    if ($member_code == $row['member_code']) {
                        if ($member_password == $row['member_code']) {
                            if ($row['member_showpass'] == 'admin') {
                                $_SESSION['admin_login'] = $row['member_id'];
                                header("location: admin/index.php");
                            } else {
                                $_SESSION['code'] = $row['member_code'];
                                $_SESSION['user_login'] = $row['member_id'];
                                header("location: User/index.php");
                            }
                        } else {
                            $_SESSION['error'] = 'รหัสผ่านผิด';
                            header("location: signin.php");
                        }
                    } else {
                        $_SESSION['error'] = 'อีเมลผิด';
                        header("location: signin.php");
                    }
                } else {
                    $_SESSION['error'] = "ไม่มีข้อมูลในระบบ";
                    header("location: signin.php");
                }

            } catch(PDOException $e) {
                echo $e->getMessage();
            }
        }
    }


?>