<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/idcertificate.css?v=<?php echo filemtime('css/idcertificate.css'); ?>" />
    <link rel="stylesheet" href="css/print.css?v=<?php echo filemtime('css/print.css'); ?>" />
    <title>Document</title>


</head>

<body>
    <div class="connan">
        <?php
        include '../dbconnect.php';
        $id = $_GET['id'];
        $table = mysqli_query($conn, "SELECT * FROM certi_license_tb2 WHERE id = '$id'");
        $row = mysqli_fetch_array($table);
        ?>
        <?php
        session_start();
        $sql = "SELECT * FROM tb_member INNER JOIN tb_student_level ON tb_member.member_id = tb_student_level.member_id where member_code = '$_SESSION[username]'";
        $result = $conn->query($sql);
        $row2 = $result->fetch_array();
        $acc_term = $_GET['acc_term'];
        $acc_year = $_GET['acc_year'];
        ?>
        <header style="display: none;">
            <form action="data/data_ajax/imagupload2.php?id=<?php echo $id ?>" method="POST" enctype="multipart/form-data">
                <div class="menu settings">
                    <ul class="menu-list">
                        <h1>theme</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>theme</h3>
                                <div class="input_type_file">
                                    <input name="theme" id="theme" type="file">
                                    <a id="reTheme" data-id="reTheme" data-target="<?php echo $id ?>">ลบ</a>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <ul class="menu-list">
                        <h1>Logo</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>Logo1</h3>
                                <div class="input_type_file">
                                    <input name="logo1" id="logo1" type="file">
                                    <a id="reLogo1" data-id="reLogo1" data-target="<?php echo $id ?>">ลบ</a>
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>Logo2</h3>
                                <div class="input_type_file">
                                    <input name="logo2" id="logo2" type="file">
                                    <a id="reLogo2" data-id="reLogo2" data-target="<?php echo $id ?>">ลบ</a>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <ul class="menu-list">
                        <h1>ข้อมุลเกียรติบัตร</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>มอบให้ในนาม</h3>
                                <input type="text" oninput="preview1()" name="text1" id="text1" data-target="text1" value="<?php echo $row['text1']; ?>">
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input" style="display: none;">
                                <h3>ชื่อนามสกุล</h3>
                                <div class="menu-input">
                                    <input type="text" style="display: none;" oninput="previewname_MR()" id="textname_MR" name="textname_MR" placeholder="คำนำ" value="<?php echo $row2['member_title']; ?>">
                                    <input type="text" style="display: none;" oninput="previewname_f()" id="textname_f" name="textname_f" placeholder="ชื่อ" value="<?php echo $row2['member_firstname']; ?>">
                                    <input type="text" style="display: none;" oninput="previewname_l()" id="textname_l" name="textname_l" placeholder="นามสกุล" value="<?php echo $row2['member_lastname']; ?>">
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ลักษนะความประพฤติ</h3>
                                <input type="text" oninput="previewnature()" id="textnature" name="textnature" placeholder="ลักษนะความประพฤติ" value="<?php echo $row['textnature']; ?>">
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ภาคเรียน</h3>
                                <input type="number" oninput="previewterm()" id="textterm" name="textterm" placeholder="ภาคเรียน" value="<?php echo $acc_term ?>">
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ปีการศึกษา</h3>
                                <input type="number" oninput="previewyear()" id="textyear" name="textyear" placeholder="ปีการศึกษา" value="<?php echo $acc_year ?>">
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>วันส่งมอบเกียรติบัตร</h3>
                                <div class="menu-input">
                                    <?php
                                    echo "<meta charset='utf-8'>";
                            
                                        //วันภาษาไทย
                                        $ThDay = array("อาทิตย์", "จันทร์", "อังคาร", "พุธ", "พฤหัส", "ศุกร์", "เสาร์");
                                        //เดือนภาษาไทย
                                        $ThMonth = array("มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฏาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม");

                                        //กำหนดคุณสมบัติ
                                        $week = date("w"); // ค่าวันในสัปดาห์ (0-6)
                                        $months = date("m") - 1; // ค่าเดือน (1-12)
                                        $day = date("d"); // ค่าวันที่(1-31)
                                        $years = date("Y") + 543; // ค่า ค.ศ.บวก 543 ทำให้เป็น ค.ศ.

                                    ?>
                                    <input type="number" oninput="previewD()" id="textD" name="textD" placeholder="วันที่" value="<?php echo $day; ?>">
                                    <input type="text" oninput="previewM()" id="textM" name="textM" placeholder="เดือน" value="<?php echo $ThMonth[$months]; ?>">
                                    <input type="number" oninput="previewY()" id="textY" name="textY" placeholder="ปี" value="<?php echo $years; ?>">
                                </div>
                            </div>
                        </li>
                    </ul>
                    <ul class="menu-list">
                        <h1>ลายเซ็น</h1>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ลายเซ็นที่1</h3>
                                <div class="menu-input">
                                    <div class="input_type_file">
                                        <input type="file" id="signature_image_1" name="signature_image_1" placeholder="รูปลายเซ็น">
                                        <a id="resignature_image_1" data-id="resignature_image_1" data-target="<?php echo $id ?>">ลบ</a>
                                    </div>
                                    <input type="text" oninput="text_signature_1()" id="signature_1" name="signature_1" placeholder="ชื่อเจ้าของลายเซ็น" value="<?php echo $row['signature_1']; ?>">
                                    <input type="text" oninput="text_signature_po1()" id="signature_po1" name="signature_po1" placeholder="ตำแหน่ง" value="<?php echo $row['signature_po1']; ?>">
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ลายเซ็นที่2</h3>
                                <div class="menu-input">
                                    <div class="input_type_file">
                                        <input type="file" id="signature_image_2" name="signature_image_2" placeholder="รูปลายเซ็น">
                                        <a id="resignature_image_2" data-id="resignature_image_2" data-target="<?php echo $id ?>">ลบ</a>
                                    </div>
                                    <input type="text" oninput="text_signature_2()" id="signature_2" name="signature_2" placeholder="ชื่อเจ้าของลายเซ็น" value="<?php echo $row['signature_2']; ?>">
                                    <input type="text" oninput="text_signature_po2()" id="signature_po2" name="signature_po2" placeholder="ตำแหน่ง" value="<?php echo $row['signature_po2']; ?>">
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <h3>ลายเซ็นที่3</h3>
                                <div class="menu-input">
                                    <div class="input_type_file">
                                        <input type="file" id="signature_image_3" name="signature_image_3" placeholder="รูปลายเซ็น">
                                        <a id="resignature_image_3" data-id="resignature_image_3" data-target="<?php echo $id ?>">ลบ</a>
                                    </div>
                                    <input type="text" oninput="text_signature_3()" id="signature_3" name="signature_3" placeholder="ชื่อเจ้าของลายเซ็น" value="<?php echo $row['signature_3']; ?>">
                                    <input type="text" oninput="text_signature_po3()" id="signature_po3" name="signature_po3" placeholder="ตำแหน่ง" value="<?php echo $row['signature_po3']; ?>">
                                </div>
                            </div>
                        </li>
                        <li class="menu-item">
                            <div class="menu-input">
                                <button type="submit" name="submit" id="save_certificate" class="button" data-id="<?php echo $id ?>">Save Certificate</button>
                                <a class="button" href="index.php"><b>กลับ</b></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </form>
        </header>
        <main>
            <div class="layout">
                <div class="page">
                    <div id="print-form">
                        <div class="form-img">
                            <div class="background" id="background">
                                <?php
                                if ($row['theme'] == '') { ?>
                                    <img src="../theme/Illustration2.png" alt="">
                                <?php } else { ?>
                                    <img src="../theme/<?php echo $row['theme'] ?>" alt="">
                                <?php } ?>
                            </div>
                            <div class="print_certificate">
                                <div class="print_certificate_head" id="print_certificate_head">
                                    <div class="image_Logo" id="Logo1">
                                        <?php
                                        if ($row['logo1'] == '') { ?>

                                        <?php } else { ?>
                                            <img src="../logo/<?php echo $row['logo1'] ?>" alt="" style="margin: 0 5px;">
                                        <?php } ?>
                                    </div>
                                    <div class="image_Logo" id="Logo2">
                                        <?php
                                        if ($row['logo2'] == '') { ?>

                                        <?php } else { ?>
                                            <img src="../logo/<?php echo $row['logo2'] ?>" alt="" style="margin: 0 5px;">
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="print_certificate_body">
                                    <div class="text" name="text" id="preview1"></div>
                                    <div class="text" name="text">มอบเกียรติบัตรฉบับนี้ให้ไว้เพื่อแสดงว่า</div>
                                    <div class="name_MR_F_L">
                                        <div class="text" name="text" id="previewname_MR"></div>
                                        <div class="text" name="text" id="previewname_f"></div>
                                        <div class="text" name="text" id="previewname_l"></div>
                                    </div>
                                    <div class="text" name="text" id="previewnature"></div>
                                    <div class="term_year">
                                        <div class="text" name="text">ภาคเรียนที่</div>
                                        <div class="text" name="text" id="previewterm"></div>
                                        <div class="text" name="text">ประจำปีการศึกษา</div>
                                        <div class="text" name="text" id="previewyear"></div>
                                    </div>
                                    <div class="text" name="text">ขอแสดงความชื่นชมและจงรักษาเกียรติประวัตินี้ตลอดไป</div>
                                    <div class="termD_M_Y">
                                        <div class="text" name="text">ให้ไว้ ณ วันที่</div>
                                        <div class="text" name="text" id="previewD"></div>
                                        <div class="text" name="text">เดือน</div>
                                        <div class="text" name="text" id="previewM"></div>
                                        <div class="text" name="text">พ.ศ.</div>
                                        <div class="text" name="text" id="previewY"></div>
                                    </div>
                                </div>
                                <div class="print_certificate_end">
                                    <div class="signature">
                                        <div class="signature_t_i">
                                            <div id="image_signature_1" class="image_signature">
                                                <?php
                                                if ($row['signature_image_1'] == '') { ?>

                                                <?php } else { ?>
                                                    <img id="image_1" src="../image_signature/<?php echo $row['signature_image_1'] ?>" alt="" style="margin: 0 6rem;">
                                                <?php } ?>
                                            </div>
                                            <div id="text_signature_1" class="text_signature"></div>
                                            <div id="text_signature_po1" class="text_signature"></div>
                                        </div>
                                        <div class="signature_t_i">
                                            <div id="image_signature_2" class="image_signature">
                                                <?php
                                                if ($row['signature_image_2'] == '') { ?>

                                                <?php } else { ?>
                                                    <img id="image_2" src="../image_signature/<?php echo $row['signature_image_2'] ?>" alt="" style="margin: 0 6rem;">
                                                <?php } ?>
                                            </div>
                                            <div id="text_signature_2" class="text_signature"></div>
                                            <div id="text_signature_po2" class="text_signature"></div>
                                        </div>
                                        <div class="signature_t_i">
                                            <div id="image_signature_3" class="image_signature">
                                                <?php
                                                if ($row['signature_image_3'] == '') { ?>

                                                <?php } else { ?>
                                                    <img id="image_3" src="../image_signature/<?php echo $row['signature_image_3'] ?>" alt="" style="margin: 0 6rem;">
                                                <?php } ?>
                                            </div>
                                            <div id="text_signature_3" class="text_signature"></div>
                                            <div id="text_signature_po3" class="text_signature"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <div class="container_button">
            <div class="btn"><a href="index.php"><i class="fi fi-rr-angle-left"></i>กลับ</a></div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>
    <script src="js/idcertificate2.js?v=<?php echo filemtime('js/idcertificate2.js'); ?>"></script>
    <script>
        $(document).ready(function() {
            const areaToPrint = document.getElementById('print-form');
            areaToPrint.addEventListener('click', function() {
                print();
            });
        });
    </script>
</body>

</html>