<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: signin.php');
    exit();
}

if (isset($_SESSION['user_login'])) {
    $member_id = $_SESSION['user_login'];
    $stmt = $conn->prepare("SELECT * FROM tb_member WHERE member_id = :member_id");
    $stmt->bindParam(':member_id', $member_id, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .profile-header {
            display: flex;
            align-items: stretch;
            margin-bottom: 20px;
            gap: 20px;
            /* ช่องว่างระหว่าง div ต่างๆ */
        }


        .profile-info,
        .select-certificate {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .profile-info {
            flex: 1;
        }

        .profile-info p {
            margin-bottom: 5px;
            margin-left: 5px;
        }

        .select-certificate {
            flex: 3;
            display: flex;
            flex-direction: row;
            /* เรียงลิงค์ในแนวนอน */
            gap: 10px;
            /* ช่องว่างระหว่างลิงค์ใน select-certificate */
            align-items: center;
        }

        .select-certificate a {
            text-decoration: none;
            color: #007bff;
        }

        .table-responsive {
            margin-top: 30px;
        }

        .table-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #dee2e6;
        }

        .table-row:nth-child(even) {
            background-color: #f8f9fa;
        }

        .table-row .col {
            flex: 1;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="profile-header">
            <div class="profile-info">
                <p>ชื่อ: <?php echo $row['member_firstname'] . ' ' . $row['member_lastname']; ?></p>
                <p>รหัส: <?php echo $row['member_code']; ?></p>
            </div>
            <div class="select-certificate">
                <a href="#" class="btn btn-outline-primary" onclick="toggleTable()">ผลการเรียนดี</a>
                <a href="#" class="btn btn-outline-primary">ประพฤติดี</a>
                <a href="#" class="btn btn-outline-primary">อื่นๆ</a>
            </div>

        </div>

        <div class="table-responsive mt-5"  id="gradeTable" style="display: none;">
            <h2>เกียรติบัตรโครงการเชิดชูเกียรติผู้มีผลการเรียนดีต่อภาคเรียน</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>ID</span>
                    <span>ชื่อกิจกรรม</span>
                    <span>PRINT</span>
                </li>
                <?php
                $grade = $conn->query("SELECT * FROM tb_member LEFT JOIN tb_grade ON tb_member.member_id = tb_grade.member_id RIGHT JOIN tb_student_level ON tb_grade.member_id = tb_student_level.member_id WHERE tb_member.member_code = '$_SESSION[username]'");
                while ($grade_grade = $grade->fetch(PDO::FETCH_ASSOC)) {
                    if ($grade_grade['grade_grade'] >= 3.00) { ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>CTN02</span>
                            <span>โครงการเชิดชูเกียรติผู้มีผลการเรียนดีต่อภาคเรียน <?php echo $grade_grade['grade_term']; ?>/<?php echo $grade_grade['grade_year']; ?></span>
                            <a type="button" class="btn btn-primary" href="idcertificate3.php?id=2&grade_term=<?php echo $grade_grade['grade_term']; ?>&grade_year=<?php echo $grade_grade['grade_year']; ?>&grade=<?php echo $grade_grade['grade_grade']; ?>">Print</a>
                        </li>
                    <?php } else { ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center bg-danger text-white">
                            <span>CTN02</span>
                            <span>โครงการเชิดชูเกียรติผู้มีผลการเรียนดีต่อภาคเรียน <?php echo $grade_grade['grade_term']; ?>/<?php echo $grade_grade['grade_year']; ?></span>
                            <a type="button" class="btn btn-primary" href="" style="display: none;">Print</a>
                        </li>
                    <?php } ?>
                <?php } ?>
            </ul>
        </div>
    </div>



    <script>
        function toggleTable() {
            var table = document.getElementById("gradeTable");
            if (table.style.display === "none") {
                table.style.display = "block";
            } else {
                table.style.display = "none";
            }
        }
    </script>


    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>