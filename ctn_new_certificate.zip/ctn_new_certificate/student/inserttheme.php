<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>COMPUTER TECHNIQUE</h1>
    <h3>Project</h3>

    <div class="date">
        <input value="<?php echo date('Y-m-d h:i:sa'); ?>">
    </div>
    <div class="insights">
        <!-- =======  =======  =======  =======  =======  =======  -->
        <div class="sales">
            <!-- icon -->

            <!-- icon -->
            <div class="middle">
                <div class="left">
                    <h2>เพิ่มธีม</h2>
                </div>
                <div class="graphBox">
                    <form action="../Admin/data/data_ajax/Uploadimgtheme.php" method="POST" enctype="multipart/form-data">
                        <label>
                            <input class="custom-file-input streched-link" name="file" type="file" accept="image/gif, image/jpeg, image/png">
                        </label>
                        <p class="small mb-0 mt-2"><b>Note : </b> Only JPG, JPEG, PNG & GIF files are allowe to uoload</p>
                        <div class="button">
                            <input type="submit" name="submit" value="Upload">
                        </div>
                    </form>
                </div>
                <div class="number">
                    <p></p>
                </div>
            </div>
            <small class="text-muted"></small>
        </div>
        <!-- =======  =======  =======  =======  =======  =======  -->
        <!-- =======  =======  =======  =======  =======  =======  -->
        <div class="sales">
            <!-- icon -->

            <!-- icon -->
            <div class="middle">
                <div class="left">
                    <h2>ธีมทั้งหมด</h2>
                </div>
                <div class="graphBox">
                    <div class="slide">
                        <div class="slide-images-theme">
                            <?php
                            include '../dbconnect.php';

                            $table = mysqli_query($conn, 'SELECT * FROM certi_bg');
                            while ($row = mysqli_fetch_array($table)) {
                            ?>
                                <div class="img-container">
                                    <img src="pdf/theme/<?php echo $row['theme']; ?>">
                                    <div class="text-container">
                                        <h3>ID Theme</h3>
                                        <p><?php echo $row['ID_theme']; ?></p>
                                    </div>
                                </div>
                            <?php  } ?>
                            <?php
                            include '../dbconnect.php';

                            $table = mysqli_query($conn, 'SELECT * FROM certi_bg');
                            while ($row = mysqli_fetch_array($table)) {
                            ?>
                                <div class="img-container">
                                    <img src="pdf/theme/<?php echo $row['theme']; ?>">
                                    <div class="text-container">
                                        <h3>ID Theme</h3>
                                        <p><?php echo $row['ID_theme']; ?></p>
                                    </div>
                                </div>
                            <?php  } ?>
                        </div>
                    </div>
                </div>
                <div class="number">
                    <p></p>
                </div>
            </div>
            <small class="text-muted"></small>
        </div>
        <!-- =======  =======  =======  =======  =======  =======  -->
        <!-- =======  =======  =======  =======  =======  =======  -->
        <div class="sales">
            <!-- icon -->

            <!-- icon -->
            <div class="middle">
                <div class="left">
                    <h2>เพิ่มลายเซ็น</h2>
                </div>
                <div class="graphBox">
                    <form action="../Admin/data/data_ajax/Uploadimglicense.php" method="POST" enctype="multipart/form-data">
                        <label>
                            <input class="custom-file-input streched-link" name="file" type="file" accept="image/gif, image/jpeg, image/png">
                        </label>
                        <label>
                            <input class="custom-file-input streched-link" name="license_name" type="text" placeholder="ชื่อเจ้าของลายเซ็น">
                        </label>
                        <p class="small mb-0 mt-2"><b>Note : </b> Only JPG, JPEG, PNG & GIF files are allowe to uoload</p>
                        <div class="button">
                            <input type="submit" name="submit" value="Upload">
                        </div>
                    </form>
                </div>
                <div class="number">
                    <p></p>
                </div>
            </div>
            <small class="text-muted"></small>
        </div>
        <!-- =======  =======  =======  =======  =======  =======  -->
        <!-- =======  =======  =======  =======  =======  =======  -->
        <div class="sales">
            <!-- icon -->

            <!-- icon -->
            <div class="middle">
                <div class="left">
                    <h2></h2>
                </div>
                <div class="graphBox">
                    <div class="slide">
                        <div class="slide-images-license">
                            <?php
                            include '../dbconnect.php';

                            $table = mysqli_query($conn, 'SELECT * FROM certi_license_tb');
                            while ($row = mysqli_fetch_array($table)) {
                            ?>
                                <div class="img-container">
                                    <img src="pdf/license/<?php echo $row['license']; ?>">
                                    <div class="text-container">
                                        <h3>ชื่อเจ้าของลายเซ็นต์</h3>
                                        <p><?php echo $row['license_name']; ?></p>
                                    </div>
                                </div>
                            <?php  } ?>
                            <?php
                            include '../dbconnect.php';

                            $table = mysqli_query($conn, 'SELECT * FROM certi_license_tb');
                            while ($row = mysqli_fetch_array($table)) {
                            ?>
                                <div class="img-container">
                                    <img src="pdf/license/<?php echo $row['license']; ?>">
                                    <div class="text-container">
                                        <h3>ชื่อเจ้าของลายเซ็นต์</h3>
                                        <p><?php echo $row['license_name']; ?></p>
                                    </div>
                                </div>
                            <?php  } ?>
                        </div>
                    </div>
                </div>
                <div class="number">
                    <p></p>
                </div>
            </div>
            <small class="text-muted"></small>
        </div>
        <!-- =======  =======  =======  =======  =======  =======  -->
    </div>
</body>

</html>