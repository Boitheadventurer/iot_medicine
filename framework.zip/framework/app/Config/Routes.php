<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Welcome::index');


$routes->get('member', 'MemberController::index');
$routes->get('member/search', 'MemberController::search');
$routes->post('member/update_status', 'MemberController::update_status');
$routes->get('member/edit/(:num)', 'MemberController::edit/$1');
$routes->post('member/update/(:num)', 'MemberController::update/$1');
$routes->get('member/delete/(:num)', 'MemberController::delete/$1');





$routes->get('member_type', 'MemberTypeController::member_type');
$routes->get('member_type/create', 'MemberTypeController::create');
$routes->post('member_type/store', 'MemberTypeController::store');
$routes->get('member_type/edit/(:num)', 'MemberTypeController::edit/$1');
$routes->post('member_type/update/(:num)', 'MemberTypeController::update/$1');
$routes->get('member_type/delete/(:num)', 'MemberTypeController::delete/$1');





$routes->get('credit', 'CreditController::credit');
$routes->get('credit/search', 'MemberController::search_credit');
$routes->post('credit/save', 'CreditController::save');


// app/Config/Routes.php
// app/Config/Routes.php

$routes->get('/member_types2', 'MemberTypeController2::index');
$routes->post('/member_type_details', 'MemberTypeController2::getMemberTypeDetails');

$routes->post('/search_member_by_code', 'MemberController::searchMemberByCode');




$routes->get('/search', 'SearchController::index');
$routes->post('/search', 'SearchController::search');





