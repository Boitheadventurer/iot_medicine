<?php

namespace App\Controllers;

use App\Models\CreditModel;
use App\Models\MemberTypeModel2;
use App\Models\LoanModel;
use CodeIgniter\Controller;

class CreditController extends Controller
{
    public function save()
    {
        $creditModel = new CreditModel();
        $loanModel = new LoanModel();

        // รับข้อมูลจากฟอร์ม
        $creditData = [
            'loan_type' => $this->request->getPost('loan_type'),
            'contract_number' => $this->request->getPost('contract_number'),
            'borrower_id' => $this->request->getPost('borrower_id'),
            'loan_amount' => $this->request->getPost('loan_amount'),
        ];

        // บันทึกข้อมูลลงใน tb_credit
        $creditModel->insert($creditData);

        $contractNumber = $this->request->getPost('contract_number');
        $guarantors = $this->request->getPost('guarantors');

        if ($guarantors && is_array($guarantors)) {
            foreach ($guarantors as $guarantor) {
                $loanData = [
                    'contract_number' => $contractNumber,
                    'mem_code' => $guarantor['mem_code'],
                    'dividend' => $guarantor['dividend']
                ];

                // บันทึกข้อมูลผู้ค้ำประกันลงใน tb_loans
                $loanModel->insert($loanData);
            }
        }

        return redirect()->to('/credit'); // หรือหน้าอื่นที่คุณต้องการ
    }

    public function credit()
    {
        $model = new MemberTypeModel2();
        $data['member_types'] = $model->getMemberTypes();

        return view('credit', $data);
    }
}
