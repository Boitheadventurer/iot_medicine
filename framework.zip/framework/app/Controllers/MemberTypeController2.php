<?php

namespace App\Controllers;

use App\Models\MemberTypeModel2;
use CodeIgniter\Controller;

class MemberTypeController2 extends Controller
{
    public function index()
    {
        $model = new MemberTypeModel2();
        $data['member_types'] = $model->getMemberTypes();
        return view('member_type_view', $data);
    }

    public function getMemberTypeDetails()
    {
        $model = new MemberTypeModel2();
        $id = $this->request->getPost('member_type_id');
        $memberType = $model->getMemberTypeById($id);

        if ($memberType) {
            // Assume 'contract_count' and 'member_cost' are available fields
            echo json_encode([
                'contract_count' => $memberType['contract_count'],
                'member_cost' => $memberType['member_cost']
            ]);
        } else {
            echo json_encode([]);
        }
    }

    
}
