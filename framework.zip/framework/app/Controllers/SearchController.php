<?php

namespace App\Controllers;

use App\Models\SearchModel;

class SearchController extends BaseController
{
    public function index()
    {
        return view('search_view');
    }

    public function search()
    {
        $query = $this->request->getPost('query');
        $model = new SearchModel();

        $data = $model->where('mem_code', $query)->findAll();

        return $this->response->setJSON($data);
    }
}
