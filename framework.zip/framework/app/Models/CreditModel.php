<?php
namespace App\Models;

use CodeIgniter\Model;

class CreditModel extends Model
{
    protected $table = 'tb_credit';
    protected $primaryKey = 'credit_id';
    protected $allowedFields = ['loan_type', 'contract_number', 'loan_amount', 'borrower_id'];
}
