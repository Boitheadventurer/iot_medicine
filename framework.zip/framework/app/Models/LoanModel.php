<?php

namespace App\Models;

use CodeIgniter\Model;

class LoanModel extends Model
{
    protected $table = 'tb_loans'; // เปลี่ยนเป็นชื่อจริงของตารางที่คุณใช้
    protected $primaryKey = 'loans_id';
    protected $allowedFields = ['dividend', 'mem_code', 'contract_number'];
}
