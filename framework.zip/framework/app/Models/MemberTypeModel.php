<?php

namespace App\Models;

use CodeIgniter\Model;

class MemberTypeModel extends Model
{
    protected $table = 'tb_member_type';
    protected $primaryKey = 'member_type_id';
    protected $allowedFields = ['member_type', 'member_cost', 'contract_count'];

    public function get_all_statuses_with_details()
    {
        $query = $this->db->query('SELECT * FROM tb_member_type');
        return $query->getResultArray();
    }
}
