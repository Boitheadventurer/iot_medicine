<?php

namespace App\Models;

use CodeIgniter\Model;

class MemberTypeModel2 extends Model
{
    protected $table = 'tb_member_type';
    protected $primaryKey = 'member_type_id';
    protected $allowedFields = ['member_type'];

    public function getMemberTypes()
    {
        return $this->findAll();
    }

    public function getMemberTypeById($id)
    {
        return $this->where('member_type_id', $id)->first();
    }
}
