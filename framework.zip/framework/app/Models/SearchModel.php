<?php

namespace App\Models;

use CodeIgniter\Model;

class SearchModel extends Model
{
    protected $table = 'tb_member';
    protected $primaryKey = 'mem_id';
    protected $allowedFields = ['mem_title', 'mem_fname', 'mem_lname', 'mem_id', 'mem_code', 'mem_status']; // ระบุฟิลด์ที่สามารถใช้งานได้
}
