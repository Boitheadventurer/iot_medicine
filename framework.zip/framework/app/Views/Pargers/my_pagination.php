<?php $pager->setSurroundCount(2); ?>

<nav class="block">
    <ul class="flex pl-0 rounded list-none flex-wrap">
        <?php if ($pager->hasPrevious()) : ?>
            <li class="page-item">
                <a class="first:ml-0 text-xs font-semibold flex w-8 h-8 mx-1 p-0 rounded-full items-center justify-center leading-tight text-gray-400 bg-white border border-gray-300" href="<?= $pager->getFirst() ?>">&laquo;</a>
            </li>
            <li class="page-item">
                <a class="first:ml-0 text-xs font-semibold flex w-8 h-8 mx-1 p-0 rounded-full items-center justify-center leading-tight text-gray-400 bg-white border border-gray-300" href="<?= $pager->getPrevious() ?>">&lsaquo;</a>
            </li>
        <?php endif; ?>

        <?php foreach ($pager->links() as $link) : ?>
            <li class="page-item <?= $link['active'] ? 'bg-gray-300' : '' ?>">
                <a href="<?= $link['uri'] ?>" class="first:ml-0 text-xs font-semibold flex w-8 h-8 mx-1 p-0 rounded-full items-center justify-center leading-tight <?= $link['active'] ? 'text-white bg-blue-500' : 'text-gray-400 bg-white border border-gray-300' ?>">
                    <?= $link['title'] ?>
                </a>
            </li>
        <?php endforeach; ?>

        <?php if ($pager->hasNext()) : ?>
            <li class="page-item">
                <a class="first:ml-0 text-xs font-semibold flex w-8 h-8 mx-1 p-0 rounded-full items-center justify-center leading-tight text-gray-400 bg-white border border-gray-300" href="<?= $pager->getNext() ?>">&rsaquo;</a>
            </li>
            <li class="page-item">
                <a class="first:ml-0 text-xs font-semibold flex w-8 h-8 mx-1 p-0 rounded-full items-center justify-center leading-tight text-gray-400 bg-white border border-gray-300" href="<?= $pager->getLast() ?>">&raquo;</a>
            </li>
        <?php endif; ?>
    </ul>
</nav>
