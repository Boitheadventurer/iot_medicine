<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">
    <div class="mx-auto w-4/5 mt-5 bg-white p-6 rounded-lg shadow-lg">
        <div class="text-center mb-4">
            <h1 class="text-3xl font-bold text-gray-900">สินเชื่อ</h1>
        </div>
        <h1 class="text-lg mb-3 font-medium text-gray-900">สัญญาเงินกู้</h1>

        <form id="outerForm" action="<?php echo base_url('credit/save'); ?>" method="POST">
            <div class="w-full mb-3">
                <div class="flex items-center border border-gray-200 rounded p-3 mb-2">
                    <input id="bordered-radio-1" type="radio" value="สามัญ" name="loan_type"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2">
                    <label for="bordered-radio-1" class="ml-2 text-sm font-medium text-gray-900">กู้สามัญ</label>
                </div>
                <div class="flex items-center border border-gray-200 rounded p-3 mb-2">
                    <input id="bordered-radio-2" type="radio" value="ฉุกเฉิน" name="loan_type"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2">
                    <label for="bordered-radio-2" class="ml-2 text-sm font-medium text-gray-900">กู้ฉุกเฉิน</label>
                </div>
                <div class="flex items-center border border-gray-200 rounded p-3">
                    <input id="bordered-radio-3" type="radio" value="ไม่เกินค่าหุ้น" name="loan_type"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2">
                    <label for="bordered-radio-3"
                        class="ml-2 text-sm font-medium text-gray-900">กู้ไม่เกินค่าหุ้น</label>
                </div>
            </div>
            <div class="mb-4">
                <label for="contract_number" class="block text-lg font-medium text-gray-900 mb-2">เลขที่สัญญา</label>
                <input type="text" id="contract_number" name="contract_number"
                    class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            </div>

            <div class="mb-4">
                <h1>ผู้ขอกู้</h1>
                <input type="text" id="search-query-borrower" name="borrower_id"
                    class="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="ค้นหาด้วยรหัส">
                <a id="search-button-borrower"
                    class="inline-flex items-center px-4 py-2 text-lg font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
                <h1 id="search-results-borrower" class="ml-2 text-lg font-medium text-gray-900"></h1>
            </div>





            <div class="mb-4">
                <label for="member_type" class="block text-lg font-medium text-gray-900 mb-2">ประเภทสมาชิก</label>
                <select id="member_type" name="member_type"
                    class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    <option value="">เลือกประเภทสมาชิก</option>
                    <?php foreach($member_types as $type): ?>
                    <option value="<?= $type['member_type_id'] ?>"><?= $type['member_type'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="text-center mb-4">
                <h1 class="text-3xl font-bold text-gray-900">วงเงิน</h1>
                <p id="contract_count" class="text-xl text-gray-700">-</p>
            </div>

            <div class="text-center mb-4">
                <h1 class="text-3xl font-bold text-gray-900">สัญญา</h1>
                <p id="member_cost" class="text-xl text-gray-700">-</p>
            </div>
    

    <script>
    $(document).ready(function() {
        $('#member_type').change(function() {
            let memberTypeId = $(this).val();

            if (memberTypeId) {
                $.ajax({
                    url: '<?= base_url('member_type_details') ?>',
                    method: 'POST',
                    data: {
                        member_type_id: memberTypeId
                    },
                    success: function(data) {
                        let result = JSON.parse(data);

                        if (result.contract_count && result.member_cost) {
                            $('#contract_count').text(result.contract_count);
                            $('#member_cost').text(result.member_cost);
                        } else {
                            $('#contract_count').text('-');
                            $('#member_cost').text('-');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            } else {
                $('#contract_count').text('-');
                $('#member_cost').text('-');
            }
        });
    });
    </script>





    <div class="mb-4">
        <label for="loan_amount" class="block text-lg font-medium text-gray-900 mb-2">วงเงินที่กู้ได้</label>
        <input type="text" id="loan_amount" name="loan_amount"
            class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
    </div>
    <div class="mb-4">
        <label for="dividend" class="block text-lg font-medium text-gray-900 mb-2">หารได้</label>
        <input type="text" id="dividend" name="dividend"
            class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            readonly />
    </div>

    <div class="relative overflow-x-auto my-4">
        <div class="flex items-center my-4">
            <label for="loan_amount" class="block text-lg font-medium text-gray-900 mb-2">ผู้ค้ำประกัน</label>
            <button type="button" id="addGuarantorButton"
                class="ml-auto inline-flex items-center px-4 py-2 text-lg font-medium text-center text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500 dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-400">
                เพิ่มผู้ค้ำประกัน
            </button>
        </div>
        <table class="w-full text-lg text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left">ลำดับ</th>
                    <th scope="col" class="px-6 py-3">รหัส</th>
                    <th scope="col" class="px-6 py-3">รายชื่อ</th>
                    <th scope="col" class="px-6 py-3 text-right">จำนวนเงิน</th>
                    <th scope="col" class="px-6 py-3 text-right">ลบ</th>
                </tr>
            </thead>
            <tbody id="guarantorTableBody">
                <tr
                    class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                    <th scope="row"
                        class="px-6 py-4 font-medium text-left text-gray-900 whitespace-nowrap dark:text-white">1</th>
                    <td class="px-6 py-4">
                        <input type="text" name="guarantors[0][mem_code]"
                            class="guarantor-query px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                            placeholder="ค้นหาด้วยรหัส">
                        <a
                            class="guarantor-search-button inline-flex items-center px-4 py-2 text-lg font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
                    </td>
                    <td class="px-6 py-4 guarantor-name" id="guarantor-results">-</td>
                    <td class="px-6 py-4">
                        <input type="text" name="guarantors[0][dividend]"
                            class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                            readonly />
                    </td>
                    <td class="px-6 py-4 text-right">
                        <button type="button" class="text-red-600 hover:text-red-900 deleteButton">ลบ</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="text-center">
        <button type="submit"
            class="inline-flex items-center px-4 py-2 text-lg font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">
            บันทึก
        </button>
    </div>
    </form>
    </div>

    <script>
    $(document).ready(function() {
        let guarantorCount = 1;

        function searchMember(query, resultElement, row) {
            $.ajax({
                url: '<?= base_url('search') ?>',
                method: 'POST',
                data: {
                    query: query
                },
                success: function(data) {
                    resultElement.empty();
                    if (data.length > 0) {
                        data.forEach(function(item) {
                            resultElement.append('<p>' + item.mem_title + ' ' 
                            + item.mem_fname + ' ' + item.mem_lname + ' ' 
                            + item.mem_status + '</p>');
                        });
                    } else {
                        resultElement.append('<p>ไม่พบข้อมูล</p>');
                    }
                    row.find('.guarantor-query').trigger('change');
                }
            });
        }

        $('#search-button-borrower').click(function() {
            let query = $('#search-query-borrower').val();
            let resultElement = $('#search-results-borrower');
            searchMember(query, resultElement);
        });

        $(document).on('click', '.guarantor-search-button', function() {
            let row = $(this).closest('tr');
            let query = row.find('.guarantor-query').val();
            let resultElement = row.find('#guarantor-results');
            searchMember(query, resultElement, row);
        });

        function updateDividend() {
            let loanAmount = parseFloat($('#loan_amount').val()) || 0;
            let dividend = loanAmount / guarantorCount;
            $('#dividend').val(dividend.toFixed(2));

            $('#guarantorTableBody tr').each(function() {
                $(this).find('input[name$="[dividend]"]').val(dividend.toFixed(2));
            });
        }

        $('#loan_amount').on('input', updateDividend);

        $('#addGuarantorButton').click(function() {
            if (guarantorCount < 6) {
                const tableBody = $('#guarantorTableBody');
                const newRow = `
                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <th scope="row" class="px-6 py-4 font-medium text-left text-gray-900 whitespace-nowrap dark:text-white">${guarantorCount + 1}</th>
                            <td class="px-6 py-4">
                                <input type="text" name="guarantors[${guarantorCount}][mem_code]" class="guarantor-query px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="ค้นหาด้วยรหัส">
                                <a class="guarantor-search-button inline-flex items-center px-4 py-2 text-lg font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
                            </td>
                            <td class="px-6 py-4 guarantor-name" id="guarantor-results">-</td>
                            <td class="px-6 py-4">
                                <input type="text" name="guarantors[${guarantorCount}][dividend]" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" readonly />
                            </td>
                            <td class="px-6 py-4 text-right">
                                <button type="button" class="text-red-600 hover:text-red-900 deleteButton">ลบ</button>
                            </td>
                        </tr>`;
                tableBody.append(newRow);
                guarantorCount++;
                addDeleteFunctionality();
                updateDividend();
            }
        });

        function addDeleteFunctionality() {
            $('.deleteButton').off('click').on('click', function() {
                $(this).closest('tr').remove();
                updateRowNumbers();
                guarantorCount--;
                updateDividend();
            });

            $('.guarantor-query').off('change').on('change', updateGuarantorFields);
        }

        function updateRowNumbers() {
            $('#guarantorTableBody tr').each(function(index) {
                $(this).find('th').text(index + 1);
                $(this).find('input').each(function() {
                    const name = $(this).attr('name');
                    if (name) {
                        $(this).attr('name', name.replace(/\[\d+\]/, `[${index}]`));
                    }
                });
            });
        }

        function updateGuarantorFields() {
            const input = $(this);
            const row = input.closest('tr');
            const rowIndex = row.index();
            const mem_code = input.val();
            const name = row.find('.guarantor-name').text();

            input.attr('name', `guarantors[${rowIndex}][mem_code]`);
            row.find('input[name$="[dividend]"]').attr('name', `guarantors[${rowIndex}][dividend]`);
        }

        addDeleteFunctionality();
    });
    </script>

</body>

</html>