<!DOCTYPE html>
<html>
<head>
    <title>Welcome to CodeIgniter</title>
</head>
<body>
    <h1>Welcome to CodeIgniter!</h1>
    <p>This is the home page.</p>
    <a href="<?= base_url('member') ?>">รายชื่อสมาชิก</a>
    <a href="<?= base_url('member_type') ?>">สัญญาและวงเงิน</a>
    <a href="<?= base_url('credit') ?>">สัญญาและวงเงิน</a>
    <a href="<?= base_url('search') ?>">ทดสอบ</a>
    <a href="<?= base_url('member_types2') ?>">ทดสอบ 2</a>
</body>
</html>
