<!DOCTYPE html>
<html>
<head>
    <title>Welcome to CodeIgniter</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="mx-auto w-4/5 mt-5 bg-white p-5 rounded-lg shadow-2xl">
        <h1 class="text-3xl font-bold my-5">
            รายชื่อสมาชิก
        </h1>
        <form action="<?= base_url('member/search') ?>" method="get" class="mb-5">
            <input type="text" name="mem_code" placeholder="ค้นหาโดยรหัส" class="border rounded py-2 px-3 text-grey-darkest" value="<?= isset($_GET['mem_code']) ? $_GET['mem_code'] : '' ?>">
            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded">ค้นหา</button>
        </form>
        <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
            <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                <thead class="text-base text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            ลำดับ
                        </th>
                        <th scope="col" class="px-6 py-3">
                            รหัส
                        </th>
                        <th scope="col" class="px-6 py-3">
                            ชื่อ-สกุล
                        </th>
                        <th scope="col" class="px-6 py-3">
                            ประเภท
                        </th>
                        <th scope="col" class="px-6 py-3">
                            แก้ไข
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            ดำเนินการ
                        </th>
                    </tr>
                </thead>
                <tbody><?php $index = 1; ?>
                    <?php foreach ($tb_member as $row) : ?>
                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <td scope="row" class="px-6 py-4 text-base text-gray-900 whitespace-nowrap dark:text-white">
                                <?php echo $index++; ?>
                            </td>
                            <td><?php echo $row['mem_code']; ?></td>
                            <td><?php echo $row['mem_title']; ?> <?php echo $row['mem_fname']; ?> <?php echo $row['mem_lname']; ?></td>
                            <td><?php echo $row['mem_status']; ?></td>
                            <td>
                                <form action="<?= base_url('member/update_status') ?>" method="post">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="mem_code" value="<?= $row['mem_code'] ?>">
                                    <select name="mem_status" onchange="if(confirm('Are you sure you want to change the status?')) { this.form.submit(); }" class="border rounded py-2 px-3 text-grey-darkest">
                                        <?php foreach ($status_options as $status): ?>
                                            <option value="<?= $status ?>" <?= $row['mem_status'] === $status ? 'selected' : '' ?>><?= $status ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </form>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <a href="<?= base_url('member/delete/' . $row['mem_id']) ?>" class="text-base text-red-600 dark:text-red-500 hover:underline" onclick="return confirm('Are you sure you want to delete the status?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="my-5 flex justify-center">
            <div><?= $pager->links('default', 'my_pagination') ?></div>
        </div>
    </div>
</body>
</html>
