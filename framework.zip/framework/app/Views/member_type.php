<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สถานะผู้ใช้งาน</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        function confirmDelete(event, url) {
            event.preventDefault(); // Prevent the default link behavior
            if (confirm('คุณแน่ใจหรือไม่ว่าต้องการลบสถานะนี้?')) {
                window.location.href = url; // Redirect to the delete URL if confirmed
            }
        }
    </script>
</head>

<body class="bg-gray-100">
    <div class="mx-auto w-4/5 mt-5 bg-white p-6 rounded-lg shadow-lg">
        <div class="flex items-center mb-4">
            <h1 class="text-3xl font-bold text-gray-900 mr-4">ข้อกำหนดสัญญาและวงเงิน</h1>
            <a href="<?= base_url('member_type/create') ?>" class="ml-auto inline-flex items-center px-4 py-2 text-lg font-medium text-center text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500 dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-400">
                เพิ่มสถานะผู้ใช้งาน
            </a>
        </div>

        <?php foreach ($statuses as $status) : ?>
            <div class="p-6 bg-white border border-gray-200 rounded-lg shadow-md mb-4 flex items-center">
                <div class="flex-1">
                    <h5 class="text-xl font-semibold text-gray-800 dark:text-gray-200">
                        สถานะ: <?= $status['member_type']; ?>
                    </h5>
                    <div class="mt-2 text-gray-600 dark:text-gray-400">
                        <p class="mb-1">จำนวนสัญญา: <?= $status['contract_count']; ?></p>
                        <p>วงเงิน: <?= number_format($status['member_cost'], 2); ?></p>
                    </div>
                </div>
                <div class="space-x-2 ml-auto flex-shrink-0">
                    <a href="<?= base_url('member_type/edit/' . $status['member_type_id']) ?>" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-gray-700 rounded-lg hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800">
                        รายละเอียด
                    </a>
                    <a href="<?= base_url('member_type/edit/' . $status['member_type_id']) ?>" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-yellow-500 rounded-lg hover:bg-yellow-600 focus:ring-4 focus:outline-none focus:ring-yellow-300 dark:bg-yellow-500 dark:hover:bg-yellow-600 dark:focus:ring-yellow-400">
                        แก้ไข
                    </a>
                    <a href="#" onclick="confirmDelete(event, '<?= base_url('member_type/delete/' . $status['member_type_id']) ?>')" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-red-600 rounded-lg hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-400">
                        ลบ
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>

</html>
