<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ค้นหา</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>ค้นหา</h1>
    <input type="text" id="search-query" placeholder="กรอกคำค้นหา...">
    <button id="search-button">ค้นหา</button>

    <div id="search-results"></div>

    <script>
        $(document).ready(function() {
            $('#search-button').click(function() {
                let query = $('#search-query').val();

                $.ajax({
                    url: '<?= base_url('search') ?>',
                    method: 'POST',
                    data: { query: query },
                    success: function(data) {
                        let results = $('#search-results');
                        results.empty();

                        if (data.length > 0) {
                            data.forEach(function(item) {
                                results.append('<p>ชื่อ: ' + item.mem_title + ' ' + item.mem_fname + ' ' + item.mem_lname + ' สถานะ: ' + item.mem_status + '</p>');
                            });
                        } else {
                            results.append('<p>ไม่พบข้อมูล</p>');
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>
