<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Welcome::index');


$routes->get('member', 'MemberController::index');
$routes->get('member/search', 'MemberController::search');
$routes->post('member/update_status', 'MemberController::update_status');
$routes->get('member/edit/(:num)', 'MemberController::edit/$1');
$routes->post('member/update/(:num)', 'MemberController::update/$1');
$routes->get('member/delete/(:num)', 'MemberController::delete/$1');





$routes->get('member_type', 'MemberTypeController::member_type');
$routes->get('member_type/create', 'MemberTypeController::create');
$routes->post('member_type/store', 'MemberTypeController::store');
$routes->get('member_type/edit/(:num)', 'MemberTypeController::edit/$1');
$routes->post('member_type/update/(:num)', 'MemberTypeController::update/$1');
$routes->get('member_type/delete/(:num)', 'MemberTypeController::delete/$1');




$routes->get('credit', 'CreditController::credit');

$routes->get('credit/search', 'MemberController::search_credit');
$routes->post('credit/save', 'CreditController::save');

$routes->post('/search_member_by_code', 'MemberController::searchMemberByCode');





$routes->get('/report_num', 'MemberTypeController2::index/$i');
$routes->post('/member_type_details', 'MemberTypeController2::getMemberTypeDetails');
$routes->post('/member_type_details2', 'MemberTypeController2::getMemberTypeDetails2');

$routes->post('/search_member_by_code1', 'MemberTypeController2::searchMemberByCode');



$routes->get('/search', 'SearchController::index');
$routes->post('/search', 'SearchController::search');


$routes->get('report', 'ReportController::index');
$routes->post('report/searchByContractNumber', 'ReportController::searchByContractNumber');
$routes->post('report/searchLoanDetails', 'ReportController::searchLoanDetails');
$routes->post('report/searchMemberDetails', 'ReportController::searchMemberDetails');
$routes->post('report/searchBorrowerDetails', 'ReportController::searchBorrowerDetails');
$routes->get('report/getStatusToIdMap', 'ReportController::getStatusToIdMap');



$routes->get('report_mem', 'ReportController::searchCreditByBorrowerIdView');
$routes->post('report_mem/searchByContractNumber', 'ReportController::searchCreditByBorrowerId');
$routes->post('report_mem/searchByMemCode', 'ReportController::searchByMemCode');
$routes->post('report_mem/searchCreditDetails', 'ReportController::searchCreditDetails');

$routes->post('credit/searchLoanDetails', 'CreditController::searchLoanDetails');
$routes->post('credit/check_contract_number', 'CreditController::check_contract_number');



// $routes->get('report', 'ReportController::index');
// $routes->post('report/searchByContractNumber', 'ReportController::searchByContractNumber');
// $routes->post('report/searchLoanDetails', 'ReportController::searchLoanDetails');
// $routes->post('report/searchMemberDetails', 'ReportController::searchMemberDetails');

//console.log(t + ' = t วงเงินผู้กู้');
//console.log(loanAmount + ' = loanAmount วงเงินขอกู้');
//console.log(sm + ' = sm จำนวนสัญญาผู้กู้');
//console.log(max + ' = max จำนวนสัญญาผู้กู้ไม่เกิน');

//console.log(dividendAmount + ' = dividendAmount จำนวนเงินหารได้');

//console.log(loancost + ' = loancost วงเงินเหลือผู้ค้ำ');
//console.log(loanCount + ' = loanCount จำนวนสัญญาผู้ค้ำ');
//console.log(max_cos + ' = max_cos จำนวนสัญญาผู้ค้ำไม่เกิน');
//console.log(guarantorCount + ' = guarantorCount จำนวนผู้ค้ำ');






