<?php

namespace App\Controllers;

use App\Models\CreditModel;
use App\Models\MemberTypeModel2;
use App\Models\LoanModel;
use CodeIgniter\Controller;

class CreditController extends Controller
{
    public function save()
    {
        $creditModel = new CreditModel();
        $loanModel = new LoanModel();
        
        $creditData = [
            'loan_type' => $this->request->getPost('loan_type'),
            'contract_number' => $this->request->getPost('contract_number'),
            'borrower_id' => $this->request->getPost('borrower_id'),
            'loan_amount' => $this->request->getPost('loan_amount'),
        ];

        $contractNumber = $this->request->getPost('contract_number');
        $existingContract = $creditModel->where('contract_number', $contractNumber)->first();
        if ($existingContract) {
            return redirect()->back()->with('error', 'เลขที่สัญญาซ้ำ กรุณากรอกใหม่')->withInput();
        }
        if ($creditModel->insert($creditData)) {
            $guarantors = $this->request->getPost('guarantors');
    
            if ($guarantors && is_array($guarantors)) {
                foreach ($guarantors as $guarantor) {
                    $loanData = [
                        'contract_number' => $contractNumber,
                        'mem_code' => $guarantor['mem_code'],
                        'dividend' => $guarantor['dividend']
                    ];
    
                    $loanModel->insert($loanData);
                }
            }
    
            return redirect()->to('/credit')->with('success', 'บันทึกข้อมูลสำเร็จ');
        } else {
            return redirect()->back()->with('error', 'เกิดข้อผิดพลาดในการบันทึกข้อมูล')->withInput();
        }
    }


    public function searchLoanDetails()
    {
        $mem_code = $this->request->getPost('mem_code');
        if ($mem_code) {
            $loanModel = new LoanModel();
            $results = $loanModel->getLoansByMemCode($mem_code);

            return $this->response->setJSON($results);
        } else {
            return $this->response->setJSON([]);
        }
    }



    public function check_contract_number()
    {
        $contract_number = $this->request->getPost('contract_number');
        $creditModel = new CreditModel();

        $exists = $creditModel->where('contract_number', $contract_number)->first();

        if ($exists) {
            return $this->response->setJSON(['exists' => true]);
        } else {
            return $this->response->setJSON(['exists' => false]);
        }
    }


    public function credit()
    {
        $model = new MemberTypeModel2();
        $data['member_types'] = $model->getMemberTypes();

        return view('credit', $data);
    }
}
