<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\MemberModel;
use App\Models\MemberTypeModel;

class MemberController extends Controller
{
    public function index()
    {
        $model = new MemberModel();
        $memberModel = new MemberModel();
        $data['tb_member'] = $memberModel->findAll();
        $data['status_options'] = $memberModel->get_unique_status_options(); // ส่งตัวแปร $status_options ไปยัง View

        $data['tb_member'] = $model->paginate(10);
        $data['pager'] = $model->pager;

        return view('member', $data);
    }


  



    public function search()
    {
        $model = new \App\Models\MemberModel();
    
        $mem_code = $this->request->getVar('mem_code');
    
        if ($mem_code) {
            $data['tb_member'] = $model->where('mem_code', $mem_code)->paginate(10);
        } else {
            $data['tb_member'] = $model->paginate(10);
        }
    
        $data['status_options'] = $model->get_unique_status_options();
    
        $data['pager'] = $model->pager;
    
        return view('member', $data);
    }
    public function search_credit()
    {
        $model = new \App\Models\MemberModel();
    
        $mem_code = $this->request->getVar('mem_code');
    
        if ($mem_code) {
            $data['tb_member'] = $model->where('mem_code', $mem_code)->paginate(10);
        } else {
            $data['tb_member'] = $model->paginate(10);
        }
    
        $data['status_options'] = $model->get_unique_status_options();
    
        $data['pager'] = $model->pager;
    
        return view('credit', $data);
    }

    public function searchMemberByCode()
    {
        $model = new MemberModel();
        $memCode = $this->request->getPost('mem_code');
        $member = $model->getMemberByCode($memCode);

        if ($member) {
            // ดึงข้อมูลเครดิตที่เกี่ยวข้อง
            $memberWithCredit = $model->getMemberWithCredit($memCode);
            if (!empty($memberWithCredit)) {
                $member['credit'] = $memberWithCredit;
            } else {
                $member['credit'] = [];
            }

            echo json_encode($member);
        } else {
            echo json_encode([]);
        }
    }

    public function update_status()
    {
        $model = new MemberModel();

        $mem_code = $this->request->getPost('mem_code');
        $status = $this->request->getPost('mem_status');

        if ($mem_code && $status) {
            $model->update_member_status($mem_code, $status);
        }

        return redirect()->to('/member');
    }



    public function delete($id)
    {
        $model = new MemberModel();
        
        // ตั้งค่าให้ค่า mem_status เป็นค่าว่าง (หรือ NULL)
        $data = ['mem_status' => ''];
        
        $model->update($id, $data);
        
        return redirect()->to(base_url('member'));
    }
}
