<?php

namespace App\Controllers;

use App\Models\MemberTypeModel;
use App\Models\MemberModel; // เรียกใช้ MemberModel
use CodeIgniter\Controller;

class MemberTypeController extends Controller
{
    public function member_type()
    {
        $model = new MemberTypeModel();
        $data['statuses'] = $model->get_all_statuses_with_details();  // รับข้อมูลสถานะทั้งหมดพร้อมรายละเอียด
        return view('member_type', $data);
    }

    public function create()
    {
        return view('member_type/create');
    }

    public function store()
    {
        $model = new MemberTypeModel();
        $data = [
            'member_type' => $this->request->getPost('member_type'),
            'member_cost' => $this->request->getPost('member_cost'),
            'contract_count' => $this->request->getPost('contract_count')
        ];
        $model->save($data);

        return redirect()->to(base_url('member_type'));
    }

    public function edit($id)
    {
        $model = new MemberTypeModel();
        $data['status'] = $model->find($id);
        return view('member_type/edit', $data);
    }

    public function update($id)
    {
        $model = new MemberTypeModel();
        $data = [
            'member_type' => $this->request->getPost('member_type'),
            'member_cost' => $this->request->getPost('member_cost'),
            'contract_count' => $this->request->getPost('contract_count')
        ];
        $model->update($id, $data);

        return redirect()->to(base_url('member_type'));
    }

    public function delete($id)
    {
        $memberTypeModel = new MemberTypeModel();
        $memberModel = new MemberModel(); // เรียกใช้ MemberModel

        // ค้นหาค่า member_type ที่จะลบ
        $memberType = $memberTypeModel->find($id);

        if ($memberType) {
            // อัปเดตคอลัมน์ mem_status ของ tb_member ที่มีค่าเหมือนกับ member_type เป็น NULL
            $memberModel->where('mem_status', $memberType['member_type'])
                        ->set(['mem_status' => null])
                        ->update();

            // ลบข้อมูลจาก member_type
            $memberTypeModel->delete($id);
        }

        return redirect()->to(base_url('member_type'));
    }
}
