<?php

namespace App\Controllers;

use App\Models\MemberTypeModel2;
use CodeIgniter\Controller;
use App\Models\MemberModel;

class MemberTypeController2 extends Controller
{

    public function index($memCode)
    {
        $memberModel = new MemberModel();
        $memberData = $memberModel->getMemberWithCredit($memCode);

        $memberTypeModel = new MemberTypeModel2();
        $memberTypes = $memberTypeModel->getMemberTypes();

        // รวมข้อมูลเข้าด้วยกันใน array เดียวกัน
        $data = [
            'member_data' => $memberData,
            'member_types' => $memberTypes
        ];

        // ส่งข้อมูลไปยัง View
        return view('report_num', $data);
    }

    public function getMemberTypeDetails()
    {
        $model = new MemberTypeModel2();
        $id = $this->request->getPost('member_type_id');
        $memberType = $model->getMemberTypeById($id);

        if ($memberType) {
            // Assume 'contract_count' and 'member_cost' are available fields
            echo json_encode([
                'contract_count' => $memberType['contract_count'],
                'member_cost' => $memberType['member_cost']
            ]);
        } else {
            echo json_encode([]);
        }
    }
    public function getMemberTypeDetails2()
    {
        $model = new MemberTypeModel2();
        $status = $this->request->getPost('member_type');
        $memberType = $model->getMemberTypeById2($status);

        if ($memberType) {
        
            return $this->response->setJSON([
                'contract_count' => $memberType['contract_count'],
                'member_cost' => $memberType['member_cost']
            ]);
        } else {
            return $this->response->setJSON([]);
        }
    }

    public function searchMemberByCode()
    {
        $model = new MemberModel();
        $memCode = $this->request->getPost('mem_code');
        $member = $model->getMemberByCode($memCode);

        if ($member) {
            // ดึงข้อมูลเครดิตที่เกี่ยวข้อง
            $memberWithCredit = $model->getMemberWithCredit($memCode);
            if (!empty($memberWithCredit)) {
                $member['report_num'] = $memberWithCredit;
            } else {
                $member['report_num'] = [];
            }

            echo json_encode($member);
        } else {
            echo json_encode([]);
        }
    }

    

    
}
