<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\MemberModel;
use App\Models\MemberTypeModel2;
use App\Models\MemberTypeModel;
use App\Models\ReportModel;
use App\Models\ContractModel;
use App\Models\LoanModel;
use CodeIgniter\CLI\Console;

class ReportController extends Controller
{
    public function index()
    {
        // สร้างอินสแตนซ์ของโมเดล ReportModel
        $reportModel = new ReportModel();
        // ดึงข้อมูลจากฟังก์ชัน getMemberOrderDetails ของ ReportModel
        $data['memberOrderDetails'] = $reportModel->getMemberOrderDetails();

        // สร้างอินสแตนซ์ของโมเดล MemberTypeModel2
        $model = new MemberTypeModel2();
        // ดึงข้อมูลจากฟังก์ชัน getMemberTypes ของ MemberTypeModel2
        $data['member_types'] = $model->getMemberTypes();

        // ส่งข้อมูลไปยัง View
        return view('report', $data);
    }

    public function getStatusToIdMap()
    {
        $model = new MemberTypeModel();
        $data = $model->getTrimmedMemberTypes();

        $response = [];
        foreach ($data as $type) {
            $response[$type['member_type']] = $type['member_type_id'];
        }

        return $this->response->setJSON($response);
    }

    public function searchMemberByCode()
    {
        $model = new MemberModel();
        $memCode = $this->request->getPost('mem_code');
        $member = $model->getMemberByCode($memCode);

        if ($member) {
            // ดึงข้อมูลเครดิตที่เกี่ยวข้อง
            $memberWithCredit = $model->getMemberWithCredit($memCode);
            if (!empty($memberWithCredit)) {
                $member['credit'] = $memberWithCredit;
            } else {
                $member['credit'] = [];
            }

            echo json_encode($member);
        } else {
            echo json_encode([]);
        }
    }


    public function searchByContractNumber()
    {
        $CodeBorrw = $this->request->getPost('code_borrowid');

        if ($CodeBorrw) {
            $creditModel = new ContractModel();
            $results = $creditModel->searchByContractNumber($CodeBorrw);

            return $this->response->setJSON($results);
        } else {
            return $this->response->setJSON([]);
        }
    }

    public function searchLoanDetails()
    {
        $contractNumbers = $this->request->getPost('contract_numbers');

        $model = new LoanModel();
        $data = $model->getLoanDetailsByContractNumbers($contractNumbers);

        return $this->response->setJSON($data);
    }

    public function searchMemberDetails()
    {
        $memCode = $this->request->getPost('mem_code');
        $memberModel = new MemberModel();
        $memberDetails = $memberModel->where('mem_code', $memCode)->findAll();

        return $this->response->setJSON($memberDetails);
    }
    public function searchBorrowerDetails()
    {
        $BorCode = $this->request->getPost('borrower_id');
        $memberModel = new ReportModel();
        $memberDetails = $memberModel->where('mem_code', $BorCode)->findAll();

        return $this->response->setJSON($memberDetails);
    }



    /////////////////////////////////////////////////////// report_member

    public function searchCreditByBorrowerId()
    {
        $loanID = $this->request->getPost('code_loan');

        if ($loanID) {
            $loanModel = new LoanModel();
            $results = $loanModel->searchByLoanNumber($loanID);

            return $this->response->setJSON($results);
        } else {
            return $this->response->setJSON([]);
        }
    }

    public function searchCreditByBorrowerIdView()
    {
        // สร้างอินสแตนซ์ของโมเดล ReportModel
        $reportModel = new ReportModel();
        // ดึงข้อมูลจากฟังก์ชัน getMemberOrderDetails ของ ReportModel
        $data['memberOrderDetails'] = $reportModel->getMemberOrderDetails();

        // สร้างอินสแตนซ์ของโมเดล MemberTypeModel2
        $model = new MemberTypeModel2();
        // ดึงข้อมูลจากฟังก์ชัน getMemberTypes ของ MemberTypeModel2
        $data['member_types'] = $model->getMemberTypes();

        // ส่งข้อมูลไปยัง View
        return view('report_mem', $data);
    }


    public function searchByMemCode()
    {
        $mem_code = $this->request->getPost('mem_code');
        $loanModel = new LoanModel();
        $loanDetails = $loanModel->where('mem_code', $mem_code)->findAll();

        return $this->response->setJSON($loanDetails);
    }
    


    public function searchCreditDetails()
    {
        $contractNumbers = $this->request->getPost('contract_numbers');

        $model = new ReportModel();
        $data = $model->getCreditDetailsByContractNumbers($contractNumbers);

        return $this->response->setJSON($data);
    }
}
