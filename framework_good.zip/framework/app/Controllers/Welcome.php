<?php

namespace App\Controllers;

//use App\Models\UserModel;

class Welcome extends BaseController
{
    public function index()
    {
        return view('index');
    }

   
}
