<?php

namespace App\Models;

use CodeIgniter\Model;

class ContractModel extends Model
{
    protected $table = 'tb_credit';
    protected $primaryKey = 'credit_id';
    protected $allowedFields = ['contract_number', 'loan_amount', 'borrower_id '];

    public function searchByContractNumber($code_borrowid){
        return $this->where('borrower_id', $code_borrowid)
                    ->orderBy('contract_number', 'ASC') // 'DESC'
                    ->get()
                    ->getResult();
    }
}
