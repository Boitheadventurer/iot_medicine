<?php

namespace App\Models;

use CodeIgniter\Model;

class LoanModel extends Model
{
    protected $table = 'tb_loans'; // เปลี่ยนเป็นชื่อจริงของตารางที่คุณใช้
    protected $primaryKey = 'loans_id';
    protected $allowedFields = ['dividend', 'mem_code', 'contract_number'];


    public function getLoanDetailsByContractNumbers($contractNumbers)
    {
        return $this->select('tb_loans.*, tb_member.*,')
                    ->join('tb_member', 'tb_member.mem_code = tb_loans.mem_code')
                    ->whereIn('tb_loans.contract_number', $contractNumbers) // ค้นหาหลายเลขสัญญา
                    ->findAll();
    }

    public function searchByContractNumber($code_borrowid)
    {
        return $this->where('borrower_id ', $code_borrowid)
            ->get()
            ->getResult();
    }
    public function searchByLoanNumber($loanID)
    {
        return $this->where('mem_code ', $loanID)
            ->get()
            ->getResult();
    }
    public function getLoansByMemCode($mem_code)
    {
        return $this->where('mem_code', $mem_code)
        ->get()
        ->getResult();
    }

}
