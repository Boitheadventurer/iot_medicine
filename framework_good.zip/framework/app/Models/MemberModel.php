<?php

namespace App\Models;

use CodeIgniter\Model;

class MemberModel extends Model
{
    protected $table = 'tb_member';
    protected $primaryKey = 'mem_id';
    protected $allowedFields = ['mem_fname', 'mem_lname', 'mem_title', 'mem_code', 'mem_status'];

    public function update_member_status($mem_code, $status)
    {
        return $this->db->table($this->table)
                        ->where('mem_code', $mem_code)
                        ->update(['mem_status' => $status]);
    }

    public function delete_status($mem_code)
    {
        $this->db->table($this->table)
                 ->where('mem_code', $mem_code)
                 ->update(['mem_status' => null]);
    }

    public function get_unique_status_options()
    {
        $query = $this->db->query('SELECT DISTINCT TRIM(member_type) as member_type FROM tb_member_type GROUP BY TRIM(member_type)');
        $results = $query->getResultArray();
        $status_options = [];

        foreach ($results as $row) {
            $status_options[$row['member_type']] = $row['member_type'];
        }

        return $status_options;
    }

    public function get_unique_status_type()
    {
        $query = $this->db->query('SELECT DISTINCT TRIM(member_type) as member_type FROM tb_member_type GROUP BY TRIM(member_type)');
        $results = $query->getResultArray();
        return array_column($results, 'member_type');
    }

    public function getMemberByCode($memCode)
    {
        return $this->where('mem_code', $memCode)->first();
    }

    public function getMemberWithCredit($memCode)
    {
        $builder = $this->db->table($this->table);
        $builder->select('tb_member.*, tb_credit.loan_amount, tb_credit.contract_number'); // เลือกคอลัมน์ที่ต้องการ
        $builder->join('tb_credit', 'tb_member.mem_code = tb_credit.borrower_id'); // กำหนดเงื่อนไขการ JOIN
        $builder->where('tb_member.mem_code', $memCode);
        $query = $builder->get();

        return $query->getResult();
    }
}
