<?php
namespace App\Models;

use CodeIgniter\Model;

class ReportModel extends Model
{
    protected $table = 'tb_member';
    protected $primaryKey = 'mem_id';
    protected $allowedFields = ['mem_title', 'mem_fname', 'mem_lname', 'mem_id', 'mem_code', 'mem_status']; 

    // ฟังก์ชันสำหรับการทำ Join 3 ตาราง
    public function getMemberOrderDetails()
    {
        return $this->db->table('tb_member')
            ->select('tb_member.*, tb_credit.*, tb_loans.*,')
            ->join('tb_credit', 'tb_credit.borrower_id = tb_member.mem_code')
            ->join('tb_loans', 'tb_loans.contract_number = tb_credit.contract_number')
            ->get()
            ->getResult();
    }

    // public function searchByContractNumber($contractNumber)
    // {
    //     return $this->where('contract_number', $contractNumber)
    //         ->get()
    //         ->getResult();
    // }

    

    public function searchByMemCode($memCode)
    {
        return $this->select('tb_member.*, tb_credit.*, tb_loans.*')
            ->join('tb_credit', 'tb_credit.borrower_id = tb_member.mem_code')
            ->join('tb_loans', 'tb_loans.contract_number = tb_credit.contract_number')
            ->where('tb_member.mem_code', $memCode)
            ->findAll();
    }

    // Search by contract number
    public function getCreditDetailsByContractNumbers($contractNumber)
    {
        return $this->select('tb_member.*, tb_credit.*, tb_loans.*')
            ->join('tb_credit', 'tb_credit.borrower_id = tb_member.mem_code')
            ->join('tb_loans', 'tb_loans.contract_number = tb_credit.contract_number')
            ->whereIn('tb_credit.contract_number', $contractNumber)
            ->groupBy('tb_credit.contract_number')
            ->findAll();
    }

    
}
