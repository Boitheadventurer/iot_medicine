<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สหกรณ์บริการวิทยาลัยเทคนิคแพร่</title>
    <link href="http://car.ctnphrae.com/assets/img/ptc-1.jpg" rel="icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: #FFBFBF;
            width: 90%;
            max-width: 1050px;
        }

        input[type=text],
        .gg {
            background-color: #FFF6D6;
        }

        input[type="radio"] {
            display: none;
        }

        input[type="radio"]:checked+.radio-label {
            background-color: #F3B774;
            border: 3px solid #FFE075;
        }

        .radio-label {
            display: block;
            padding: 15px 25px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s, color 0.2s;
            background-color: #FFF6D6;
        }

        .radio-label:hover {
            background-color: #FFD09B;
        }

        .radio-label-dis {
            display: block;
            padding: 15px 25px;
            border-radius: 5px;
            cursor: not-allowed;
            transition: background-color 0.2s, color 0.2s;
            background-color: #C2C2C2;
        }

        .radio-label-dis:hover {
            background-color: #A2A2A2;
        }

        .table {
            overflow: hidden;
            border-radius: 8px;
            min-width: 750px;
        }
    </style>
</head>

<body>
    <div class="container rounded my-5 p-4">
        <div class="text-center mb-4">
            <h2 class="fw-bold">สินเชื่อ</h2>
        </div>



        <?php if (session()->getFlashdata('success')) : ?>
            <div class="alert alert-success text-center">
                <?= session()->getFlashdata('success') ?>
            </div>
        <?php elseif (session()->getFlashdata('error')) : ?>
            <div class="alert alert-warning text-center">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form id="outerForm" action="<?php echo base_url('credit/save'); ?>" method="POST">
            <h6 class="fw-bold">สัญญาเงินกู้</h6>
            <div class="row mb-4 text-center">
                <div class="col p-1">
                    <input id="bordered-radio-1" type="radio" value="สามัญ" name="loan_type" class="form-check-input" required>
                    <label for="bordered-radio-1" class="radio-label fw-bold">กู้สามัญ</label>
                </div>
                <div class="col p-1">
                    <input id="bordered-radio-x" type="radio" value="ฉุกเฉิน" name="loan_type" class="form-check-input">
                    <label for="bordered-radio-x" class="radio-label-dis fw-bold">กู้ฉุกเฉิน</label>
                </div>
                <div class="col p-1">
                    <input id="bordered-radio-x" type="radio" value="ไม่เกินค่าหุ้น" name="loan_type" class="form-check-input">
                    <label for="bordered-radio-x" class="radio-label-dis fw-bold">กู้ไม่เกินค่าหุ้น</label>
                </div>
                <div class="col p-1">
                    <input id="bordered-radio-x" type="radio" value="เพื่อการดำรงชีวิต" name="loan_type" class="form-check-input">
                    <label for="bordered-radio-x" class="radio-label-dis fw-bold">กู้เพื่อการดำรงชีวิต</label>
                </div>
                <script>
                    document.getElementById("bordered-radio-x").disabled = true;
                </script>
            </div>

            <div class="mb-4">
                <label for="c ontract_number" class="fw-bold mb-2 h6">เลขที่รหัสสัญญา</label>
                <input required type="text" onkeypress="return isNumberKey(event)" id="contract_number" placeholder="กรอกเลขที่รหัสสัญญา" name="contract_number" class="form-control">
            </div>

            <div class="row mb-4">
                <div class="col">
                    <label for="mem_code" class="fw-bold h6">ผู้ขอกู้</label>
                    <a id="search_member" class="btn btn-warning">ค้นหา</a>
                    <input type="text" id="mem_code" name="borrower_id" class="form-control mt-2" placeholder="ค้นหาสมาชิกด้วยรหัสสมาชิก">
                </div>
            </div>

            <div id="member_search_results">
                <!-- ผลลัพธ์การค้นหาจะแสดงที่นี่ -->
            </div>

            <div class="mb-4" hidden>
                <label for="member_type" class="block text-lg font-medium text-gray-900 mb-2">ประเภทสมาชิก</label>
                <select id="member_type" name="member_type" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    <option value="">ประเภทสมาชิก</option>
                    <?php foreach ($member_types as $type) : ?>
                        <option value="<?= $type['member_type_id'] ?>"><?= $type['member_type'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="text-center mb-4" hidden>
                <h1 class="text-3xl font-bold text-gray-900">วงเงิน</h1>
                <p id="contract_count" class="text-xl text-gray-700">-</p>
            </div>

            <div class="text-center mb-4" hidden>
                <h1 class="text-3xl font-bold text-gray-900">สัญญา</h1>
                <p id="member_cost" class="text-xl text-gray-700">-</p>
            </div>

            <div class="row mb-4">
                <div class="col">
                    <label for="loan_amount" class="fw-bold mb-1">ขอกู้เงินจำนวน</label>
                    <input type="text" onkeypress="return isNumberKey(event)" placeholder="0.00" id="loan_amount" name="loan_amount" class="form-control" required>
                </div>
                <div class="col">
                    <label for="dividend" class="fw-bold mb-1">หารได้</label>
                    <input type="text" id="dividend" placeholder="0.00" name="dividend" class="form-control h" readonly>
                </div>
            </div>

            <div class="flex items-center my-4">
                <label for="loan_amount" class="fw-bold">ผู้ค้ำประกัน</label>
                <button type="button" id="addGuarantorButton" class="btn btn-warning">
                    เพิ่มผู้ค้ำประกัน
                </button>
            </div>

            <div class="table-responsive">
                <table class="table table-striped table-danger bg-danger table-bordered text-center">
                    <thead>
                        <tr>
                            <th scope="col">ลำดับ</th>
                            <th scope="col" class="w-25">รหัสประจำตัวสมาชิก</th>
                            <th scope="col" class="w-25">รายชื่อ</th>
                            <th scope="col" class="w-25">สถานะ</th>
                            <th scope="col" class="w-25">จำนวนเงิน</th>
                        </tr>
                    </thead>
                    <tbody id="guarantorTableBody">
                        <tr>
                            <th>1</th>
                            <td>
                                <div class="row">
                                    <div class="col">
                                        <input type="text" onkeypress="return isNumberKey(event)" name="guarantors[0][mem_code]" class="guarantor-query form-control w-100" required placeholder="รหัสสมาชิก">
                                    </div>
                                    <div class="col">
                                        <a class="guarantor-search-button btn btn-warning w-100">ค้นหา</a>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span id="guarantor-status">-</span>
                            </td>
                            <td>
                                <div id="contract-count"></div>
                                <div id="member-cost">-</div>
                                <div id="member-cost2"></div>
                                <div id="hidden-data-1" hidden></div>
                                <div id="hidden-data-2" hidden></div>
                                <div id="hidden-data-3" hidden></div>
                            </td>
                            <td>
                                <input type="text" name="guarantors[0][dividend]" value="0.00" class="form-control w-100" readonly />
                                <button type="button" class="deleteButton btn btn-danger form-control w-100">ลบ</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="text-center">
                <button type="submit" id="saveButton" class="btn btn-success w-25 mx-auto">
                    บันทึก
                </button>
            </div>
        </form>
    </div>

    <script>
        //กรอกเฉพาะตัวเลขเท่านั้น
        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode != 46 && charCode > 31 &&
                (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
    </script>


    <script>
        $(document).ready(function() {
            let guarantorCount = 1;
            let status, contractCount, sm, max, t, diviice, cost, max_cos, loancost, loanCount, mem_code;
            let all_info = []; //Highlight*
            let statusToIdMap = {};
            loadStatusToIdMap();

            function loadStatusToIdMap() {
                $.ajax({
                    url: '<?= base_url('report/getStatusToIdMap') ?>',
                    method: 'GET',
                    success: function(data) {
                        statusToIdMap = data;
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            }

            function updateGuarantorStatus(row, status) {
                status = status.trim();
                $.ajax({
                    url: '<?= base_url('member_type_details2') ?>',
                    method: 'POST',
                    data: {
                        member_type: status
                    },
                    success: function(response) {
                        //console.log(response);
                        if (response.contract_count && response.member_cost) {
                            cost = response.member_cost;
                            max_cos = response.contract_count;
                            
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            }

            function searchLoanDetails(mem_code, row, callback) {
                $.ajax({
                    url: '<?= base_url('credit/searchLoanDetails') ?>',
                    method: 'POST',
                    data: {
                        mem_code: mem_code
                    },
                    success: function(data) {

                        if (data) {
                            let totalLoanAmount = 0;
                            let loanDetailsHtml = '';
                            let loans = 0;
                            let cost2 = 0;
                            let loanAmount = 0;
                            let maxx = 0;
                            loanCount = 0;

                            data.forEach(function(loan) {
                                loanAmount = parseFloat(loan.dividend) || 0;
                                totalLoanAmount += loanAmount;
                                loanCount += 1;

                            });
                            loanDetailsHtml += `<strong>มีจำนวนสัญญา : </strong> ${loanCount} / ${max_cos}<br>`;
                            loanDetailsHtml += `<strong>วงเงินเหลือ : </strong>${loancost = cost - totalLoanAmount}`;
                            row.find('#member-cost2').html(loanDetailsHtml); // loanDetailsHtml = loanCount + max_cos + loancost 
                            row.find('#hidden-data-1').val(loanCount);
                            row.find('#hidden-data-2').val(max_cos);
                            row.find('#hidden-data-3').val(loancost = cost - totalLoanAmount);
                        } else {
                            row.find('#member-cost2').text('ไม่พบข้อมูล');
                            row.find('#hidden-data-1').val('');
                            row.find('#hidden-data-2').val('');
                            row.find('#hidden-data-3').val('');
                        }
                        if (typeof callback === 'function') {
                        callback();
                    }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            }

            function searchMember(query, resultElement, row) {
                $.ajax({
                    url: '<?= base_url('search') ?>',
                    method: 'POST',
                    data: {
                        query: query
                    },
                    success: function(data) {
                        resultElement.empty();
                        row.find('#guarantor-status').empty();
                        row.find('#member-cost').empty();
                        row.find('#contract-count').empty();
                        row.find('#member-cost2').empty();
                        row.find('#hidden-data-1').empty();
                        row.find('#hidden-data-2').empty();
                        row.find('#hidden-data-3').empty();
                        if (data.length > 0) {
                            data.forEach(function(item) {
                                resultElement.append(item.mem_title + ' ' + item.mem_fname + ' ' + item.mem_lname);
                                let status = item.mem_status;
                                updateGuarantorStatus(row, status);
                                row.find('#guarantor-status').append(`${item.mem_title} ${item.mem_fname} ${item.mem_lname} <br> ${status}`);
                                mem_code = item.mem_code;
                                searchLoanDetails(mem_code, row, function() {
                                    searchLoanDetails(mem_code, row);
                                });
                            });
                        } else {
                            row.find('#guarantor-status').append('<p class="text-danger">ไม่พบข้อมูล</p>');
                            row.find('#member-cost').append('<p class="text-danger">ไม่พบข้อมูล</p>');
                            row.find('#member-cost2').append('');
                        }

                        row.find('.guarantor-query').trigger('change');
                    }
                });
            }

            

            function updateMemberTypeDetails(memberTypeId, callback) {
                if (memberTypeId) {
                    $.ajax({
                        url: '<?= base_url('member_type_details') ?>',
                        method: 'POST',
                        data: {
                            member_type_id: memberTypeId
                        },
                        success: function(data) {
                            let result = JSON.parse(data);

                            if (result.contract_count && result.member_cost) {
                                $('#contract_count').text(result.member_cost);
                                $('#member_cost').text(result.contract_count);
                                max = result.contract_count;
                                contractCount = parseFloat(result.member_cost) || 0;
                                if (typeof callback === "function") {
                                    callback();
                                }
                            } else {
                                $('#contract_count').text('-');
                                $('#member_cost').text('-');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                } else {
                    $('#contract_count').text('-');
                    $('#member_cost').text('-');
                }
            }

            function updateDividend() {
                let loanAmount = parseFloat($('#loan_amount').val()) || 0;
                let dividend = loanAmount / guarantorCount;
                diviice = dividend;
                $('#dividend').val(dividend.toFixed(2));

                $('#guarantorTableBody tr').each(function() {
                    $(this).find('input[name$="[dividend]"]').val(dividend.toFixed(2));
                });
            }

            function addDeleteFunctionality() {
                $('.deleteButton').off('click').on('click', function() {
                    $(this).closest('tr').remove();
                    updateRowNumbers();
                    guarantorCount--;
                    updateDividend();
                });

                $('.guarantor-query').off('change').on('change', updateGuarantorFields);
            }

            function updateRowNumbers() {
                $('#guarantorTableBody tr').each(function(index) {
                    $(this).find('th').text(index + 1);
                    $(this).find('input').each(function() {
                        const name = $(this).attr('name');
                        if (name) {
                            $(this).attr('name', name.replace(/\[\d+\]/, `[${index}]`));
                        }
                    });
                });
            }

            function updateGuarantorFields() {
                const input = $(this);
                const row = input.closest('tr');
                const rowIndex = row.index();
                const mem_code = input.val();

                input.attr('name', `guarantors[${rowIndex}][mem_code]`);
                row.find('input[name$="[dividend]"]').attr('name', `guarantors[${rowIndex}][dividend]`);

                const borrowerId = $('#mem_code').val();

                let duplicate = false;
                $('#guarantorTableBody .guarantor-query').each(function() {
                    if ($(this).val() === mem_code && $(this).get(0) !== input.get(0)) {
                        duplicate = true;
                    }
                });

                if (mem_code === borrowerId) {
                    alert('รหัสสมาชิกผู้ค้ำประกันไม่สามารถเป็นผู้ขอกู้ได้');
                    input.val('-');
                    row.find('.guarantor-name').text('-');
                    updateGuarantorFields.call(input);
                    return;
                }

                if (duplicate) {
                    alert('รหัสสมาชิกผู้ค้ำประกันซ้ำ');
                    input.val('-');
                    row.find('.guarantor-name').text('-');
                    updateGuarantorFields.call(input);
                    return;
                }
            }



            $('#search-button-borrower').click(function() {
                let query = $('#search-query-borrower').val();
                let resultElement = $('#search-results-borrower');
                searchMember(query, resultElement);
            });

            $(document).on('click', '.guarantor-search-button', function() {
                let row = $(this).closest('tr');
                let query = row.find('.guarantor-query').val();
                let resultElement = row.find('#guarantor-results');
                searchMember(query, resultElement, row);
            });

            $('#loan_amount').on('input', updateDividend);

            $('#addGuarantorButton').click(function() {
                if (guarantorCount < 6) {
                    const tableBody = $('#guarantorTableBody');
                    const newRow = `
                    <tr>
                        <th>${guarantorCount + 1}</th>
                        <td>
                            <div class="row">
                                <div class="col">
                                    <input type="text" name="guarantors[${guarantorCount}][mem_code]" class="guarantor-query form-control w-100" placeholder="รหัสสมาชิก">
                                </div>
                                <div class="col">
                                    <a class="guarantor-search-button form-control w-100 btn btn-warning">ค้นหา</a>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span id="guarantor-status">-</span>
                        </td>
                        <td>
                            <div id="contract-count">-</div>
                            <div id="member-cost"></div>
                            <div id="member-cost2"></div>
                            <div id="hidden-data-1" hidden></div>
                            <div id="hidden-data-2" hidden></div>
                            <div id="hidden-data-3" hidden></div>
                        </td>
                        <td>
                            <input type="text" name="guarantors[${guarantorCount}][dividend]"  class="form-control" readonly />
                            <button type="button" class="deleteButton btn btn-danger form-control w-100">ลบ</button>
                        </td>
                    </tr>`;
                    tableBody.append(newRow);
                    
                    all_info.push({
                        mem_code: '',
                        loanCost: loancost,
                        loanCount: loanCount,
                        maxCos: max_cos
                    });
                    
                    guarantorCount++;
                    addDeleteFunctionality();
                    updateDividend();
                }
            });

            addDeleteFunctionality();

            $('#member_type').change(function() {
                let memberTypeId = $(this).val();
                updateMemberTypeDetails(memberTypeId);
            });

            $('#search_member').click(function() {
                let memCode = $('#mem_code').val();
                $('#member_search_results').html('');
                $('#member_type').val('');
                $('#contract_count').text('-');
                $('#member_cost').text('-');
                contractCount = 0;

                if (memCode) {
                    $.ajax({
                        url: '<?= base_url('search_member_by_code') ?>',
                        method: 'POST',
                        data: {
                            mem_code: memCode
                        },
                        success: function(data) {
                            let result = JSON.parse(data);
                            let html = '';

                            if (result) {
                                if (result.mem_title !== undefined) {
                                    html = `
                                        <div class="gg rounded p-4 mb-3">
                                            <strong>ชื่อ-สกุล :</strong> ${result.mem_title} ${result.mem_fname} ${result.mem_lname}<br>
                                            <strong>สถานะ :</strong> ${result.mem_status}
                                        </div>
                                    `;
                                }
                                if (result.credit && result.credit.length >= 0) {
                                    let totalLoanAmount = 0;
                                    let loanAmounts = [];
                                    sm = result.credit.length;

                                    result.credit.forEach(function(credit) {
                                        loanAmounts.push(parseFloat(credit.loan_amount) || 0);
                                        html += `
                                            <div class="gg rounded p-4 mb-3" hidden>
                                                <strong>สัญญาที่ :</strong> ${credit.contract_number}<br>
                                                <strong>วงเงิน :</strong> ${credit.loan_amount}
                                            </div>
                                        `;
                                    });
                                    totalLoanAmount = loanAmounts.reduce((acc, current) => acc + current, 0);
                                    let memberTypeId = statusToIdMap[result.mem_status.trim()];
                                    if (memberTypeId) {
                                        $('#member_type').val(memberTypeId);
                                        updateMemberTypeDetails(memberTypeId, function() {
                                            t = contractCount - totalLoanAmount;
                                            t = isNaN(t) ? 0 : t;
                                            $('#member_cost').text(t);
                                            $('#hidden_t').val(t);
                                            html += `
                                                <div class="gg rounded p-4 mb-3">
                                                    <strong>มีจำนวนสัญญา :</strong> ${sm} / ${max}<br>
                                                    <strong>วงเงินเหลือ :</strong> ${t}
                                                </div>`;
                                            $('#member_search_results').html(html);
                                        });
                                    } else {
                                        $('#member_search_results').html(html);
                                    }
                                } else {
                                    html += `<div class="bg-danger text-light rounded p-4 mb-3">
                                        <strong>ไม่มีรหัสสมาชิกในฐานข้อมูล</strong>
                                    </div>`;
                                    $('#member_search_results').html(html);
                                }
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                } else {
                    $('#member_search_results').html(`<div class="bg-danger text-light rounded p-4 mb-3">
                        <strong>กรุณากรอกรหัสสมาชิก<strong>
                    </div>`);
                }
            });

            // Edit
            $('#saveButton').click(function(event) {
                let loanAmount = parseFloat($('#loan_amount').val().replace(/,/g, ''));
                let dividendAmount = parseFloat($('#dividend').val().replace(/,/g, ''));
                let errorMessage = '';

                all_info = [];

                $('#guarantorTableBody tr').each(function(index) {
                    const memCode = $(this).find('input[name^="guarantors"]')[0].value;
                    const dividend = $(this).find('input[name^="guarantors"][name$="[dividend]"]').val();
                    const loanDetails = {
                        mem_code: Number(memCode) || 0,
                        loanCost: Number($(this).find('#hidden-data-3').val()) || 0,
                        loanCount: Number($(this).find('#hidden-data-1').val()) || 0,
                        maxCos: Number($(this).find('#hidden-data-2').val()) || 0
                    };
                    all_info.push(loanDetails);
                });
                console.log(all_info);

                // Validate the form data
                if (isNaN(loanAmount) || isNaN(guarantorCount)) {
                    errorMessage = 'ผิดพลาด 1 กรุณากรอกข้อมูลให้ครบถ้วน';
                } else if (loanAmount > t) {
                    console.log(loanAmount + ' loanAmount');
                    console.log(t + ' t');
                    errorMessage = 'ผิดพลาด 2 ตรวจพบจำนวนเงินขอกู้ เกินกว่าจำนวนเงินผู้กู้';
                } else if (all_info.some(info => dividendAmount > info.loanCost)) {
                    console.log(dividendAmount + ' dividendAmount');
                    console.log(all_info.map(info => info.loanCost) + ' all_info.loanCost');
                    errorMessage = 'ผิดพลาด 3 ตรวจพบจำนวนเงินขอกู้ เกินกว่าจำนวนวงเงินค้ำ';
                } else if (all_info.some(info => info.loanCount >= info.maxCos)) {
                    console.log(all_info.map(info => info.loanCount) + ' all_info.loanCount');
                    console.log(all_info.map(info => info.maxCos) + ' all_info.maxCos');
                    errorMessage = 'ผิดพลาด 4 ตรวจพบจำนวนสัญญาผู้ค้ำครบกำหนด';
                } else if (sm >= max) {
                    console.log(sm + ' sm');
                    console.log(max + ' max');
                    errorMessage = 'ผิดพลาด 5 ตรวจพบจำนวนสัญญาผู้กู้ครบกำหนด';
                }

                if (errorMessage) {
                    alert(errorMessage);
                    event.preventDefault();
                }
            });
            // End Edit

            $('#contract_number').on('blur', function() {
                let contractNumber = $(this).val();

                if (contractNumber) {
                    $.ajax({
                        url: '<?= base_url('credit/check_contract_number') ?>',
                        method: 'POST',
                        data: {
                            contract_number: contractNumber
                        },
                        success: function(response) {
                            if (response.exists) {
                                alert('มีหมายเลขสัญญานี้แล้ว');
                                $('#contract_number').val('');
                                $('#contract_number').focus();
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                }
            });

            $('#outerForm').on('submit', function(event) {
                let contractNumber = $('#contract_number').val();
                if (!contractNumber) {
                    event.preventDefault();
                    alert('กรุณากรอกเลขที่สัญญาใหม่');
                }
            });
        });
    </script>



    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>

</html>