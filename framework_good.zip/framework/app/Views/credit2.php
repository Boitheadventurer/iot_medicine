<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">
    <div class="mx-auto w-4/5 mt-5 bg-white p-6 rounded-lg shadow-lg">
        <div class="text-center mb-4">
            <h1 class="text-3xl font-bold text-gray-900">สินเชื่อ</h1>
        </div>
        <h1 class="text-lg mb-3 font-medium text-gray-900">สัญญาเงินกู้</h1>

        <form id="outerForm" action="<?php echo base_url('credit/save'); ?>" method="POST">
            <div class="w-full mb-3">
                <div class="flex items-center border border-gray-200 rounded p-3 mb-2">
                    <input id="bordered-radio-1" type="radio" value="สามัญ" name="loan_type" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2">
                    <label for="bordered-radio-1" class="ml-2 text-sm font-medium text-gray-900">กู้สามัญ</label>
                </div>
                <div class="flex items-center border border-gray-200 rounded p-3 mb-2">
                    <input id="bordered-radio-2" type="radio" value="ฉุกเฉิน" name="loan_type" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2">
                    <label for="bordered-radio-2" class="ml-2 text-sm font-medium text-gray-900">กู้ฉุกเฉิน</label>
                </div>
                <div class="flex items-center border border-gray-200 rounded p-3">
                    <input id="bordered-radio-3" type="radio" value="ไม่เกินค่าหุ้น" name="loan_type" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2">
                    <label for="bordered-radio-3" class="ml-2 text-sm font-medium text-gray-900">กู้ไม่เกินค่าหุ้น</label>
                </div>
            </div>
            <div class="mb-4">
                <label for="contract_number" class="block text-lg font-medium text-gray-900 mb-2">เลขที่สัญญา</label>
                <input type="text" id="contract_number" name="contract_number" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            </div>
            
            <div class="mb-4">
                <h1>ผู้ขอกู้</h1>
                <input type="text" id="search-query-borrower" name="borrower_id" class="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="ค้นหาด้วยรหัส">
                <a id="search-button-borrower" class="inline-flex items-center px-4 py-2 text-lg font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
                <h1 id="search-results-borrower" class="ml-2 text-lg font-medium text-gray-900"></h1>
            </div>

            <div class="mb-4">
                <label for="loan_amount" class="block text-lg font-medium text-gray-900 mb-2">วงเงินที่กู้ได้</label>
                <input type="text" id="loan_amount" name="loan_amount" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            </div>
            <div class="mb-4">
                <label for="dividend" class="block text-lg font-medium text-gray-900 mb-2">หารได้</label>
                <input type="text" id="dividend" name="dividend" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" readonly />
            </div>



            <div class="relative overflow-x-auto my-4">
                <div class="flex items-center my-4">
                    <label for="loan_amount" class="block text-lg font-medium text-gray-900 mb-2">ผู้ค้ำประกัน</label>
                    <button type="button" id="addGuarantorButton" class="ml-auto inline-flex items-center px-4 py-2 text-lg font-medium text-center text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500 dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-400">
                        เพิ่มผู้ค้ำประกัน
                    </button>
                </div>
                <?php $index = 1; ?>
                <table class="w-full text-lg text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left">ลำดับ</th>
                            <th scope="col" class="px-6 py-3">รหัส</th>
                            <th scope="col" class="px-6 py-3">รายชื่อ</th>
                            <th scope="col" class="px-6 py-3 text-right">จำนวนเงิน</th>
                            <th scope="col" class="px-6 py-3 text-right">ลบ</th>
                        </tr>
                    </thead>
                    <tbody id="guarantorTableBody">
                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <th scope="row" class="px-6 py-4 font-medium text-left text-gray-900 whitespace-nowrap dark:text-white"><?php echo $index++ ?></th>

                            <td class="px-6 py-4">
                                <input type="text" name="borrower_id" class="guarantor-query px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="ค้นหาด้วยรหัส">
                                <a class="guarantor-search-button inline-flex items-center px-4 py-2 text-lg font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
                            </td>
                            <td class="px-6 py-4 guarantor-name" id="guarantor-results"></td>

                            <td class="px-6 py-4">
                                <input type="text" readonly id="dividend" name="dividend" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" readonly />
                            </td>

                            <td class="px-6 py-4 text-right">
                                <button type="button" class="text-red-600 hover:text-red-900 deleteButton">ลบ</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="text-center">
                <button type="submit" class="inline-flex items-center px-4 py-2 text-lg font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">
                    บันทึก
                </button>
            </div>
        </form>
    </div>


    <script>
        $(document).ready(function() {
            function searchMember(query, resultElement, row) {
                $.ajax({
                    url: '<?= base_url('search') ?>',
                    method: 'POST',
                    data: {
                        query: query
                    },
                    success: function(data) {
                        resultElement.empty();
                        if (data.length > 0) {
                            data.forEach(function(item) {
                                resultElement.append('<p>' + item.mem_title + ' ' + item.mem_fname + ' ' + item.mem_lname + '</p>');
                            });
                        } else {
                            resultElement.append('<p>ไม่พบข้อมูล</p>');
                        }
                        row.querySelector('.guarantor-query').dispatchEvent(new Event('change'));
                    }
                });
            }

            $('#search-button-borrower').click(function() {
                let query = $('#search-query-borrower').val();
                let resultElement = $('#search-results-borrower');
                searchMember(query, resultElement);
            });

            $(document).on('click', '.guarantor-search-button', function() {
                let row = $(this).closest('tr');
                let query = row.find('.guarantor-query').val();
                let resultElement = row.find('#guarantor-results');
                searchMember(query, resultElement, row);
            });

            function updateDividend() {
                let loanAmount = parseFloat($('#loan_amount').val()) || 0;
                let dividend = loanAmount / guarantorCount;
                $('#dividend').val(dividend.toFixed(2)); // Show the result with 2 decimal places

                // Update dividend for each guarantor
                $('#guarantorTableBody tr').each(function() {
                    $(this).find('input[name^="dividend"]').val(dividend.toFixed(2));
                });
            }

            // Update dividend when the loan amount changes
            $('#loan_amount').on('input', updateDividend);

            let guarantorCount = 1;

            document.getElementById('addGuarantorButton').addEventListener('click', function() {
                if (guarantorCount < 6) {
                    guarantorCount++;
                    const tableBody = document.getElementById('guarantorTableBody');
                    const newRow = document.createElement('tr');
                    newRow.className = 'bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600';
                    newRow.innerHTML = `
            <th scope="row" class="px-6 py-4 font-medium text-left text-gray-900 whitespace-nowrap dark:text-white">${guarantorCount}</th>
           
            <td class="px-6 py-4">
                                <input type="text" name="mem_code" class="guarantor-query px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="ค้นหาด้วยรหัส">
                                <a class="guarantor-search-button inline-flex items-center px-4 py-2 text-lg font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
                </td>

                <td class="px-6 py-4 guarantor-name" id="guarantor-results">-</td>
            <td class="px-6 py-4">
            <input type="text" readonly id="dividend" name="dividend" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" readonly />
            </td>
            <td class="px-6 py-4 text-right">
                <button type="button" class="text-red-600 hover:text-red-900 deleteButton">ลบ</button>
            </td>
        `;
                    tableBody.appendChild(newRow);
                    addDeleteFunctionality();
                    newRow.querySelector('.guarantor-query').addEventListener('change', updateGuarantorFields);
                    updateDividend();
                }
            });

            function addDeleteFunctionality() {
                document.querySelectorAll('.deleteButton').forEach(button => {
                    button.removeEventListener('click', handleDeleteRow);
                    button.addEventListener('click', handleDeleteRow);
                });

                document.querySelectorAll('.guarantor-query').forEach(input => {
                    input.removeEventListener('change', updateGuarantorFields);
                    input.addEventListener('change', updateGuarantorFields);
                });

                // Ensure dividend is up-to-date
                updateDividend();
            }

            function handleDeleteRow(event) {
                const row = event.target.closest('tr');
                row.remove();
                updateRowNumbers();
                guarantorCount--;
                updateDividend(); // Update dividend when deleting a row
            }

            function updateRowNumbers() {
                const rows = document.querySelectorAll('#guarantorTableBody tr');
                rows.forEach((row, index) => {
                    row.querySelector('th').innerText = index + 1;
                });
            }

            addDeleteFunctionality();

            function createHiddenField(name, value) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = name;
                input.value = value;
                return input;
            }

            function updateGuarantorFields(event) {
                const input = event.target;
                const row = input.closest('tr');
                const rowIndex = Array.from(row.parentNode.children).indexOf(row);
                const mem_code = input.value;
                const name = row.querySelector('.guarantor-results').innerText;

                const form = document.getElementById('outerForm');

                let mem_code_field = document.querySelector(`input[name="guarantor[${rowIndex}][mem_code]"]`);
                if (!mem_code_field) {
                    mem_code_field = createHiddenField(`guarantor[${rowIndex}][mem_code]`, mem_code);
                    form.appendChild(mem_code_field);
                } else {
                    mem_code_field.value = mem_code;
                }

                let name_field = document.querySelector(`input[name="guarantor[${rowIndex}][name]"]`);
                if (!name_field) {
                    name_field = createHiddenField(`guarantor[${rowIndex}][name]`, name);
                    form.appendChild(name_field);
                } else {
                    name_field.value = name;
                }

                // Update dividend when the guarantor fields change
                updateDividend();
            }
        });
    </script>


</body>

</html>