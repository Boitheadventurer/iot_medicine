<!DOCTYPE html>
<html>
<head>
    <title>Welcome to CodeIgniter</title>
</head>
<body>
    <h1>Welcome to CodeIgniter!</h1>
    <p>This is the home page.</p>
    <a href="<?= base_url('member') ?>">รายชื่อสมาชิก</a><p></p>
    <a href="<?= base_url('member_type') ?>">สัญญาและวงเงิน</a><p></p>
    <a href="<?= base_url('credit') ?>">สินเชื่อ</a><p></p>
    <a href="<?= base_url('report') ?>">ค้นหาผู้กู้</a><p></p>
    <a href="<?= base_url('report_mem') ?>">ค้นหาคนค้ำ</a><p></p>
    <a href="<?= base_url('report_num') ?>">ค้นหาสัญญา</a><p></p>
</body>
</html>
