<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขสถานะผู้ใช้งาน</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100">
    <div class="mx-auto w-4/5 mt-5 bg-white p-6 rounded-lg shadow-lg">
        <h1 class="text-2xl font-bold text-gray-900 mb-4">แก้ไขสถานะผู้ใช้งาน</h1>

        <?= \Config\Services::validation()->listErrors(); ?>

        <form action="<?= base_url('member_type/update/' . $status['member_type_id']) ?>" method="post">
            <?= csrf_field() ?>
            <div class="mb-4">
                <label for="member_type" class="block text-sm font-medium text-gray-700">สถานะ</label>
                <input type="text" id="member_type" name="member_type" value="<?= $status['member_type'] ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required />
            </div>
            <div class="mb-4">
                <label for="member_cost" class="block text-sm font-medium text-gray-700">วงเงิน</label>
                <input type="number" id="member_cost" name="member_cost" value="<?= $status['member_cost'] ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
            </div>
            <div class="mb-4">
                <label for="contract_count" class="block text-sm font-medium text-gray-700">จำนวนสัญญา</label>
                <input type="number" id="contract_count" name="contract_count" value="<?= $status['contract_count'] ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
            </div>
            <button type="submit" class="inline-flex items-center px-4 py-2 text-lg font-medium text-center text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500 dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-400">
                อัปเดตสถานะ
            </button>
            <a href="../" class="inline-flex items-center px-4 py-2 text-lg font-medium text-center text-white bg-red-600 rounded-lg hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-400">
                ยกเลิก
            </a>
        </form>
    </div>
</body>

</html>
