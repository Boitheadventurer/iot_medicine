<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">
    <div class="mx-auto w-4/5 mt-5 bg-white p-6 rounded-lg shadow-lg">
        <div class="text-center mb-4">
            <h1 class="text-3xl font-bold text-gray-900">สินเชื่อ</h1>
        </div>

        <div class="mb-4">
            <label for="mem_code" class="block text-lg font-medium text-gray-900 mb-2">ค้นหาสมาชิกด้วยรหัส</label>
            <div class="flex space-x-2">
                <input type="text" id="mem_code" name="mem_code" placeholder="กรอกรหัสสมาชิก" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <button id="search_member" class="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</button>
            </div>
        </div>

        <div id="member_search_results" class="mb-4">
            <!-- ผลลัพธ์การค้นหาจะแสดงที่นี่ -->
        </div>

        <div class="mb-4">
            <label for="member_type" class="block text-lg font-medium text-gray-900 mb-2">ประเภทสมาชิก</label>
            <select id="member_type" name="member_type" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <option value="">เลือกประเภทสมาชิก</option>
                <?php foreach ($member_types as $type) : ?>
                    <option value="<?= $type['member_type_id'] ?>"><?= $type['member_type'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="text-center mb-4">
            <h1 class="text-3xl font-bold text-gray-900">วงเงิน</h1>
            <p id="contract_count" class="text-xl text-gray-700">-</p>
        </div>

        <div class="text-center mb-4">
            <h1 class="text-3xl font-bold text-gray-900">สัญญา</h1>
            <p id="member_cost" class="text-xl text-gray-700">-</p>
        </div>

    </div>

    <script>
        $(document).ready(function() {
            const statusToIdMap = {
                "ครู": "2",
                "เจ้าหน้าที่": "3",
                "บุคคลทั่วไป": "4"
            };

            function updateMemberTypeDetails(memberTypeId) {
                if (memberTypeId) {
                    $.ajax({
                        url: '<?= base_url('member_type_details') ?>',
                        method: 'POST',
                        data: {
                            member_type_id: memberTypeId
                        },
                        success: function(data) {
                            let result = JSON.parse(data);

                            if (result.contract_count && result.member_cost) {
                                $('#contract_count').text(result.member_cost);
                                $('#member_cost').text(result.contract_count);
                            } else {
                                $('#contract_count').text('-');
                                $('#member_cost').text('-');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                } else {
                    $('#contract_count').text('-');
                    $('#member_cost').text('-');
                }
            }

            $('#member_type').change(function() {
                let memberTypeId = $(this).val();
                updateMemberTypeDetails(memberTypeId);
            });

            $('#search_member').click(function() {
                let memCode = $('#mem_code').val();
                $('#member_search_results').html('');
                $('#member_type').val('');
                $('#contract_count').text('-');
                $('#member_cost').text('-');

                if (memCode) {
                    $.ajax({
                        url: '<?= base_url('search_member_by_code') ?>',
                        method: 'POST',
                        data: {
                            mem_code: memCode
                        },
                        success: function(data) {
                            let result = JSON.parse(data);
                            let html = '';

                            if (result) {
                                html = `
                                    <div class="p-4 bg-gray-200 rounded-md md-4">
                                        <p><strong>ชื่อ-สกุล:</strong> ${result.mem_title} ${result.mem_fname} ${result.mem_lname}</p>
                                        <p><strong>สถานะ:</strong> ${result.mem_status}</p>
                                    </div>
                                `;
                                if (result.credit && result.credit.length > 0) {
                                    let totalLoanAmount = 0;
                                    let loanAmounts = [];

                                    result.credit.forEach(function(credit) {
                                        loanAmounts.push(parseFloat(credit.loan_amount));
                                        html += `
                                            <div class="p-4 bg-gray-200 rounded-md my-4">
                                                <p><strong>วงเงิน:</strong> ${credit.loan_amount}</p>
                                                <p><strong>สัญญา:</strong> ${credit.contract_number}</p>
                                            </div>
                                        `;
                                    });
                                    totalLoanAmount = loanAmounts.reduce((acc, current) => acc + current, 0);
                                    html += `
                                        <div class="p-4 bg-gray-200 rounded-md my-4">
                                            <p><strong>รวมวงเงิน:</strong> ${totalLoanAmount}</p>
                                        </div>
                                    `;
                                } else {
                                    html += '<p>ไม่มีข้อมูลเครดิตสำหรับสมาชิกนี้</p>';
                                }

                                var moon = result.mem_status.trim();
                                let memberTypeId = statusToIdMap[moon];
                                if (memberTypeId) {
                                    $('#member_type').val(memberTypeId);
                                    updateMemberTypeDetails(memberTypeId);
                                } else {
                                    console.error("No matching member type ID for status: ", moon);
                                }
                            } else {
                                html = '<p>ไม่พบข้อมูลสมาชิกที่มีรหัสนี้</p>';
                            }

                            $('#member_search_results').html(html);
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                } else {
                    $('#member_search_results').html('<p>กรุณากรอกรหัสสมาชิก</p>');
                }
            });
        });
    </script>
</body>
</html>
