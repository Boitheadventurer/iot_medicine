<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สหกรณ์บริการวิทยาลัยเทคนิคแพร่</title>
    <link href="http://car.ctnphrae.com/assets/img/ptc-1.jpg" rel="icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: #FFBFBF;
            width: 90%;
            max-width: 1050px;
        }

        input[type=text], .gg {
            background-color: #FFF6D6;
        }
    </style>
</head>

<body>
    <div class="container rounded my-5 p-4">
        <div class="text-center mb-4">
            <h2 class="fw-bold">รายงาน</h2>
        </div>

        <!-- <div class="mb-4">
            <label for="mem_code" class="block text-lg font-medium text-gray-900 mb-2">ค้นหาสมาชิกด้วยรหัส</label>
            <div class="flex space-x-2">
                <input type="text" id="mem_code" name="borrower_id" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <a id="search_member" class="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
            </div>
        </div> -->

        <div id="member_search_results" class="mb-4">
            <!-- ผลลัพธ์การค้นหาจะแสดงที่นี่ -->
        </div>


        <div class="row mb-4">
        <label for="contract_number" class="fw-bold h6">ค้นหารหัสสมาชิก</label>
            <div class="col-10">
                <input type="text" onkeypress="return isNumberKey(event)" id="code_borrowid" name="code_borrowid" class="form-control">
            </div>
            <div class="col-2">
                <button id="search_borrowid" class="btn btn-warning w-100">ค้นหา</button>
            </div>
            <!-- input contract_number -->
            <!-- a search_contract -->
        </div>

        <div id="contract_search_results" class="mb-4">
            <!-- แสดงข้อมูลผู้กู้ -->
        </div>

        <div id="loan_details" class="mb-4">
            <!-- แสดงข้อมูลผู้ค้ำ -->
        </div>

        <div id="borrower_details" class="mb-4">
            <!-- ผลลัพธ์การค้นหา tb_loans จะแสดงที่นี่ -->
        </div>

    </div>

    <script>
        //กรอกเฉพาะตัวเลขเท่านั้น
        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode != 46 && charCode > 31 &&
                (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
    </script>

    <script>
        $(document).ready(function() {
            let guarantorCount = 1;
            let contractCount = 0;
            let sm = 0;
            let index = 1;
            let max = 0;
            let t = 0;
            let bw = 0;
            let get_title, get_fname, get_lname, get_sttus;
            let statusToIdMap = {};

            $('#search-button-borrower').click(function() {
                let query = $('#search-query-borrower').val();
                let resultElement = $('#search-results-borrower');
                searchMember(query, resultElement);
            });

            $(document).on('click', '.guarantor-search-button', function() {
                let row = $(this).closest('tr');
                let query = row.find('.guarantor-query').val();
                let resultElement = row.find('#guarantor-results');
                searchMember(query, resultElement, row);
            });

            $('#search-button-borrower').click(function() {
                let query = $('#search-query-borrower').val();
                let resultElement = $('#search-results-borrower');
                searchMember(query, resultElement);
            });

            $(document).on('click', '.guarantor-search-button', function() {
                let row = $(this).closest('tr');
                let query = row.find('.guarantor-query').val();
                let resultElement = row.find('#guarantor-results');
                searchMember(query, resultElement, row);
            });

            function loadStatusToIdMap() {
                $.ajax({
                    url: '<?= base_url('report/getStatusToIdMap') ?>',
                    method: 'GET',
                    success: function(data) {
                        statusToIdMap = data;
                        console.log(statusToIdMap);
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            }

            loadStatusToIdMap();

            function updateMemberTypeDetails(memberTypeId, callback) {
                if (memberTypeId) {
                    $.ajax({
                        url: '<?= base_url('member_type_details') ?>',
                        method: 'POST',
                        data: {
                            member_type_id: memberTypeId
                        },
                        success: function(data) {
                            let result = JSON.parse(data);

                            if (result.contract_count && result.member_cost) {
                                $('#contract_count').text(result.member_cost);
                                $('#member_cost').text(result.contract_count);
                                max = result.contract_count;
                                contractCount = parseFloat(result.member_cost) || 0;
                                if (typeof callback === "function") {
                                    callback();
                                }
                            } else {
                                $('#contract_count').text('-');
                                $('#member_cost').text('-');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                } else {
                    $('#contract_count').text('-');
                    $('#member_cost').text('-');
                }
            }

            $('#member_type').change(function() {
                let memberTypeId = $(this).val();
                updateMemberTypeDetails(memberTypeId);
            });

            // Start Edit
            $('#search_borrowid').click(function() {
                let CodeBorrw = $('#code_borrowid').val();

                if (CodeBorrw) {
                    $.ajax({
                        url: '<?= base_url('report/searchByContractNumber') ?>',
                        method: 'POST',
                        data: {
                            code_borrowid: CodeBorrw
                        },
                        success: function(data) {
                            let html = '';
                            if (data.length > 0) {
                                let contractNumbers = [];
                                let promises = data.map(function(item) {
                                    bw = item.borrower_id;
                                    contractNumbers.push(item.contract_number); // เก็บ contract_number ทุกตัว
                                    return searchBorrowerDetails(bw).then(function() {
                                        html += `
                                            <div class="rounded my-4 p-4 gg">
                                                <strong>ข้อมูลสมาชิก :</strong> ${get_title} ${get_fname} ${get_lname} ${get_sttus}<br>
                                                <strong>เลขสัญญา :</strong> ${item.contract_number} <br>
                                                <strong>ประเภทสัญญา :</strong> ${item.loan_type} <br>
                                                <strong>จำนวนเงิน :</strong> ${item.loan_amount} <br>
                                            </div>
                                        `;
                                    });
                                });
                                $.when.apply($, promises).then(function() {
                                    $('#contract_search_results').html(html);
                                    searchLoanDetails(contractNumbers); // ส่ง array ของ contract_numbers
                                });
                            } else {
                                html = `
                                    <div class="rounded p-4 my-4 gg">
                                        <strong>ไม่พบข้อมูล</strong>
                                    </div>`;
                                $('#contract_search_results').html(html);
                                $('#loan_details').html(``);
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                } else {
                    $('#contract_search_results').html('<p class="p-4 rounded gg">Please enter a contract number</p>');
                }
            });
            // End Edit

            function searchLoanDetails(contractNumbers) {
                $.ajax({
                    url: '<?= base_url('report/searchLoanDetails') ?>',
                    method: 'POST',
                    data: {
                        contract_numbers: contractNumbers
                    },
                    success: function(data) {
                        let html = '';
                        let index = 1;

                        if (data.length > 0) {
                            data.forEach(function(item) {
                                html += `
                                <div class="rounded p-4 my-4 gg">
                                    <strong>เลขสัญญา :</strong> ${item.contract_number} <br>
                                    <strong>จำนวนเงินที่กู้ :</strong> ${item.dividend} <br>
                                    <strong>ข้อมูลสมาชิก :</strong> ${item.mem_code} ${item.mem_title} ${item.mem_fname} ${item.mem_lname} ${item.mem_status} <br>
                                </div>`;
                            });
                        } else {
                            html = `
                            <div class="rounded p-4 my-4 gg">
                                <strong>ไม่พบข้อมูล</strong>
                            </div>`;
                        }
                        $('#loan_details').html(html);
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            }

            function searchBorrowerDetails(borCode) {
                return $.Deferred(function(deferred) {
                    $.ajax({
                        url: '<?= base_url('report/searchBorrowerDetails') ?>',
                        method: 'POST',
                        data: {
                            borrower_id: borCode
                        },
                        success: function(data) {
                            if (data.length > 0) {
                                data.forEach(function(item) {
                                    get_title = item.mem_title;
                                    get_fname = item.mem_fname;
                                    get_lname = item.mem_lname;
                                    get_sttus = item.mem_status;
                                });
                            }
                            deferred.resolve();
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                            deferred.reject();
                        }
                    });
                }).promise();
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>

</html>