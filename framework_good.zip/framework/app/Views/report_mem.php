<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">
    <div class="mx-auto w-4/5 mt-5 bg-white p-6 rounded-lg shadow-lg">
        <div class="text-center mb-4">
            <h1 class="text-3xl font-bold text-gray-900">รายงาน</h1>
        </div>

        <div class="mb-4">
            <label for="mem_code" class="block text-lg font-medium text-gray-900 mb-2">ค้นหาสมาชิกด้วยรหัส</label>
            <div class="flex space-x-2">
                <input type="text" id="mem_code" name="mem_code" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <a id="search_member" class="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
            </div>
        </div>

        <div id="loan_details" class="mb-4 hidden">
            <!-- ผลลัพธ์การค้นหา tb_loans จะแสดงที่นี่ -->
        </div>

        <div id="credit_details" class="mb-4 hidden">
            <!-- ผลลัพธ์การค้นหา tb_credit จะแสดงที่นี่ -->
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#search_member').click(function() {
                let memCode = $('#mem_code').val();

                if (memCode) {
                    $.ajax({
                        url: '<?= base_url('report_mem/searchByMemCode') ?>',
                        method: 'POST',
                        data: {
                            mem_code: memCode
                        },
                        success: function(data) {
                            let html = '';
                            let contractNumbers = [];

                            if (data.length > 0) {
                                data.forEach(function(item) {
                                    html += `
                                <div class="p-4 bg-gray-200 rounded-md my-4">
                                    <p><strong>เลขสัญญา :</strong> ${item.contract_number}</p>
                                    <p><strong>ผู้ค้ำ :</strong> ${item.mem_code}</p>
                                    <p><strong>ชื่อ-นามสกุล :</strong>${item.mem_title} ${item.mem_fname} ${item.mem_lname}</p>
                                    <p><strong>จำนวนเงิน :</strong> ${item.dividend}</p>
                                </div>
                            `;
                                    contractNumbers.push(item.contract_number); // เก็บ contract_number ทุกตัว
                                });
                                searchCreditDetails(contractNumbers); // ส่ง array ของ contract_numbers
                            } else {
                                html = '<p class="p-4 bg-gray-200 rounded-md"><strong>ไม่พบรหัสสมาชิกนี้</strong></p>';
                            }
                            $('#loan_details').html(html).removeClass('hidden');
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                } else {
                    $('#loan_details').html('<p class="p-4 bg-gray-200 rounded-md">กรุณากรอกรหัสสมาชิก</p>').removeClass('hidden');
                }
            });

            function searchCreditDetails(contractNumbers) {
                $.ajax({
                    url: '<?= base_url('report_mem/searchCreditDetails') ?>',
                    method: 'POST',
                    data: {
                        contract_numbers: contractNumbers // ส่ง array ของ contract_numbers
                    },
                    success: function(data) {
                        let html = '';
                        let index = 1; // ลำดับเริ่มต้น

                        if (data.length > 0) {
                            data.forEach(function(item) {
                                html += `
                            <div class="p-4 bg-gray-200 rounded-md my-4">
                                <p><strong>ลำดับ :</strong> ${index++}</p>
                                <p><strong>เลขสัญญา :</strong> ${item.contract_number}</p>
                                <p><strong>จำนวนเงินที่กู้ :</strong> ${item.loan_amount}</p>
                                <p><strong>รหัสผู้กู้ :</strong> ${item.borrower_id}</p>
                                <p><strong>ชื่อผู้กู้ :</strong> ${item.mem_title} ${item.mem_fname} ${item.mem_lname}</p>
                            </div>
                        `;
                            });
                        } else {
                            html = '<p class="p-4 bg-gray-200 rounded-md"><strong>ไม่พบข้อมูลเครดิต</strong></p>';
                        }
                        $('#credit_details').html(html).removeClass('hidden');
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            }
        });
    </script>
</body>

</html>