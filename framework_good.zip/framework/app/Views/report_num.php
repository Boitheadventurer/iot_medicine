<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">
    <div class="mx-auto w-4/5 mt-5 bg-white p-6 rounded-lg shadow-lg">
        <div class="text-center mb-4">
            <h1 class="text-3xl font-bold text-gray-900">รายงาน</h1>
        </div>

        <!-- <div class="mb-4">
            <label for="mem_code" class="block text-lg font-medium text-gray-900 mb-2">ค้นหาสมาชิกด้วยรหัส</label>
            <div class="flex space-x-2">
                <input type="text" id="mem_code" name="borrower_id" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <a id="search_member" class="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
            </div>
        </div> -->

        <div id="member_search_results" class="mb-4">
            <!-- ผลลัพธ์การค้นหาจะแสดงที่นี่ -->
        </div>


        <div class="mb-4">
            <label for="contract_number" class="block text-lg font-medium text-gray-900 mb-2">ค้นหาสัญญาด้วยรหัส</label>
            <div class="flex space-x-2">
                <input type="text" id="contract_number" name="contract_number" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <a id="search_contract" class="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-500">ค้นหา</a>
            </div>
        </div>

        <div id="contract_search_results" class="mb-4">
            <!-- ผลลัพธ์การค้นหาจะแสดงที่นี่ -->
        </div>

        <div id="loan_details" class="mb-4">
            <!-- ผลลัพธ์การค้นหา tb_loans จะแสดงที่นี่ -->
        </div>


        <div id="borrower_details" class="mb-4">
            <!-- ผลลัพธ์การค้นหา tb_loans จะแสดงที่นี่ -->
        </div>

        <div class="mb-4" hidden>
            <label for="member_type" class="block text-lg font-medium text-gray-900 mb-2">ประเภทสมาชิก</label>
            <select id="member_type" name="member_type" class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <option value="">ประเภทสมาชิก</option>
                <?php foreach ($member_types as $type) : ?>
                    <option value="<?= $type['member_type_id'] ?>"><?= $type['member_type'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>





    <script>
        //กรอกเฉพาะตัวเลขเท่านั้น
        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode != 46 && charCode > 31 &&
                (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
    </script>



    <script>
        $(document).ready(function() {
            let guarantorCount = 1;

            function searchMember(query, resultElement, row) {
                $.ajax({
                    url: '<?= base_url('search') ?>',
                    method: 'POST',
                    data: {
                        query: query
                    }, // ข้อมูลที่ส่งไปกับการค้นหา
                    success: function(data) {
                        resultElement.empty(); // ล้างข้อมูลผลการค้นหาเก่า
                        if (data.length > 0) {
                            data.forEach(function(item) {
                                resultElement.append('<p>' + item.mem_title + ' ' +
                                    item.mem_fname + ' ' + item.mem_lname + ' ' +
                                    item.mem_status + '</p>');
                            });
                        } else {
                            resultElement.append('<p>ไม่พบข้อมูล</p>');
                        }
                        row.find('.guarantor-query').trigger('change');
                    }
                });
            }

            $('#search-button-borrower').click(function() {
                let query = $('#search-query-borrower').val();
                let resultElement = $('#search-results-borrower');
                searchMember(query, resultElement);
            });

            $(document).on('click', '.guarantor-search-button', function() {
                let row = $(this).closest('tr');
                let query = row.find('.guarantor-query').val();
                let resultElement = row.find('#guarantor-results');
                searchMember(query, resultElement, row);
            });

        });
    </script>



    <script>
        $(document).ready(function() {
    let guarantorCount = 1;
    let get_title;
    let get_fname;
    let get_lname;
    let get_sttus;

    $('#search-button-borrower').click(function() {
        let query = $('#search-query-borrower').val();
        let resultElement = $('#search-results-borrower');
        searchMember(query, resultElement);
    });

    $(document).on('click', '.guarantor-search-button', function() {
        let row = $(this).closest('tr');
        let query = row.find('.guarantor-query').val();
        let resultElement = row.find('#guarantor-results');
        searchMember(query, resultElement, row);
    });

    let contractCount = 0;
    let sm = 0;
    let index = 1;
    let max = 0;
    let t = 0;
    let bw = 0;
    const statusToIdMap = {
        "ครู": "2",
        "เจ้าหน้าที่": "3",
        "บุคคลทั่วไป": "4"
    };

    function updateMemberTypeDetails(memberTypeId, callback) {
        if (memberTypeId) {
            $.ajax({
                url: '<?= base_url('member_type_details') ?>',
                method: 'POST',
                data: {
                    member_type_id: memberTypeId
                },
                success: function(data) {
                    let result = JSON.parse(data);

                    if (result.contract_count && result.member_cost) {
                        $('#contract_count').text(result.member_cost);
                        $('#member_cost').text(result.contract_count);
                        max = result.contract_count;
                        contractCount = parseFloat(result.member_cost) || 0;
                        if (typeof callback === "function") {
                            callback();
                        }
                    } else {
                        $('#contract_count').text('-');
                        $('#member_cost').text('-');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                }
            });
        } else {
            $('#contract_count').text('-');
            $('#member_cost').text('-');
        }
    }

    $('#member_type').change(function() {
        let memberTypeId = $(this).val();
        updateMemberTypeDetails(memberTypeId);
    });

    $('#search_contract').click(function() {
        let contractNumber = $('#contract_number').val();

        if (contractNumber) {
            $.ajax({
                url: '<?= base_url('report/searchByContractNumber') ?>',
                method: 'POST',
                data: {
                    contract_number: contractNumber
                },
                success: function(data) {
                    let html = '';
                    if (data.length > 0) {
                        let promises = data.map(function(item) {
                            bw = item.borrower_id;
                            return searchBorrowerDetails(bw).then(function() {
                                html += `
                                    <div class="p-4 bg-gray-200 rounded-md my-4">
                                        <p><strong>เลขสัญญา :</strong> ${item.contract_number}</p>
                                        <p><strong>ผู้ขอกู้ :</strong> ${item.borrower_id} ${get_title} ${get_fname} ${get_lname}</p>
                                        <p><strong>ประเภทสัญญา :</strong> ${item.loan_type}</p>
                                        <p><strong>กู้ :</strong> ${item.loan_amount}</p>
                                    </div>
                                `;
                                let con_num = item.contract_number;
                                searchLoanDetails(con_num);
                            });
                        });

                        $.when.apply($, promises).then(function() {
                            $('#contract_search_results').html(html);
                        });
                    } else {
                        html = '<p class="p-4 bg-gray-200 rounded-md">No results found</p>';
                        $('#contract_search_results').html(html);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                }
            });
        } else {
            $('#contract_search_results').html('<p class="p-4 bg-gray-200 rounded-md">Please enter a contract number</p>');
        }
    });

    function searchLoanDetails(contractNumber) {
        $.ajax({
            url: '<?= base_url('report/searchLoanDetails') ?>',
            method: 'POST',
            data: {
                contract_number: contractNumber
            },
            success: function(data) {
                let html = '';
                if (data.length > 0) {
                    data.forEach(function(item) {
                        html += `
                            <div class="p-4 bg-gray-200 rounded-md my-4">
                                <p><strong>รหัสผู้ค้ำประกัน :</strong> ${item.mem_code}</p>
                                <p><strong>จำนวนเงิน :</strong> ${item.dividend}</p>
                            </div>
                        `;
                        let m_code = item.mem_code;
                        searchMemberDetails(m_code);
                    });
                } else {
                    html = '<p class="p-4 bg-gray-200 rounded-md">ไม่พบข้อมูล</p>';
                }
                $('#loan_details').html(html);
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    }

    function searchMemberDetails(memCode) {
        $.ajax({
            url: '<?= base_url('report/searchMemberDetails') ?>',
            method: 'POST',
            data: {
                mem_code: memCode
            },
            success: function(data) {
                let html = '';
                if (data.length > 0) {
                    data.forEach(function(item) {
                        html += `
                            <div class="p-4 bg-gray-200 rounded-md my-4">
                                <p><strong>ชื่อสมาชิก :</strong> ${item.mem_fname}  ${item.mem_lname}</p>
                                <p><strong>สถานะ :</strong> ${item.mem_status}</p>
                            </div>
                        `;
                    });
                } else {
                    html = '<p class="p-4 bg-gray-200 rounded-md">ไม่พบข้อมูลสมาชิก</p>';
                }
                $('#loan_details').append(html);
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    }

    function searchBorrowerDetails(borCode) {
        return $.Deferred(function(deferred) {
            $.ajax({
                url: '<?= base_url('report/searchBorrowerDetails') ?>',
                method: 'POST',
                data: {
                    borrower_id: borCode
                },
                success: function(data) {
                    if (data.length > 0) {
                        data.forEach(function(item) {
                            get_title = item.mem_title;
                            get_fname = item.mem_fname;
                            get_lname = item.mem_lname;
                            get_sttus = item.mem_status;
                        });
                    }
                    deferred.resolve();
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    deferred.reject();
                }
            });
        }).promise();
    }

    $('#search_member').click(function() {
        let memCode = $('#mem_code').val();
        $('#member_search_results').html('');
        $('#member_type').val('');
        $('#contract_count').text('-');
        $('#member_cost').text('-');
        contractCount = 0;
        sm = 0;

        if (memCode) {
            $.ajax({
                url: '<?= base_url('search_member_by_code1') ?>',
                method: 'POST',
                data: {
                    mem_code: memCode
                },
                success: function(data) {
                    let result = JSON.parse(data);
                    let html = '';

                    if (result) {
                        if (result.mem_title !== undefined) {
                            html = `
                                <div class="p-4 bg-gray-200 rounded-md md-4">
                                    <p><strong>ชื่อ-สกุล:</strong> ${result.mem_title} ${result.mem_fname} ${result.mem_lname}</p>
                                    <p><strong>สถานะ:</strong> ${result.mem_status}</p>
                                </div>
                            `;
                        }
                        if (result.credit && result.credit.length >= 0) {
                            let totalLoanAmount = 0;
                            let loanAmounts = [];
                            sm = result.credit.length;

                            result.credit.forEach(function(credit) {
                                loanAmounts.push(parseFloat(credit.loan_amount) || 0);
                                html += `
                                    <div class="p-4 bg-gray-200 rounded-md my-4">
                                        <p><strong>สัญญาที่:</strong> ${credit.contract_number}</p>
                                        <p><strong>วงเงิน:</strong> ${credit.loan_amount}</p>
                                    </div>
                                `;
                            });
                            totalLoanAmount = loanAmounts.reduce((acc, current) => acc + current, 0);
                            let memberTypeId = statusToIdMap[result.mem_status.trim()];
                            if (memberTypeId) {
                                $('#member_type').val(memberTypeId);
                                updateMemberTypeDetails(memberTypeId, function() {
                                    t = contractCount - totalLoanAmount;
                                    t = isNaN(t) ? 0 : t;
                                    $('#member_cost').text(t);
                                    $('#hidden_t').val(t);

                                    html += `
                                        <div class="p-4 bg-gray-200 rounded-md my-4">
                                            <p><strong>รวมวงเงินสัญญาทั้งหมด:</strong> ${totalLoanAmount}</p>
                                            <p><strong>วงเงินเหลือ:</strong> ${t}</p>
                                            <p><strong>จำนวนสัญญา:</strong> ${sm} / ${max}</p>
                                        </div>
                                    `;
                                    $('#member_search_results').html(html);
                                    console.log(t);
                                });
                            } else {
                                $('#member_search_results').html(html);
                            }
                        } else {
                            html += `<div class="p-4 bg-gray-200 rounded-md my-4">
                                        <p><strong>ไม่มีข้อมูลเครดิตสำหรับสมาชิกนี้<strong></p>
                                    </div>`;
                            $('#member_search_results').html(html);
                        }
                    } else {
                        html = `<div class="p-4 bg-gray-200 rounded-md my-4">
                                    <p><strong>ไม่พบข้อมูลสมาชิกรหัสนี้<strong></p>
                                </div>`;
                        $('#member_search_results').html(html);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                }
            });
        } else {
            $('#member_search_results').html('<p>กรุณากรอกรหัสสมาชิก</p>');
        }
    });
});

    </script>

</body>

</html>