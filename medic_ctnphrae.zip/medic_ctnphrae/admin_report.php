<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายละเอียดผู้ใช้</title>
    <!-- เพิ่ม Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container my-5">
        <?php
        include 'php/chk_id.php';

        // ตรวจสอบว่า id ถูกส่งมาหรือไม่
        if (isset($_GET['id'])) {
            $userId = $_GET['id'];

            // ดึงข้อมูลจากฐานข้อมูลตาม id
            $query = "SELECT * FROM `tb_device` INNER JOIN `user` ON tb_device.id = user.id WHERE tb_device.id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $userData = $result->fetch_assoc();
                // แสดงข้อมูลในรูปแบบ HTML
        ?>
                <div class="card shadow-sm" style="max-width: 800px; margin: 0 auto;">
                    <div class="card-header text-center bg-primary text-white">
                        <h3 class="mb-0">รายละเอียดผู้ใช้</h3>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title mb-4 fs-4">ข้อมูลผู้ใช้</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item fs-5"><strong>ชื่อผู้ใช้:</strong> <?php echo $userData['firstname'] . " " . $userData['lastname']; ?></li>
                            <li class="list-group-item fs-5"><strong>เบอร์โทร:</strong> <?php echo $userData['device_detail']; ?></li>
                            <li class="list-group-item fs-5"><strong>Username:</strong> <?php echo $userData['email']; ?></li>
                            <li class="list-group-item fs-5"><strong>Password:</strong> <?php echo $userData['password']; ?></li>
                            <li class="list-group-item fs-5"><strong>สร้างบัญชีเมื่อ</strong><?php 
                                $date = new DateTime($z["created_at"]);
                                $th_year = $date->format('Y') + 543;

                                // อาร์เรย์เดือนภาษาไทย
                                $th_months = [
                                    1 => "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", 
                                    "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
                                ];

                                // ดึงวัน, เดือน, ปี
                                $day = $date->format('d');
                                $month = $th_months[(int)$date->format('m')];
                                $time = $date->format('H:i:s'); // ดึงเวลา ชั่วโมง:นาที:วินาที

                                // แสดงผล วันที่ เดือน ปี และเวลา
                                echo $day . " " . $month . " " . $th_year . " <br> " . $time . " น.";
                            ?></li>
                        </ul>
                    </div>
                </div>
        <?php
            } else {
                echo "<p class='text-center'>ไม่พบข้อมูลผู้ใช้</p>";
            }
        } else {
            echo "<p class='text-center'>ไม่พบรหัสผู้ใช้</p>";
        }
        ?>
    </div>

    <!-- เพิ่ม Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // รันคำสั่ง window.print() เมื่อหน้าเว็บโหลดเสร็จ
        window.onload = function() {
            window.print();
        }

        // ตรวจสอบว่าเอกสารการพิมพ์ถูกยกเลิกหรือไม่
        window.onafterprint = function() {
            // เมื่อพิมพ์เสร็จหรือยกเลิก ให้กลับไปหน้าเดิม
            window.location.href = "home_admin.php"; // หรือใช้ history.back() ถ้าอยากให้ย้อนกลับไปยังหน้าก่อนหน้า
        }
    </script>

</body>

</html>
