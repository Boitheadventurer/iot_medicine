<!doctype html>
<html lang="en">
    <head>
        <title>เครื่องจ่ายยาอัตโนมัติ</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- Remix Icon -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
        <!-- Icon Title -->
        <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
            body {
                background-color: #e0e0e0;
            }
            * {
                margin: 0;
                padding: 0;
                font-family: "Bai Jamjuree", sans-serif;
            }
            .inf {
                margin: 0 0 0 10%;
            }
            .container {
                background-color: white;
                max-width: 800px;
                width: 90%;
            }
            .indeximage {
                width: 100%;
                min-width: 250px;
                max-width: 550px;
            }
            .card {
                width: 100%;
                min-width: 250px;
                max-width: 450px;
                margin: 0 auto;
                float: none;
            }
            @media only screen and (max-width: 1000px){
                .indeximage {
                    display: block;
                    width: 100%;
                    margin: 0 auto;
                }
                .mainsection .row {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    text-align: center;
                }
                .inf {
                    margin: 5% 0;
                }
            }
            @media only screen and (max-width: 560px) {
                .card {
                    width: 100%;
                    margin: auto;
                    align-items: center;
                    text-align: center;
                }
            }
        </style>
    </head>
    <body>
        <?php
            include 'php/chk_id.php';   
            include 'php/navbar_admin.php';
        ?>
        <!-- Banner Title -->
        <?php $id =$_GET["id"];
            $sql = "SELECT * FROM tb_device LEFT JOIN user ON user.id = tb_device.id WHERE tb_device.id = '$id'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            //if ($row <= 0) { ?>
                 <div class="container my-5 shadow p-4 rounded" style="background: #fff;">
                <h2 class="text-center">ข้อมูลยา</h2> 
                <!-- <div class="btn btn-primary"></div> -->

                <style>
    .box-buttons {
        display: flex;
        justify-self: end;
        /* position: ; */
        width: 100%;
        /* height: 20px; */
        top: 18%;
        /* right: -8%; */
        /* padding: 10px; */
        align-items: right;
        border-radius: 10px;
        justify-content: flex-end;
    }
    .buttons {
        margin: 8px
    }
    .buttons:hover {
        filter: brightness(0.9); /* Slightly darken the button on hover */
        color:#000;
        text-decoration: none;
    }
    </style>


                <form method="POST" action="#">

                <?php $count = 0; $id = $_GET['id']; foreach($conn->query("SELECT * FROM `tb_device` INNER JOIN  user ON tb_device.id = user.id WHERE user.id = $id") as $z) { ?>
            

                    <nav class="navbar navbar-expand-lg bg-light shadow-sm mb-5">
            <div class="container">


                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- เนื้อหาของ Navbar -->
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto gap-3">
                        <li class="nav-item">
                            <a class="nav-link" href="home_admin.php">
                                <i class="bi bi-house"></i> หน้าหลัก
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="detial.php?id=<?php echo $_GET['id']; ?>">
                                <i class="bi bi-capsule"></i> เครื่องจ่ายยา
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="data1.php?id=<?php echo $_GET['id']; ?>">
                                <i class="bi bi-file-medical"></i> ข้อมูลยา
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="etial.php?id=<?php echo $_GET['id']; ?>">
                                <i class="bi bi-gear"></i> ตั้งค่าการจ่ายยา
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="history.php?id=<?php echo $_GET['id']; ?>">
                                <i class="bi bi-clock-history"></i> ประวัติการจ่ายยา
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
                <?php } ?>
                <?php
    include 'php/chk_id.php';
    ?>

    <!-- Insert Medicine -->
    <?php
    if (isset($_GET['medicine_id'])) {
        $medicine_id = $_GET['medicine_id'];

        $sql = "DELETE FROM tb_medicine WHERE medicine_id = '$medicine_id'";
        $conn->query($sql);
        echo "<script>window.location.href='medicine.php';</script>";
        exit();
    }
    ?>
    <div class="container p-4 rounded bg-white">

        <div class="table-responsive">
        <table class="table table-hover table-bordered text-center align-middle rounded ggtable">
            <thead class="table-success">
                <tr>
                    <th scope="col" class="w-25">ชื่อยา</th>
                    <th scope="col" class="w-25">ประเภทการทานยา</th>
                </tr>
            </thead>
            <tbody>
                <?php $id = $_GET['id']; foreach ($conn->query("SELECT * FROM tb_medicine WHERE id = $id") as $z) { ?>
                    <tr>
                        <td><?php echo $z['medicine_name']; ?></td>
                        <td>
                        <select class="form-control" name="medicine_detail" disabled>
    <option value="ก่อนอาหาร" <?php echo ($z['medicine_detail'] == 'ก่อนอาหาร') ? 'selected' : ''; ?>>ก่อนอาหาร</option>
    <option value="หลังอาหาร" <?php echo ($z['medicine_detail'] == 'หลังอาหาร') ? 'selected' : ''; ?>>หลังอาหาร</option>
</select>

                        </td>

                    </tr>
                <?php } ?>
                </form>
            </div>
            <?php //} ?>


            
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
</html>