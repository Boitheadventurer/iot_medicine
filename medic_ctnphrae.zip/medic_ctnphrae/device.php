<!doctype html>
<html lang="en">

<head>
    <title>เครื่องจ่ายยาอัตโนมัติ</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        body {
            background-color: #e0e0e0;
        }

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: white;
            max-width: 800px;
            width: 90%;
        }

        .ggtable {
            min-width: 450px;
        }
    </style>
</head>

<body>
    <?php
    include 'php/chk_id.php';
    include 'php/navbar.php';
    ?>

    <?php
    $sql = "SELECT * FROM tb_device LEFT JOIN user ON user.id = tb_device.id WHERE tb_device.id = '$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    if ($row <= 0) { ?>
        <div class="container my-5 shadow p-4 rounded">
            <h2 class="text-center">ข้อมูลเครื่องจ่ายยา</h2>
            <form method="POST" action="php/chk_device.php">
                <div class="mb-3">
                    <label for="dtail" class="form-label text-danger">ไอดีไลน์ผู้ใช้งาน</label>
                    <input type="text" class="form-control" name="dtail" required>
                </div>

                <div class="mb-3">
                    <label for="dline" class="form-label text-danger">หมายเลขโทเคน เครื่องจ่ายยา</label>
                    <input type="text" class="form-control" name="dline" required>
                    <!-- Fix Value -->
                </div>

                <button type="submit" class="btn btn-success">ยืนยันเปิดใช้งานเครื่อง</button>
            </form>
        </div>
    <?php } else { ?>
        <?php
        // ตรวจสอบว่าเป็นการส่งข้อมูลแบบ POST
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $dtail          = $_POST['dtail'];
            $did            = $_POST['did'];
            $delay          = $_POST['delay'];
            $dline          = $_POST['dline'];
            $url1           = $_POST['durl1'];
            $url2           = $_POST['durl2'];
            $modesend       = $_POST['modesend'];
            $dtelegram_id   = $_POST['dtelegram_id'];
            $dtelegram_token = $_POST['dtelegram_token'];

            $sql = "UPDATE tb_device 
                            SET device_detail = '$dtail', 
                                alert_delay = '$delay', 
                                token_line = '$dline' ,
                                url1 = '$url1', 
                                url2 = '$url2',
                                modesend = '$modesend',
                                telegram_id = '$dtelegram_id',
                                telegram_key = '$dtelegram_token'
                            WHERE id = '$did'";
            // url1 = line
            // url2 = telegram
            // รันคำสั่ง SQL
            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('บันทึกการแก้ไขข้อมูลสำเร็จ'); window.location.href='device.php';</script>";
            } else {
                echo "เกิดข้อผิดพลาด: " . $conn->error;
            }
        }
        ?>

        <!-- ฟอร์มแสดงข้อมูลและการแก้ไข -->
        <div class="container my-5 shadow p-4 rounded">
            <h2 class="text-center">ข้อมูลเครื่องจ่ายยา</h2>
            <form method="POST" action="#">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="dfullname" class="form-label text-success">เจ้าของผู้สมัคร ใช้งานระบบ</label>
                        <input type="text" class="form-control" name="dfullname" value="<?php echo $row['firstname_th'] . " " . $row['lastname_th']; ?>" readonly>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="status" class="form-label text-success">สถานะเครื่อง</label>
                        <input type="text" class="form-control" name="status" id="status_online" value="" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="demail" class="form-label text-success">อีเมล</label>
                        <input type="email" class="form-control" name="demail" value="<?php echo $row['email']; ?>" readonly>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="dpassword" class="form-label text-success">รหัสผ่าน</label>
                        <input type="text" class="form-control" name="dpassword" value="<?php echo $row['password']; ?>" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6"> <!-- form-group col-md-4 -->
                        <label for="dtail" class="form-label text-success">ไอดีไลน์ผู้ใช้งาน</label>
                        <input type="text" class="form-control" name="dtail" value="<?php echo $row['device_detail']; ?>">
                    </div>
                    <div class="form-group col-md-4" hidden> <!-- form-group col-md-4 -->
                        <label for="delay" class="form-label text-success">กำหนดดีเลย์แจ้งเตือน (นาที)</label>
                        <input type="number" class="form-control" name="delay" value="<?php echo $row['alert_delay']; ?>">
                    </div>
                    <div class="form-group col-md-6"> <!-- form-group col-md-4 -->
                        <label for="did" class="form-label text-success">หมายเลข เชื่อมต่อเครื่อง</label>
                        <input type="text" class="form-control" name="did" value="<?php echo $row['id']; ?>" readonly>
                    </div>
                </div>
                <h3 class="text-center my-3">รูปแบบการแจ้งเตือน</h3>

                <div class="text-center">
                    <button type="submit" class="btn btn-primary">บันทึกการแก้ไขข้อมูล</button>
                </div>

                <div class="form-row mt-3">
                    <div class="form-group col-md-12">
                        <label for="" class="form-label text-info">การแจ้งเตือนออนไลน์</label>
                        <select class="form-control" name="modesend">
                            <option value="1" <?php echo ($row['modesend'] == 1) ? 'selected' : ''; ?>>Telegram</option>
                            <option value="0" <?php echo ($row['modesend'] == 0) ? 'selected' : ''; ?>>LINE Notify</option>
                        </select>
                    </div>
                </div>
                <?php if ($row['modesend'] == 1) { ?>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label for="dtelegram_token" class="form-label text-primary">หมายเลขโทเคน เทเลแกรม</label>
                            <input type="text" class="form-control" name="dtelegram_token" value="<?php echo $row['telegram_key']; ?>">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="dtelegram_id" class="form-label text-primary">ไอดี เทเลแกรม</label>
                            <input type="text" class="form-control" name="dtelegram_id" value="<?php echo $row['telegram_id']; ?>">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="durl2" class="form-label text-primary">ลิงค์กลุ่ม เทเลแกรม</label>
                            <input type="text" class="form-control" name="durl2" value="<?php echo $row['url2']; ?>">
                        </div>
                    </div>
                    <?php
                    if ($row['url2'] != NULL) {
                        include('phpqrcode/qrlib.php');
                        $file_name = "qrcodetelegram.png";
                        $content = $row['url2'];
                        QRcode::png($content, $file_name, QR_ECLEVEL_L, 10);
                        echo "<center>
                                    <img src='{$file_name}' style='width: 25%;'>
                                    </center>
                                    <h6 class='text-primary text-center'>QR Code กลุ่มแจ้งเตือน</h6>
                                    ";
                    } ?>
                <?php } else if ($row['modesend'] == 0) { ?>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="dline" class="form-label text-success">หมายเลขโทเคน ไลน์</label>
                            <input type="text" class="form-control" name="dline" value="<?php echo $row['token_line']; ?>">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="durl1" class="form-label text-success">ลิงค์กลุ่ม ไลน์</label>
                            <input type="text" class="form-control" name="url1" value="<?php echo $row['url1']; ?> ">
                        </div>
                    </div>

                    <?php
                    if ($row['url1'] != NULL) {
                        include('phpqrcode/qrlib.php');
                        $file_name = "qrcodeline.png";
                        $content = $row['url1'];
                        QRcode::png($content, $file_name, QR_ECLEVEL_L, 10);
                        echo "<center>
                                    <img src='{$file_name}' style='width: 25%;'>
                                    </center>
                                    <h6 class='text-primary text-center'>QR Code กลุ่มแจ้งเตือน</h6>
                                    ";
                    } ?>
                <?php } ?>
            </form>
        </div>

        <div class="container my-5 shadow p-4 rounded" hidden>
            <h2 class="text-center">การตั้งค่าการจ่ายยา</h1>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered text-center ggtable">
                        <thead>
                            <tr>
                                <th scope="col" class="w-25">เช้า</th>
                                <th scope="col" class="w-25">กลางวัน</th>
                                <th scope="col" class="w-25">เย็น</th>
                                <th scope="col" class="w-25">ก่อนนอน</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php foreach ($conn->query("SELECT * FROM tb_data_bf WHERE id = $id") as $z) {
                                        echo substr($z['time_bf'], 0, 5);
                                    } ?>
                                </td>
                                <td><?php foreach ($conn->query("SELECT * FROM tb_data_lunch WHERE id = $id") as $z) {
                                        echo substr($z['time_lunch'], 0, 5);
                                    } ?>
                                </td>
                                <td><?php foreach ($conn->query("SELECT * FROM tb_data_dn WHERE id = $id") as $z) {
                                        echo substr($z['time_dn'], 0, 5);
                                    } ?>
                                </td>
                                <td><?php foreach ($conn->query("SELECT * FROM tb_data_bb WHERE id = $id") as $z) {
                                        echo substr($z['time_bb'], 0, 5);
                                    } ?>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <?php foreach ($conn->query("SELECT * FROM tb_data_bf WHERE id = '$id'") as $z) {
                                        $r1 = $z['medicine_id'];
                                        $r2 = $z['medicine_id2'];
                                        $r3 = $z['medicine_id3'];
                                        $r4 = $z['medicine_id4'];

                                        if ($r1 != NULL) {
                                            $sql_1 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r1'");
                                            $ech_1 = $sql_1->fetch_assoc();
                                            echo $ech_1['medicine_name'] . "<hr>";
                                        }

                                        if ($r2 != NULL) {
                                            $sql_2 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r2'");
                                            $ech_2 = $sql_2->fetch_assoc();
                                            echo $ech_2['medicine_name'] . "<hr>";
                                        }

                                        if ($r3 != NULL) {
                                            $sql_3 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r3'");
                                            $ech_3 = $sql_3->fetch_assoc();
                                            echo $ech_3['medicine_name'] . "<hr>";
                                        }

                                        if ($r4 != NULL) {
                                            $sql_4 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r4'");
                                            $ech_4 = $sql_4->fetch_assoc();
                                            echo $ech_4['medicine_name'] . "<hr>";
                                        }
                                    } ?>
                                </td>
                                <td>
                                    <?php foreach ($conn->query("SELECT * FROM tb_data_lunch WHERE id = '$id'") as $z) {
                                        $r1 = $z['medicine_id'];
                                        $r2 = $z['medicine_id2'];
                                        $r3 = $z['medicine_id3'];
                                        $r4 = $z['medicine_id4'];

                                        if ($r1 != NULL) {
                                            $sql_1 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r1'");
                                            $ech_1 = $sql_1->fetch_assoc();
                                            echo $ech_1['medicine_name']  . "<hr>";
                                        }

                                        if ($r2 != NULL) {
                                            $sql_2 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r2'");
                                            $ech_2 = $sql_2->fetch_assoc();
                                            echo $ech_2['medicine_name']  . "<hr>";
                                        }

                                        if ($r3 != NULL) {
                                            $sql_3 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r3'");
                                            $ech_3 = $sql_3->fetch_assoc();
                                            echo $ech_3['medicine_name']  . "<hr>";
                                        }

                                        if ($r4 != NULL) {
                                            $sql_4 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r4'");
                                            $ech_4 = $sql_4->fetch_assoc();
                                            echo $ech_4['medicine_name']  . "<hr>";
                                        }
                                    } ?>
                                </td>
                                <td>
                                    <?php foreach ($conn->query("SELECT * FROM tb_data_dn WHERE id = '$id'") as $z) {
                                        $r1 = $z['medicine_id'];
                                        $r2 = $z['medicine_id2'];
                                        $r3 = $z['medicine_id3'];
                                        $r4 = $z['medicine_id4'];

                                        if ($r1 != NULL) {
                                            $sql_1 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r1'");
                                            $ech_1 = $sql_1->fetch_assoc();
                                            echo $ech_1['medicine_name'] . "<hr>";
                                        }

                                        if ($r2 != NULL) {
                                            $sql_2 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r2'");
                                            $ech_2 = $sql_2->fetch_assoc();
                                            echo $ech_2['medicine_name']  . "<hr>";
                                        }

                                        if ($r3 != NULL) {
                                            $sql_3 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r3'");
                                            $ech_3 = $sql_3->fetch_assoc();
                                            echo $ech_3['medicine_name']  . "<hr>";
                                        }

                                        if ($r4 != NULL) {
                                            $sql_4 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r4'");
                                            $ech_4 = $sql_4->fetch_assoc();
                                            echo $ech_4['medicine_name']  . "<hr>";
                                        }
                                    } ?>
                                </td>
                                <td>
                                    <?php foreach ($conn->query("SELECT * FROM tb_data_bb WHERE id = '$id'") as $z) {
                                        $r1 = $z['medicine_id'];
                                        $r2 = $z['medicine_id2'];
                                        $r3 = $z['medicine_id3'];
                                        $r4 = $z['medicine_id4'];

                                        if ($r1 != NULL) {
                                            $sql_1 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r1'");
                                            $ech_1 = $sql_1->fetch_assoc();
                                            echo $ech_1['medicine_name']  . "<hr>";
                                        }

                                        if ($r2 != NULL) {
                                            $sql_2 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r2'");
                                            $ech_2 = $sql_2->fetch_assoc();
                                            echo $ech_2['medicine_name']  . "<hr>";
                                        }

                                        if ($r3 != NULL) {
                                            $sql_3 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r3'");
                                            $ech_3 = $sql_3->fetch_assoc();
                                            echo $ech_3['medicine_name']  . "<hr>";
                                        }

                                        if ($r4 != NULL) {
                                            $sql_4 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r4'");
                                            $ech_4 = $sql_4->fetch_assoc();
                                            echo $ech_4['medicine_name']  . "<hr>";
                                        }
                                    } ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
        </div>
    <?php } ?>
    <div class="container my-5 shadow p-4 rounded" hidden>
        <h2 class="text-center">ประวัติการจ่ายยา
            <!-- ปุ่มสำหรับการปริ้น -->
            <button onclick="printTable()" class="btn btn-primary mb-3">ปริ้นตารางนี้</button>
        </h2>
        <div class="table-responsive">
            <?php
            // กำหนดจำนวนรายการต่อหน้า
            $items_per_page = isset($_GET['items_per_page']) ? (int)$_GET['items_per_page'] : 10;

            // รับค่าหน้าปัจจุบันจาก URL (ถ้าไม่มีให้เริ่มที่หน้า 1)
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $page = max($page, 1); // ตรวจสอบให้ไม่น้อยกว่า 1

            // คำนวณตำแหน่งเริ่มต้น
            $offset = ($page - 1) * $items_per_page;

            // Query ประวัติการจ่ายยาพร้อมแบ่งหน้า
            $history_query = "SELECT tb_data_eat_medicine.*, 
                                                m1.medicine_name AS medicine1, 
                                                m2.medicine_name AS medicine2, 
                                                m3.medicine_name AS medicine3, 
                                                m4.medicine_name AS medicine4
                                        FROM tb_data_eat_medicine
                                        LEFT JOIN tb_medicine AS m1 ON tb_data_eat_medicine.medicine_id = m1.medicine_id
                                        LEFT JOIN tb_medicine AS m2 ON tb_data_eat_medicine.medicine_id2 = m2.medicine_id
                                        LEFT JOIN tb_medicine AS m3 ON tb_data_eat_medicine.medicine_id3 = m3.medicine_id
                                        LEFT JOIN tb_medicine AS m4 ON tb_data_eat_medicine.medicine_id4 = m4.medicine_id
                                        WHERE tb_data_eat_medicine.device_id = '$id'
                                        ORDER BY tb_data_eat_medicine.time_get DESC
                                        LIMIT $items_per_page OFFSET $offset";
            $history_result = $conn->query($history_query);

            //นับจำนวนสำเร็จ
            $Success_query = "SELECT COUNT(*) AS 'total_success'FROM tb_data_eat_medicine WHERE
                        device_id = '$id' AND medicine_get LIKE 'success'";
            $Success_result = $conn->query($Success_query);
            $Success = $Success_result->fetch_assoc();

            //นับจำนวนไม่สำเร็จ
            $Fail_query = "SELECT COUNT(*) AS 'total_fail'FROM tb_data_eat_medicine WHERE
                        device_id = '$id' AND medicine_get LIKE 'failed'";
            $Fail_result = $conn->query($Fail_query);
            $Fail = $Fail_result->fetch_assoc();

            // Query นับจำนวนรายการทั้งหมด
            $count_query = "SELECT COUNT(*) AS total_items FROM tb_data_eat_medicine WHERE device_id = '$id'";
            $count_result = $conn->query($count_query);
            $total_items = $count_result->fetch_assoc()['total_items'];

            // คำนวณจำนวนหน้าทั้งหมด
            $total_pages = ceil($total_items / $items_per_page);
            ?>
            <!-- Dropdown เลือกจำนวนแถวแบบไม่ใช้ฟอร์ม -->
            <div class="mb-3">
                <label for="itemsPerPageSelect">เลือกจำนวนแถวที่ต้องการแสดง</label>
                <select id="itemsPerPageSelect" class="form-control w-50" onchange="updateItemsPerPage()">
                    <option value="10" <?php if ($items_per_page == 10) echo 'selected'; ?>>10 แถว</option>
                    <option value="25" <?php if ($items_per_page == 25) echo 'selected'; ?>>25 แถว</option>
                    <option value="50" <?php if ($items_per_page == 50) echo 'selected'; ?>>50 แถว</option>
                    <option value="100" <?php if ($items_per_page == 100) echo 'selected'; ?>>100 แถว</option>
                </select>
            </div>

            <table class="table table-striped table-bordered text-center ggtable" id="printableTable">
                <thead>
                    <tr>
                        <th scope="col" class="w-25">ครั้งที่</th> <!-- เพิ่มส่วนหัวสำหรับ ID -->
                        <th scope="col" class="w-25">วันที่ - เวลา</th>
                        <th scope="col" class="w-25">ชื่อยา</th>
                        <th scope="col" class="w-25">ผลลัพธ์การจ่ายยา</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $history_query = "SELECT tb_data_eat_medicine.*, 
                            m1.medicine_name AS medicine1, 
                            m2.medicine_name AS medicine2, 
                            m3.medicine_name AS medicine3, 
                            m4.medicine_name AS medicine4
                        FROM tb_data_eat_medicine
                        LEFT JOIN tb_medicine AS m1 ON tb_data_eat_medicine.medicine_id = m1.medicine_id
                        LEFT JOIN tb_medicine AS m2 ON tb_data_eat_medicine.medicine_id2 = m2.medicine_id
                        LEFT JOIN tb_medicine AS m3 ON tb_data_eat_medicine.medicine_id3 = m3.medicine_id
                        LEFT JOIN tb_medicine AS m4 ON tb_data_eat_medicine.medicine_id4 = m4.medicine_id
                        WHERE tb_data_eat_medicine.device_id = '$id'
                        ORDER BY tb_data_eat_medicine.time_get DESC
                        LIMIT $items_per_page OFFSET $offset";

                    $history_result = $conn->query($history_query);

                    if ($history_result->num_rows > 0) {
                        while ($history_row = $history_result->fetch_assoc()) {
                            $data_id = $history_row['data_id']; // ดึงค่า data_id
                            $date = date('d/m/Y', strtotime($history_row['time_get'] + 543));
                            $time = date('H:i', strtotime($history_row['time_get']));

                            $medicines = array_filter([
                                $history_row['medicine1'],
                                $history_row['medicine2'],
                                $history_row['medicine3'],
                                $history_row['medicine4']
                            ]);
                            $medicine_list = implode("<br>", $medicines);

                            $medicine_get_result = ($history_row['medicine_get'] == 'success') ? 'สำเร็จ' : 'ไม่สำเร็จ';

                            echo "<tr>
                        <td>{$data_id}</td> <!-- แสดง ID -->
                        <td>{$date}<br>{$time}</td>
                        <td>{$medicine_list}</td>
                        <td><b>{$medicine_get_result}</b></td>
                    </tr>";
                        }

                        echo "<tr>
                    <td rowspan='2' colspan='3' style='text-align: center; vertical-align: middle; font-weight: bold;'>สรุปผลการจ่ายยา</td>
                    <td style='color: green;'><b>สำเร็จ : {$Success['total_success']}</b></td>
                </tr>
                <tr>
                    <td style='color: red;'><b>ไม่สำเร็จ : {$Fail['total_fail']}</b></td>
                </tr>";
                    } else {
                        echo "<tr><td colspan='4'>ไม่มีประวัติการจ่ายยา</td></tr>";
                    }
                    ?>
                </tbody>
            </table>



            <!-- การสร้างปุ่มนำทาง (ก่อนหน้า/ถัดไป) -->
            <nav>
                <ul class="pagination justify-content-center">
                    <?php
                    // ปุ่ม "ก่อนหน้า"
                    if ($page > 1) {
                        $prev_page = $page - 1;
                        echo "<li class='page-item'>
                                            <a class='page-link' href='?page={$prev_page}&items_per_page={$items_per_page}'>ก่อนหน้า</a>
                                        </li>";
                    }

                    // แสดงเลขหน้า
                    for ($i = 1; $i <= $total_pages; $i++) {
                        $active = ($i == $page) ? "active" : "";
                        echo "<li class='page-item {$active}'>
                                            <a class='page-link' href='?page={$i}&items_per_page={$items_per_page}'>{$i}</a>
                                        </li>";
                    }

                    // ปุ่ม "ถัดไป"
                    if ($page < $total_pages) {
                        $next_page = $page + 1;
                        echo "<li class='page-item'>
                                            <a class='page-link' href='?page={$next_page}&items_per_page={$items_per_page}'>ถัดไป</a>
                                        </li>";
                    }
                    ?>
                </ul>
            </nav>
        </div>
    </div>
    <script>
        function updateItemsPerPage() {
            const itemsPerPage = document.getElementById('itemsPerPageSelect').value;
            const currentPage = <?php echo $page; ?>; // ค่าเพจปัจจุบันจาก PHP
            window.location.href = `?items_per_page=${itemsPerPage}&page=${currentPage}`;
        }

        function printTable() {
            // เปิดหน้าสำหรับพิมพ์
            var printWindow = window.open('userprint.php', '_blank');

            // รอให้หน้าโหลดเสร็จแล้วค่อยสั่งพิมพ์
            printWindow.onload = function() {
                printWindow.print();
                printWindow.close();
            };
        }
    </script>
    <script>
        function fetchData() {
            fetch('http://medic.ctnphrae.com/php/status.php?device=<?php echo $id; ?>')
                .then(response => response.text()) // Read as text
                .then(data => {
                    console.log('Raw data:', data);

                    // Extract JSON part of the response
                    const jsonStart = data.indexOf('{');
                    if (jsonStart !== -1) {
                        const jsonString = data.slice(jsonStart); // Extract JSON substring
                        try {
                            const jsonData = JSON.parse(jsonString); // Parse JSON
                            document.getElementById('status_online').value = jsonData.status_online;
                            if (jsonData.status_online == "online") {
                                document.getElementById('status_online').style.color = "green";
                            } else {
                                document.getElementById('status_online').style.color = "red";
                            }
                        } catch (error) {
                            console.error('Error parsing JSON:', error, '\nExtracted data:', jsonString);
                        }
                    } else {
                        console.error('No JSON found in response:', data);
                    }
                })
                .catch(error => console.error('Error fetching data:', error));
        }
        setInterval(fetchData, 5000);
        window.onload = fetchData;
    </script>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>