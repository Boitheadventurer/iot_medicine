<!doctype html>
<html lang="en">
    <head>
        <title>เครื่องจ่ายยาอัตโนมัติ</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- Remix Icon -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
        <!-- Icon Title -->
        <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
            body {
                background-color: #e0e0e0;
            }
            * {
                margin: 0;
                padding: 0;
                font-family: "Bai Jamjuree", sans-serif;
            }
            .container {
                background-color: white;
                max-width: 800px;
                width: 90%;
            }
            .ggtable {
                min-width: 450px;
            }
        </style>
    </head>
    <body>
        <?php
            include 'php/chk_id.php';   
            include 'php/navbar_admin.php';
        ?>

        <?php $id =$_GET["id"];
            $sql = "SELECT * FROM tb_device LEFT JOIN user ON user.id = tb_device.id WHERE tb_device.id = '$id'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            if ($row <= 0) { ?>
                <div class="container my-5 shadow p-4 rounded">
                    <h2 class="text-center">ข้อมูลเครื่องจ่ายยา</h2>
                    <form method="POST" action="php/chk_device.php">
                        <div class="mb-3">
                            <label for="dtail" class="form-label text-danger">ไอดีไลน์ผู้ใช้งาน</label>
                            <input type="text" class="form-control" name="dtail" required>
                        </div>

                        <div class="mb-3">
                            <label for="dline" class="form-label text-danger">หมายเลขโทเคน เครื่องจ่ายยา</label>
                            <input type="text" class="form-control" name="dline" required>
                            <!-- Fix Value -->
                        </div>

                        <button type="submit" class="btn btn-success">ยืนยันเปิดใช้งานเครื่อง</button>
                    </form>
                </div>
        <?php } else { ?>
            <?php
                // ตรวจสอบว่าเป็นการส่งข้อมูลแบบ POST
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                    $dtail  = $_POST['dtail'];
                    $did    = $_POST['did'];
                    $delay  = $_POST['delay'];
                    $dline  = $_POST['dline'];

                    $sql = "UPDATE tb_device 
                            SET device_detail = '$dtail', 
                                alert_delay = '$delay', 
                                token_line = '$dline' 
                            WHERE id = '$did'";

                    // รันคำสั่ง SQL
                    if ($conn->query($sql) === TRUE) {
                        echo "<script>alert('บันทึกการแก้ไขข้อมูลสำเร็จ'); window.location.href='device.php';</script>";
                    } else {
                        echo "เกิดข้อผิดพลาด: " . $conn->error;
                    }
                }
            ?>

            <style>
                .box-buttons {
        display: flex;
        justify-self: end;
        /* position: ; */
        width: 100%;
        /* height: 20px; */
        top: 18%;
        /* right: -8%; */
        /* padding: 10px; */
        align-items: right;
        border-radius: 10px;
        justify-content: flex-end;
    }
     .buttons {
        margin: 8px
    }
            </style>

           
<?php $id = $_GET["id"]; ?>
            <div class="container my-5 shadow p-4 rounded">
                <h2 class="text-center">การตั้งค่าการจ่ายยา</h1>
                <nav class="navbar navbar-expand-lg bg-light shadow-sm mb-5">
            <div class="container">


                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- เนื้อหาของ Navbar -->
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto gap-3">
                        <li class="nav-item">
                            <a class="nav-link" href="home_admin.php">
                                <i class="bi bi-house"></i> หน้าหลัก
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="detial.php?id=<?php echo $_GET['id']; ?>">
                                <i class="bi bi-capsule"></i> เครื่องจ่ายยา
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="data1.php?id=<?php echo $_GET['id']; ?>">
                                <i class="bi bi-file-medical"></i> ข้อมูลยา
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="etial.php?id=<?php echo $_GET['id']; ?>">
                                <i class="bi bi-gear"></i> ตั้งค่าการจ่ายยา
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="history.php?id=<?php echo $_GET['id']; ?>">
                                <i class="bi bi-clock-history"></i> ประวัติการจ่ายยา
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

                <div class="table-responsive">
                <table class="table table-striped table-bordered text-center ggtable">
                    <thead>
                        <tr>
                            <th scope="col" class="w-25">เช้า</th>
                            <th scope="col" class="w-25">กลางวัน</th>
                            <th scope="col" class="w-25">เย็น</th>
                            <th scope="col" class="w-25">ก่อนนอน</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php foreach($conn->query("SELECT * FROM tb_data_bf WHERE id = $id") as $z) {
                                echo substr($z['time_bf'], 0, 5);} ?>
                            </td>
                            <td><?php foreach($conn->query("SELECT * FROM tb_data_lunch WHERE id = $id") as $z) {
                                echo substr($z['time_lunch'], 0, 5);} ?>
                            </td>
                            <td><?php foreach($conn->query("SELECT * FROM tb_data_dn WHERE id = $id") as $z) {
                                echo substr($z['time_dn'], 0, 5);} ?>
                            </td>
                            <td><?php foreach($conn->query("SELECT * FROM tb_data_bb WHERE id = $id") as $z) {
                                echo substr($z['time_bb'], 0, 5);} ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <?php foreach($conn->query("SELECT * FROM tb_data_bf WHERE id = '$id'") as $z) {
                                $r1 = $z['medicine_id'];
                                $r2 = $z['medicine_id2'];
                                $r3 = $z['medicine_id3'];
                                $r4 = $z['medicine_id4'];

                                if ($r1 != NULL) {
                                    $sql_1 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r1'");
                                    $ech_1 = $sql_1->fetch_assoc();
                                    echo $ech_1['medicine_name'] . "<hr>";
                                }
                                
                                if ($r2 != NULL) {
                                    $sql_2 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r2'");
                                    $ech_2 = $sql_2->fetch_assoc();   
                                    echo $ech_2['medicine_name'] . "<hr>";
                                }

                                if ($r3 != NULL) {
                                    $sql_3 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r3'");
                                    $ech_3 = $sql_3->fetch_assoc();
                                    echo $ech_3['medicine_name'] . "<hr>";
                                }
                                
                                if ($r4 != NULL) {
                                    $sql_4 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r4'");
                                    $ech_4 = $sql_4->fetch_assoc();
                                    echo $ech_4['medicine_name'] . "<hr>";
                                }}?>
                            </td>
                            <td>
                            <?php foreach($conn->query("SELECT * FROM tb_data_lunch WHERE id = '$id'") as $z) {
                                $r1 = $z['medicine_id'];
                                $r2 = $z['medicine_id2'];
                                $r3 = $z['medicine_id3'];
                                $r4 = $z['medicine_id4'];

                                if ($r1 != NULL) {
                                    $sql_1 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r1'");
                                    $ech_1 = $sql_1->fetch_assoc();
                                    echo $ech_1['medicine_name']  . "<hr>";
                                }

                                if ($r2 != NULL) {
                                    $sql_2 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r2'");
                                    $ech_2 = $sql_2->fetch_assoc();   
                                    echo $ech_2['medicine_name']  . "<hr>";
                                }

                                if ($r3 != NULL) {
                                    $sql_3 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r3'");
                                    $ech_3 = $sql_3->fetch_assoc();
                                    echo $ech_3['medicine_name']  . "<hr>";
                                }

                                if ($r4 != NULL) {
                                    $sql_4 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r4'");
                                    $ech_4 = $sql_4->fetch_assoc();
                                    echo $ech_4['medicine_name']  . "<hr>";
                                }}?>
                            </td>
                            <td>
                            <?php foreach($conn->query("SELECT * FROM tb_data_dn WHERE id = '$id'") as $z) {
                                $r1 = $z['medicine_id'];
                                $r2 = $z['medicine_id2'];
                                $r3 = $z['medicine_id3'];
                                $r4 = $z['medicine_id4'];

                                if ($r1 != NULL) {
                                    $sql_1 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r1'");
                                    $ech_1 = $sql_1->fetch_assoc();
                                    echo $ech_1['medicine_name'] . "<hr>";
                                }

                                if ($r2 != NULL) {
                                    $sql_2 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r2'");
                                    $ech_2 = $sql_2->fetch_assoc();   
                                    echo $ech_2['medicine_name']  . "<hr>";
                                }

                                if ($r3 != NULL) {
                                    $sql_3 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r3'");
                                    $ech_3 = $sql_3->fetch_assoc();
                                    echo $ech_3['medicine_name']  . "<hr>";
                                }

                                if ($r4 != NULL) {
                                    $sql_4 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r4'");
                                    $ech_4 = $sql_4->fetch_assoc();
                                    echo $ech_4['medicine_name']  . "<hr>";
                                }}?>
                            </td>
                            <td>
                            <?php foreach($conn->query("SELECT * FROM tb_data_bb WHERE id = '$id'") as $z) {
                                $r1 = $z['medicine_id'];
                                $r2 = $z['medicine_id2'];
                                $r3 = $z['medicine_id3'];
                                $r4 = $z['medicine_id4'];

                                if ($r1 != NULL) {
                                    $sql_1 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r1'");
                                    $ech_1 = $sql_1->fetch_assoc();
                                    echo $ech_1['medicine_name']  . "<hr>";
                                }

                                if ($r2 != NULL) {
                                    $sql_2 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r2'");
                                    $ech_2 = $sql_2->fetch_assoc();   
                                    echo $ech_2['medicine_name']  . "<hr>";
                                }

                                if ($r3 != NULL) {
                                    $sql_3 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r3'");
                                    $ech_3 = $sql_3->fetch_assoc();
                                    echo $ech_3['medicine_name']  . "<hr>";
                                }

                                if ($r4 != NULL) {
                                    $sql_4 = $conn->query("SELECT * FROM tb_medicine WHERE medicine_id = '$r4'");
                                    $ech_4 = $sql_4->fetch_assoc();
                                    echo $ech_4['medicine_name']  . "<hr>";
                                }}?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div>
            </div>
        <?php } ?>
            




            <script>
                function updateItemsPerPage() {
                        const itemsPerPage = document.getElementById('itemsPerPageSelect').value;
                        const currentPage = <?php echo $page; ?>; // ค่าเพจปัจจุบันจาก PHP
                        window.location.href = `?items_per_page=${itemsPerPage}&page=${currentPage}`;
                    }
                    function printTable() {
                        // ดึงตารางที่ต้องการพิมพ์
                        var table = document.getElementById('printableTable');

                        if (!table) {
                            alert("ไม่พบตารางที่ต้องการพิมพ์");
                            return;
                        }

                        // ดึงเนื้อหาหัวตาราง (thead) และเนื้อหาข้อมูล (tbody)
                        var thead = table.querySelector('thead').outerHTML;
                        var tbody = table.querySelector('tbody').outerHTML;

                        // สร้าง HTML สำหรับการพิมพ์
                        var printContent = `
                            <html>
                                <head>
                                    <title>ประวัติการจ่ายยา</title>
                                    <style>
                                        table {
                                            width: 100%;
                                            border-collapse: collapse;
                                            text-align: center;
                                        }
                                        th, td {
                                            border: 1px solid black;
                                            padding: 8px;
                                        }
                                        th {
                                            background-color: #f2f2f2;
                                        }
                                        body {
                                            font-family: Arial, sans-serif;
                                            margin: 20px;
                                        }
                                    </style>
                                </head>
                                <body>
                                    <h2 style="text-align: center;">ประวัติการจ่ายยา</h2>
                                    <table>${thead}${tbody}</table>
                                </body>
                            </html>
                        `;

                        // เปิดหน้าต่างใหม่สำหรับการพิมพ์
                        var printWindow = window.open('', '_blank');
                        printWindow.document.open();
                        printWindow.document.write(printContent);
                        printWindow.document.close();

                        // รอให้โหลดเสร็จแล้วจึงพิมพ์
                        printWindow.onload = function () {
                            printWindow.print();
                            printWindow.close();
                        };
                    }
            </script>

        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
</html>