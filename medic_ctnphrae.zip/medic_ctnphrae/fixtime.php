<?php

include 'php/chk_id.php';
include 'php/navbar.php';

if (isset($_POST["submit"])) {

    $meal_count = $_POST['meal_count']; // รับค่า meal_count จากฟอร์ม

    if (!empty($id) && !empty($meal_count)) {

        // ตรวจสอบว่ามี ID อยู่ในฐานข้อมูลหรือไม่
        $check_sql = "SELECT id FROM tb_device WHERE id = '$id'";
        $check_result = mysqli_query($conn, $check_sql);

        if (mysqli_num_rows($check_result) > 0) {
            // ถ้ามี ID อยู่แล้ว ให้ทำการอัปเดตจำนวนมื้อ
            $update_sql = "UPDATE tb_device SET meal_count = '$meal_count' WHERE id = '$id'";
            if (mysqli_query($conn, $update_sql)) {
                // ดำเนินการบันทึกเวลาของมื้ออาหาร
                $delete_old_meals_sql = "DELETE FROM tb_meal_times WHERE device_id = '$id'";
                mysqli_query($conn, $delete_old_meals_sql);

                for ($i = 1; $i <= $meal_count; $i++) {
                    $meal_time = $_POST["meal_time_$i"];
                    $meal_period = $_POST["meal_period_$i"];

                    // เพิ่มข้อมูลมื้ออาหารใหม่
                    $insert_meal_sql = "INSERT INTO tb_meal_times (device_id, meal_number, meal_time, meal_period) 
                                        VALUES ('$id', '$i', '$meal_time', '$meal_period')";
                    mysqli_query($conn, $insert_meal_sql);
                }

                $deleteQueries = [
                    "DELETE FROM tb_data_bf WHERE id = '$id'",
                    "DELETE FROM tb_data_lunch WHERE id = '$id'",
                    "DELETE FROM tb_data_dn WHERE id = '$id'",
                    "DELETE FROM tb_data_bb WHERE id = '$id'"
                ];

                foreach ($deleteQueries as $query) {
                    if (!$conn->query($query)) {
                        echo "เกิดข้อผิดพลาด: " . $conn->error;
                    }
                }

                echo "<script>
                        alert('บันทึกข้อมูลกำหนดมื้อจ่ายยา สำเร็จ!');
                        window.location.href = 'set_medicine.php';
                      </script>";
            } else {
                echo "<script>
                        alert('การอัปเดตข้อมูลล้มเหลว: " . mysqli_error($conn) . "');
                        window.location.href = 'home.php';
                      </script>";
            }
        } else {
            // ถ้าไม่มี ID ให้แจ้งเตือน
            echo "<script>
                    alert('ไม่สามารถบันทึกข้อมูลได้ กรุณาติดต่อผู้ดูแลระบบ');
                    window.location.href = 'home.php';
                  </script>";
        }
    } else {
        echo "<script>
                alert('ข้อมูลไม่ครบถ้วน กรุณาลองใหม่!');
                window.location.href = 'home.php';
              </script>";
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <title>กำหนดจำนวนมื้อ</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        body {
            background-color: #e0e0e0;
        }

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: white;
            max-width: 800px;
            width: 90%;
        }

        .ggtable {
            min-width: 450px;
        }

        .ca {
            cursor: pointer;
            width: 50%;
        }
    </style>
</head>

<body>


    <!-- ฟอร์มแสดงข้อมูลและการแก้ไข -->
    <div class="container my-5 shadow p-4 rounded">
        <h2 class="text-center">กำหนดจำนวนมื้อจ่ายยา</h2>

        <?php
        // ดึงข้อมูลจำนวนมื้อจากฐานข้อมูล
        $meal_count = 0; // ค่าเริ่มต้น

        if (!empty($id)) {
            // นับข้อมูลในแต่ละตาราง
            $tables = ['tb_data_bf', 'tb_data_lunch', 'tb_data_dn', 'tb_data_bb'];
            foreach ($tables as $table) {
                $query = "SELECT COUNT(*) AS count FROM $table WHERE id = '$id'";
                $result = mysqli_query($conn, $query);
                if ($row = mysqli_fetch_assoc($result)) {
                    $meal_count += (int) $row['count']; // รวมจำนวนข้อมูลจากทุกตาราง
                }
            }
        }
        //$meal_count = 0;
        //if (!empty($id)) {
        //    $query = "SELECT meal_count FROM tb_device WHERE id = '$id'";
        //    $result = mysqli_query($conn, $query);
        //    if ($row = mysqli_fetch_assoc($result)) {
        //        $meal_count = $row['meal_count'];
        //    }
        //}
        ?>

        <form method="POST" action=" ">
            <div class="card-body">
                <h5 class="card-title text-success">เลือกจำนวนมื้อ</h5>
                <div class="d-flex flex-wrap gap-2">
                    <!-- Option 1 -->
                    <div class="card border-success text-center option-card ca <?= ($meal_count == 1) ? 'bg-success text-white' : ''; ?>" onclick="selectMeal(1)">
                        <div class="card-body">
                            <h6 class="card-text">1 มื้อ</h6>
                        </div>
                    </div>
                    <!-- Option 2 -->
                    <div class="card border-success text-center option-card ca <?= ($meal_count == 2) ? 'bg-success text-white' : ''; ?>" onclick="selectMeal(2)">
                        <div class="card-body">
                            <h6 class="card-text">2 มื้อ</h6>
                        </div>
                    </div>
                    <!-- Option 3 -->
                    <div class="card border-success text-center option-card ca <?= ($meal_count == 3) ? 'bg-success text-white' : ''; ?>" onclick="selectMeal(3)">
                        <div class="card-body">
                            <h6 class="card-text">3 มื้อ</h6>
                        </div>
                    </div>
                    <!-- Option 4 -->
                    <div class="card border-success text-center option-card ca <?= ($meal_count == 4) ? 'bg-success text-white' : ''; ?>" onclick="selectMeal(4)">
                        <div class="card-body">
                            <h6 class="card-text">4 มื้อ</h6>
                        </div>
                    </div>
                </div>
                <!-- Hidden input to store the selected value -->
                <input type="hidden" id="mealCount" name="meal_count" value="<?= $meal_count; ?>">
            </div>

            <script>
                function selectMeal(value) {
                    // Clear previously selected cards
                    document.querySelectorAll('.option-card').forEach(card => {
                        card.classList.remove('bg-success', 'text-white');
                    });

                    // Highlight the selected card
                    const selectedCard = document.querySelector(`.option-card:nth-child(${value})`);
                    selectedCard.classList.add('bg-success', 'text-white');

                    // Update the hidden input value
                    document.getElementById('mealCount').value = value;
                }
            </script>

            <div class="text-center my-3">
                <button id="saveButton" class="btn btn-primary" type="submit" name="submit">บันทึกการตั้งค่าจำนวนมื้อ</button>
            </div>
        </form>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>