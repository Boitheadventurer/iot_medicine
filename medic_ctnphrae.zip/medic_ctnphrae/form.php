

<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code</title>
</head>
 
<body>

<form action="" method="POST">
    <input type="url" name="url" id="">
    <button type="submit" >กดซะ</button>
</form>
        <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['url'])) {
                include "php/conn.php";
                $url = $_POST["url"];
                $id = 3;
                $sql = "UPDATE `tb_device` SET `url` = '$url' WHERE `device_id` = '$id'";
                $conn->query($sql);
                // if () {
                //     echo "<script>window.location.href='../home.php';</script>";
                // } else { 
                //     echo "<script>alert('แก้ไขจ่ายยา ล้มเหลว!'); window.location.href='../home.php';</script>";
                // }
                echo "maaaaa";
                include 'phpqrcode/qrlib.php';
                $flie_name = "qr.png";
                $text = $_POST["url"];
                QRcode::png($text, $flie_name);
             ?>
               <img src="<?php echo $flie_name; ?>" alt="">
            <?php }
        ?>

</body>

</html>
