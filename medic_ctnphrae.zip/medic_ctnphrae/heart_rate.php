 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ฟอร์มเก็บข้อมูลสุขภาพ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background-color: #f8d7da;
            /* สีพื้นหลังแดงอ่อน */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .form-container {
            background-color: white;
            /* สีพื้นหลังของฟอร์มแดงอ่อน */
            width: 100%;
            max-width: 400px;
            /* กำหนดขนาดความกว้างของฟอร์ม */
            padding: 20px;
            border-radius: 10px;
        }

        .btn-danger-custom {
            background-color: #dc3545;
            border: none;
        }

        .btn-danger-custom:hover {
            background-color: #c82333;
        }

        .form-header {
            color: #721c24;
            /* สีหัวข้อแดงเข้ม */
        }

        .form-container img {
            max-width: 100px; /* ขนาดสูงสุดของรูปภาพ */
            display: block;
            margin: 0 auto 20px; /* จัดกลางและมีระยะห่างจากด้านล่าง */
        }
    </style>
</head>

<body>
<?php
include 'php/conn.php';

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['id'];


            if (!$userId) {
                die("��辺������ʼ������ʪѹ");
            }

            $sql = "SELECT firstname_th, lastname_th FROM user WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
            } else {
                $row = [
                    'firstname' => "��辺������",
                    'lastname' => "��辺������"
                ];
            }


?>
    <div class="form-container shadow position-relative">
        <!-- ปุ่มกลับ -->
        <a href="home.php" class="btn btn-outline-secondary position-absolute top-0 start-0 m-3">
            <i class="bi bi-arrow-left"></i> กลับ
        </a>

        <img src="image/AI.png" alt="Medic Icon">
        <div class="text-end text-danger">
            <!-- <strong>รหัสผู้ใช้:</strong> <?php echo htmlspecialchars($_SESSION['id']); ?> -->
        </div>
        <form action="php/save_health_data.php" method="POST">
            <h3 class="text-center mb-4 form-header">วัดความดันและชีพจร</h3>

            <input type="hidden" name="id" value="<?php echo htmlspecialchars($_SESSION['id']); ?>">
            <div class="mb-3">
 <input type="hidden" name="id" value="<?php echo htmlspecialchars($_SESSION['id']); ?>">
            <input type="hidden" name="firstname" value="<?php echo htmlspecialchars($row['firstname_th']); ?>">
            <input type="hidden" name="lastname" value="<?php echo htmlspecialchars($row['lastname_th']); ?>">
                <label for="systolicPressure" class="form-label">ความดันสูง (Systolic) <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="systolicPressure" name="systolic_pressure" placeholder="กรอกค่าความดันสูง" maxlength="3" required>
            </div>
            <div class="mb-3">
                <label for="diastolicPressure" class="form-label">ความดันต่ำ (Diastolic) <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="diastolicPressure" name="diastolic_pressure" placeholder="กรอกค่าความดันต่ำ" maxlength="3" required>
            </div>
            <div class="mb-3">
                <label for="pulseRate" class="form-label">ชีพจร (Pulse) <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="pulseRate" name="pulse_rate" placeholder="กรอกค่าชีพจร" maxlength="3" required>
            </div>
            <div class="text-center mt-2">
                <button type="submit" class="btn btn-danger">
                    <i class="ri-heart-pulse-line"></i> บันทึก
                </button>
                <button type="reset" class="btn btn-secondary">
                    <i class="bi bi-arrow-clockwise"></i> ล้างข้อมูล
                </button>
                <a href="heart_report.php" class="btn btn-success">
                    <i class="ri-file-text-line"></i> รายงาน
                </a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
