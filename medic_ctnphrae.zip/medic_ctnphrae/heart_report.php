<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลสุขภาพ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
   
    <style>
@import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

body {
    background-color: #e0e0e0;
}

* {
    margin: 0;
    padding: 0;
    font-family: "Bai Jamjuree", sans-serif;
}
        hr {
        border: none;
        height: 2px;
        background-color: #000;
    }

        .table-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .table th {
            background-color: #dc3545;
            color: white;
            text-align: center;
        }

        .table tbody tr:hover {
            background-color: #f5c6cb;
        }

   

        .chart-container {
            display: flex;
            justify-content: space-between;
        }

        .chart-wrapper {
            width: 48%; /* กำหนดให้กราฟแบ่งขนาดพื้นที่ออกเป็น 2 ส่วน */
        }

        .section-title {
            font-size: 18px;
    font-weight: 600;
    margin: 10px 0;
    }

    .info-row {
        display: flex;
        justify-content: space-between;
        margin: 5px 0;
        font-size: 16px;
    }

    .info-row p {
        margin: 5px 0;
    }

    .info-group {
        width: 48%;
    }
    .info-group2 {
        width: 15%;
        margin-right: 5% ;
        margin-left: 19% ;
    }
    .info-group3 {

    }

    .box-user-all{
        padding:25px;
        border-radius: 8px;
        border: 1px solid #ccc;
        /* text-align:center */
        width: 220mm;
        /* background:red; */
    }
    .box-user-erorr{
        justify-content: center;
        align-items: center;
        display:flex;
        width:100%;
        margin:0px 0px 25px 0;
    }

    </style>

    <!-- ไสตล์ของ Modal -->
    <style>
        #modalInfo {
            font-size: 1.5rem; /* เพิ่มขนาดตัวหนังสือ */
            font-weight: bold;
        }
        .modal-dialog {
            max-width: 800px; /* กำหนดความกว้าง modal */
            margin: auto;
        }
        .modal-body {
            font-size: 1.2rem; /* ขยายขนาดตัวอักษรภายใน modal body */
        }
    </style>

</head>
 <!--gemini-->
 <?php 
            function Gemini($prompt) {
                $api_key = "AIzaSyBg-_YMe9T9tyau32USnJ92ziwAX15wj_c";
                $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={$api_key}";
                $data = array(
                    "contents" => array(
                        array(
                            "role" => "user",
                            "parts" => array(
                                array(
                                    "text" => $prompt
                                )
                            )
                        )
                    )
                );
                $json_data = json_encode($data);
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $response = curl_exec($ch);
                curl_close($ch);
                if(curl_errno($ch)) {
                    return 'Curl error: ' . curl_error($ch);
                }
                return json_decode($response, true)["candidates"][0]["content"]["parts"][0]["text"];
            }
        ?>
        
        <?php
            // include 'php/conn.php';
            
            include 'php/chk_id.php'; 
            include 'php/navbar.php';
            $count = 0;
        ?>
<?php
$sql = "SELECT tb_data_bf.*,tb_medicine.* 
FROM tb_data_bf  
INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id
WHERE tb_data_bf.id ='$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    // echo  $row["medicine_name"];
  }
}
$sql = "SELECT tb_data_bf.*,tb_medicine.* 
FROM tb_data_bf  
INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id2
WHERE tb_data_bf.id ='$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    // echo  $row["medicine_name"];
  }
}
$sql = "SELECT tb_data_bf.*,tb_medicine.* 
FROM tb_data_bf  
INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id3
WHERE tb_data_bf.id ='$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    // echo  $row["medicine_name"];
  }
}
$sql = "SELECT tb_data_bf.*,tb_medicine.* 
FROM tb_data_bf  
INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id4
WHERE tb_data_bf.id ='$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    // echo  $row["medicine_name"];
  }
}
?>
<?php
$sql = "SELECT 
tb_device.*, 
user.*, 
tb_data_bf.*, 
tb_data_lunch.*, 
tb_data_dn.*, 
tb_data_bb.*, 
tb_medicine.*, 
DATE_FORMAT(user.dob, '%d/%m/%Y') AS formatted_dob 
FROM tb_device 
INNER JOIN user ON user.id = tb_device.id
INNER JOIN tb_data_bf ON tb_data_bf.id = user.id
INNER JOIN tb_data_lunch ON tb_data_lunch.id = user.id
INNER JOIN tb_data_dn ON tb_data_dn.id = user.id
INNER JOIN tb_data_bb ON tb_data_bb.id = user.id
INNER JOIN tb_medicine ON tb_medicine.id = user.id
WHERE tb_device.id = '$id'";
$result = $conn->query($sql);   
$row2 = $result->fetch_assoc();

?>

<?php
$sql = "SELECT 
tb_device.*, 
user.*, 

DATE_FORMAT(user.dob, '%d/%m/%Y') AS formatted_dob 
FROM tb_device 
INNER JOIN user ON user.id = tb_device.id

WHERE tb_device.id = '$id'";
$result = $conn->query($sql);   
$row1 = $result->fetch_assoc();

?>

<style>
        .loading-spinner {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(255, 255, 255, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }

    .spinner-border {
        width: 3rem;
        height: 3rem;
    }
</style>

<script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("loadingSpinner").style.display = "none";
        });
    </script>

<body>

  <div id="loadingSpinner" class="loading-spinner">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
        <p>กำลังโหลดข้อมูล...</p>
    </div>

    <div class="container mt-5">
    <div class="table-container">
        
     
    

     <div class="box-user-erorr">
        
        <div class="box-user-all">
            <div style="width:100%; display: flex; align-items: center;">
        <img style="    width: 100px;
    margin-right: 10px;" src="./image/AI.png" alt="Logo">
                <div style="font-size: 30px;
    font-weight: 600;" class="header-title">
                     รายงานข้อมูลความดันและชีพจร
                </div>
                </div>
                <hr>
                <div class="box-back-color" style="background-color: #e0e0e0; padding: 20px; padding-left: 50px; border-radius: 10px;">
        <div class="section-title">ข้อมูลผู้ป่วย</div>

<div class="info-row">
    <div class="info-group">
        <p>ชื่อจริง: <?php echo $row1['firstname_th']; ?></p>
    </div>
    <div class="info-group">
        <p>นามสกุล: <?php echo $row1['lastname_th']; ?></p>
    </div>
</div>

<div class="info-row">
    <div class="info-group">
        <p>วัน / เดือน / ปีเกิด: <?php echo $row1['formatted_dob']; ?></p>
    </div>
    <!-- <div class="info-group2" >
        <p>อายุ :20  ปี</p>
    </div> -->
    <div class="info-group">
        <p>เพศ:
            <?php echo ($row1['gender'] == 'male') ? 'ชาย' : 'หญิง'; ?>
        </p>
    </div>
</div>

<div class="info-row">
    <div class="info-group">
        <p>ที่อยู่: <?php echo $row1['address']; ?></p>
    </div>
</div>
<div class="info-row">
    <div class="info-group">
        <p>โรคประจำตัว: <?php echo $row1['chronic_disease']; ?></p>
    </div>
    </div>
</div>


<!-- <div class="info-row">
  
</div> -->
<hr>
<div style="text-align:center; margin-bottom:20px;">
        <button class="btn btn-primary" id="printButton" onclick="openPrintPage()">ส่งออกเอกสาร</button>
        <!-- <button class="btn btn-primary" onclick="goToDownloadPage()">ดาวน์โหลดเอกสาร</button> -->

<script>
    function goToDownloadPage() {
        window.location.href = 'heart_report_pdf.php'; // ลิงก์ไปยังหน้า download
    }
</script>
        </div>





      
        <div class="container">

        <style>
            .box-text-qrcode-1{
                text-align:center;
                justify-content: center;
                align-items: center; 
                width: 120px;
                margin-bottom: 5px;
                display:flex;
            }
            .box-text-qrcode-All{
        
                width: 100%;
                display:flex;
                justify-content: center;
                align-items: center; 
                gap:30px;
                /* margin-top: 20px ; */
            }
            .box-qrcode-all-1{
                width: 100%;
            }

            .box-qrcode-image-1{
                width: 120px;
    height: 120px;
    border: 1px solid #000;
    margin-bottom: 5px;
    display:flex;
            }
   
        </style>

  

</div>

</div>
</div>
            <table class="table table-bordered table-hover text-center">
                <thead>
                    <tr>
                        <th>ลำดับ</th>
                        <th>ความดันสูง (Systolic)</th>
                        <th>ความดันต่ำ (Diastolic)</th>
                        <th>ชีพจร (Pulse)</th>
                        <th>คำเเนะนำประจำวัน</th>
                        <th>วันที่บันทึก</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                

                        // ฟังก์ชันในการแปลงวันที่เป็นภาษาไทย
                        function convertToThaiDate($date) {
                            $thaiMonths = [
                                "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน",
                                "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม",
                                "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
                            ];
                            $timestamp = strtotime($date);
                            $day = date('d', $timestamp); 
                            $month = $thaiMonths[date('n', $timestamp) - 1];
                            $year = date('Y', $timestamp) + 543; 
                            $time = date('H:i', $timestamp); // แสดงเวลาในรูปแบบ 24 ชั่วโมง
                        
                            return "$day $month $year เวลา $time น.";
                        }
                        

                    $sql = "SELECT * FROM tb_heart ORDER BY date DESC";
                    $result = $conn->query($sql);

                       // กำหนดจำนวนรายการต่อหน้า
        $itemsPerPage = 10;

        // คำนวณหน้าปัจจุบันจาก query string (URL)
        $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        // คำนวณ OFFSET สำหรับการ query ข้อมูล
        $offset = ($currentPage - 1) * $itemsPerPage;

        // คำสั่ง SQL ดึงข้อมูล
        $sql = "SELECT * FROM tb_heart ORDER BY date DESC LIMIT $itemsPerPage OFFSET $offset";
        $result = $conn->query($sql);

        // คำนวณจำนวนหน้าทั้งหมด
        $countSql = "SELECT COUNT(*) AS total FROM tb_heart";
        $countResult = $conn->query($countSql);
        $totalRows = $countResult->fetch_assoc()['total'];
        $totalPages = ceil($totalRows / $itemsPerPage);


                    $heartid = [];
                    $dates = [];
                    $systolic = [];
                    $diastolic = [];
                    $pulse = [];
                    $heartinfo = [];

                    if ($result->num_rows > 0) {
                        $i = 1;
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                            <td hidden>{$row['heart_id']}</td>
                            <td>{$i}</td>
                            <td>{$row['systolic_pressure']} mmHg</td>
                            <td>{$row['diastolic_pressure']} mmHg</td>
                            <td>{$row['pulse_rate']} bpm</td>
                            <td><i class='fa-solid fa-magnifying-glass' data-toggle='modal' data-target='#exampleModal' data-hid='{$row['heart_report']}' data-dates='" . date('d/m/Y H:i', strtotime($row['date'])) . "'></i></td>
                            <td>" . convertToThaiDate($row['date']) . "</td>
                        </tr>";
                        

                            $heartid[] = $row['heart_id'];
                            $dates[] = date('Y-m-d', strtotime($row['date']));
                            $systolic[] = $row['systolic_pressure'];
                            $diastolic[] = $row['diastolic_pressure'];
                            $pulse[] = $row['pulse_rate'];
                            $heartinfo[] = [
                                "วันที่" => $dates,
                                "ค่าความดันสูง" => $systolic,
                                "ค่าความดันต่ำ" => $diastolic,
                                "ค่าชีพจร" => $pulse
                            ];
                            $i++;
                        }
                    } else {
                        echo "<tr>
                                <td colspan='5' class='text-danger'>ไม่มีข้อมูล</td>
                              </tr>";
                    }
                    
                    $conn->close();
                    ?>
                </tbody>
            </table>

            <nav>
        <ul class="pagination justify-content-center">
            <?php if ($currentPage > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $currentPage - 1; ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php for ($page = 1; $page <= $totalPages; $page++): ?>
                <li class="page-item <?php echo ($page == $currentPage) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page; ?>"><?php echo $page; ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $currentPage + 1; ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

    <style>
                /* Media Query สำหรับหน้าจอมือถือ */
@media (max-width: 768px) {
    /* ปรับขนาดตัวอักษรและระยะห่าง */
    body {
        font-size: 14px;
    }

    .table-container {
        padding: 10px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .header-title {
        font-size: 24px;
    }

    .info-row {
        flex-direction: column;
        margin: 10px 0;
    }

    .info-group, .info-group2, .info-group3 {
        width: 100%;
    }

    .box-user-all {
        width: 100%; /* ทำให้ขนาดเต็มหน้าจอ */
        padding: 15px;
    }

    .box-user-erorr {
        flex-direction: column;
    }

    .filters {
        flex-direction: column;
        gap: 10px;
        padding: 10px;
    }

    .chart-container {
        flex-direction: column;
        gap: 20px;
        padding: 10px;
    }

    .chart-wrapper {
        width: 100%;
    }

    .table th, .table td {
        font-size: 12px;
        padding: 5px;
    }

    .btn {
        font-size: 14px;
        padding: 10px 15px;
        margin: 5px 0;
        width: 100%;
    }

    .loading-spinner {
        padding: 20px;
    }

    .spinner-border {
        width: 2rem;
        height: 2rem;
    }

    /* ปรับ modal ให้เหมาะสม */
    .modal-dialog {
        max-width: 100%;
        margin: 10px;
    }

    .modal-body {
        font-size: 14px;
    }
    .chart-container {
        flex-direction: column; /* เปลี่ยนเป็นแนวตั้ง */
        gap: 15px;
    }

    .chart-wrapper {
        width: 100%; /* ให้ wrapper ขยายเต็มหน้าจอ */
        padding: 15px; /* เพิ่ม padding รอบกราฟ */
    }

    .canvas-char-box {
        width: 100% !important; /* กำหนดความกว้างเต็ม */
        height: 200px !important; /* เพิ่มความสูงกราฟให้มากขึ้น */
        max-width: none; /* ป้องกันขนาดถูกจำกัด */
    }

    .chart-title {
        font-size: 18px; /* ขยายฟอนต์หัวข้อเล็กน้อย */
    }
}

     .filters {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 15px;
        margin-top: 20px;
        padding: 10px 0;
        background-color: #ffffff;
        border-radius: 8px;
    }

    .filters label {
        font-weight: bold;
        color: #333;
    }

    .filters select {
        padding: 5px 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    .chart-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-items: flex-start;
        gap: 20px;
        padding: 20px;
    }

    .chart-wrapper {
        background-color: #ffffff;
        border-radius: 8px;
        padding: 20px;
        max-width: 500px;
        flex: 1;
    }

    .chart-wrapper h3 {
        margin-bottom: 20px;
        font-size: 18px;
        color: #555;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    canvas {
        display: block;
        margin: 0 auto;
        max-width: 100%;
        height: auto;
    }

    /* เพิ่มความสวยงามเมื่อหน้าจอเล็ก */
    @media (max-width: 768px) {
        .filters {
            flex-direction: column;
            gap: 10px;
        }

        .chart-container {
            flex-direction: column;
        }

        .chart-wrapper {
            width: 100%;
        }
    }
    .ai-box-messenger{
            margin-top: 25px;
            border: solid 0.5px;
            padding: 25px;
        }

</style>



<div class="chart-container">
    <div class="chart-wrapper">
        <h3 style="font-weight: 800;" class="text-center text-danger">ภาพรวมความดันโลหิตช่วง 15 วันล่าสุด</h3>
        <canvas class="canvas-char-box" id="healthChart" width="500" height="300"></canvas>
    </div>

    <div class="chart-wrapper">
        <h3 style="font-weight: 800;" class="text-center text-primary">ภาพรวมชีพจรช่วง 15 วันล่าสุด</h3>
        <canvas class="canvas-char-box" id="pulseChart" width="500" height="300"></canvas>
    </div>
</div>

<div class="filters">
    <div style="display:none;">
    <label for="filter-day">เลือกวัน:</label>
    <select id="filter-day" onchange="updateChart()">
        <option value="">ทุกวัน</option>
        <!-- Populate day options dynamically with JavaScript -->
    </select>
    </div>
    
    <label for="filter-month">เลือกเดือน:</label>
    <select id="filter-month" onchange="updateChart()">
        <option value="">ทุกเดือน</option>
        <!-- Populate month options dynamically with JavaScript -->
    </select>
    
    <label for="filter-year">เลือกปี:</label>
    <select id="filter-year" onchange="updateChart()">
        <option value="">ทุกปี</option>
        <!-- Populate year options dynamically with JavaScript -->
    </select>
</div>
  
 

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">คำเเนะนำ ประจำวัน</h5>
                    <h5 class="modal-title" id="modaldate"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="modalInfo"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
                </div>
            </div>
        </div>
    </div>


    <div class="ai-box-messenger">
    <h4>คำเเนะนำในการดูเเลตัวเองเเละการปรับพฤติกรรมที่เหมาะสม</h4>
    <?php
        $STinfo = json_encode($heartinfo); // แปลงค่า allinfo เป็น JSON string

           $Gen = Gemini("นี่คือรายงานค่าความดันสูง ความดันต่ำ เเละค่าชีพจรในเเต่ละวัน มีข้อมูลตามนี้.$STinfo.ช่วยประเมินโรคที่อาจเกิดขึ้นเเละให้คำเเนะนำในการดูเเลตัวเองเเละการปรับพฤติกรรมที่เหมาะสม");
            //$Gen = Gemini("ทวนค่า.$STinfo.ออกมาอีกที");
            echo str_replace("*","","$Gen");
            $text = str_replace("*","","$Gen");
            $_SESSION['gen'] = $text;
    ?>

</div>
    
    </div>
        </div>
           </div>

    
    <script>
// Sample data (replace these with the actual PHP-generated data)
const dates = <?= json_encode($dates); ?>;
const systolic = <?= json_encode($systolic); ?>;
const diastolic = <?= json_encode($diastolic); ?>;
const pulse = <?= json_encode($pulse); ?>;

// ฟอร์แมตรูปแบบวันที่ในภาษาไทย
function formatDateInThai(date) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Intl.DateTimeFormat('th-TH', options).format(new Date(date));
}

// ฟังก์ชันเติมตัวเลือกใน <select>
function populateSelectOptions() {
    const days = new Set();
    const months = new Set();
    const years = new Set();

    // ดึงค่าจากวันที่ในตัวแปร dates
    dates.forEach(dateStr => {
        const date = new Date(dateStr);
        days.add(date.getDate());
        months.add(date.getMonth() + 1);
        years.add(date.getFullYear());
    });

    // แปลง Set เป็น Array และเรียงลำดับ
    const sortedDays = Array.from(days).sort((a, b) => a - b);
    const sortedMonths = Array.from(months).sort((a, b) => a - b);
    const sortedYears = Array.from(years).sort((a, b) => a - b);

    // เติมตัวเลือกลงใน select
    const daySelect = document.getElementById('filter-day');
    const monthSelect = document.getElementById('filter-month');
    const yearSelect = document.getElementById('filter-year');

    // ล้างตัวเลือกเก่า
    daySelect.innerHTML = '<option value="">ทุกวัน</option>';
    monthSelect.innerHTML = '<option value="">ทุกเดือน</option>';
    yearSelect.innerHTML = '<option value="">ทุกปี</option>';

    // เติมตัวเลือกใหม่
    sortedDays.forEach(day => {
        const option = document.createElement('option');
        option.value = day;
        option.text = day;
        daySelect.appendChild(option);
    });

    sortedMonths.forEach(month => {
        const option = document.createElement('option');
        option.value = month;
        option.text = new Intl.DateTimeFormat('th-TH', { month: 'long' }).format(new Date(2020, month - 1, 1));
        monthSelect.appendChild(option);
    });

 // เติมตัวเลือกใหม่ใน Select สำหรับปี (เปลี่ยนปี ค.ศ. เป็น พ.ศ.)
sortedYears.forEach(year => {
    const option = document.createElement('option');
    option.value = year; // ยังคงใช้ปี ค.ศ. สำหรับการกรองข้อมูล
    option.text = year + 543; // แสดงปี พ.ศ. ใน dropdown
    yearSelect.appendChild(option);
});

}

// ฟังก์ชันอัปเดตกราฟตามตัวกรอง
function updateChart() {
    const day = document.getElementById('filter-day').value;
    const month = document.getElementById('filter-month').value;
    const year = document.getElementById('filter-year').value;

    const filteredDates = [];
    const filteredSystolic = [];
    const filteredDiastolic = [];
    const filteredPulse = [];

    dates.forEach((dateStr, index) => {
        const date = new Date(dateStr);
        const currentDay = date.getDate();
        const currentMonth = date.getMonth() + 1;
        const currentYear = date.getFullYear();

        if (
            (!day || currentDay == day) &&
            (!month || currentMonth == month) &&
            (!year || currentYear == year)
        ) {
            filteredDates.push(formatDateInThai(dateStr));
            filteredSystolic.push(systolic[index]);
            filteredDiastolic.push(diastolic[index]);
            filteredPulse.push(pulse[index]);
        }
    });

    // อัปเดตข้อมูลในกราฟ
    healthChart.data.labels = filteredDates;
    healthChart.data.datasets[0].data = filteredSystolic;
    healthChart.data.datasets[1].data = filteredDiastolic;
    healthChart.update();

    pulseChart.data.labels = filteredDates;
    pulseChart.data.datasets[0].data = filteredPulse;
    pulseChart.update();
}

// สร้างกราฟ Health Chart
const healthChartCtx = document.getElementById('healthChart').getContext('2d');
const healthChart = new Chart(healthChartCtx, {
    type: 'line',
    data: {
        labels: dates.map(date => formatDateInThai(date)),
        datasets: [
            {
                label: 'ความดันสูง (Systolic)',
                data: systolic,
                borderColor: 'rgba(255, 99, 132, 1)',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderWidth: 2
            },
            {
                label: 'ความดันต่ำ (Diastolic)',
                data: diastolic,
                borderColor: 'rgba(54, 162, 235, 1)',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderWidth: 2
            }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});

// สร้างกราฟ Pulse Chart
const pulseChartCtx = document.getElementById('pulseChart').getContext('2d');
const pulseChart = new Chart(pulseChartCtx, {
    type: 'line',
    data: {
        labels: dates.map(date => formatDateInThai(date)),
        datasets: [
            {
                label: 'ชีพจร (Pulse)',
                data: pulse,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderWidth: 2
            }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});

// ฟังก์ชันเปิดหน้าสำหรับพิมพ์
function openPrintPage() {
    const printWindow = window.open('heart_report_print.php');
    printWindow.onload = function () {
        printWindow.print();
        printWindow.onafterprint = function () {
            printWindow.close();
        };
    };
}

// เรียกฟังก์ชันเพื่อเติมตัวเลือกเมื่อโหลดหน้า
populateSelectOptions();

</script>

    <!-- modal script -->
    <script>
        $('#exampleModal').on('show.bs.modal', function (event) {
            // ดึง element ที่ trigger modal
            var button = $(event.relatedTarget);
            
            // ดึงค่า data-hid จาก button
            var heartId = button.data('hid');
            var heartDate = button.data('dates');
            
            // แสดงค่าใน modal
            $(this).find('#modalInfo').text(heartId);
            $(this).find('#modaldate').text(heartDate);
        });
    </script>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- Remix Icon -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
        <!-- Icon Title -->
        <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
</body>

</html>