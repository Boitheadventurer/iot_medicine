<!DOCTYPE html>
<html lang="en">



<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลสุขภาพ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>

    <style>
        body {
            background-color:rgb(255, 255, 255);
            line-height: 1.8; 
        }
        p, div, span {
    line-height: 1.6; /* กำหนดให้ทุกข้อความมีระยะห่างเหมาะสม */
}

        .table-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .table th {
            background-color: #dc3545;
            color: white;
            text-align: center;
        }

        .table tbody tr:hover {
            background-color: #f5c6cb;
        }

        .chart-container {
            /* display: flex; */
            justify-content: space-between;
        }

        .chart-wrapper {
            width: 100%; /* กำหนดให้กราฟแบ่งขนาดพื้นที่ออกเป็น 2 ส่วน */
        }

        .section-title {
            font-size: 18px;
    font-weight: 600;
    margin: 10px 0;
    }

    .info-row {
        display: flex;
        justify-content: space-between;
        margin: 5px 0;
        font-size: 16px;
    }

    .info-row p {
        margin: 5px 0;
    }

    .info-group {
        width: 48%;
    }

    .box-user-all{
        padding:25px;
        border-radius: 8px;
        border: 1px solid #ccc;
        /* text-align:center */
        width: 100%;
        /* background:red; */
    }
    .box-user-erorr{
        justify-content: center;
        align-items: center;
        display:flex;
        width:100%;
        margin:0px 0px 25px 0;
    }
    </style>

    <!-- ไสตล์ของ Modal -->
    <style>
        #modalInfo {
            font-size: 1.5rem; /* เพิ่มขนาดตัวหนังสือ */
            font-weight: bold;
        }
        .modal-dialog {
            max-width: 800px; /* กำหนดความกว้าง modal */
            margin: auto;
        }
        .modal-body {
            font-size: 1.2rem; /* ขยายขนาดตัวอักษรภายใน modal body */
        }
    </style>

</head>



 <!--gemini-->
 <?php 
            function Gemini($prompt) {
                $api_key = "AIzaSyBg-_YMe9T9tyau32USnJ92ziwAX15wj_c";
                $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={$api_key}";

                $data = array(
                    "contents" => array(
                        array(
                            "role" => "user",
                            "parts" => array(
                                array(
                                    "text" => $prompt
                                )
                            )
                        )
                    )
                );
                $json_data = json_encode($data);
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $response = curl_exec($ch);
                curl_close($ch);
                if(curl_errno($ch)) {
                    return 'Curl error: ' . curl_error($ch);
                }
                return json_decode($response, true)["candidates"][0]["content"]["parts"][0]["text"];
            }
        ?>
        
        <?php
            // include 'php/conn.php';
            include 'php/chk_id.php';   
            $count = 0;
        ?>
<?php
$sql = "SELECT tb_data_bf.*,tb_medicine.* 
FROM tb_data_bf  
INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id
WHERE tb_data_bf.id ='$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    // echo  $row["medicine_name"];
  }
}
$sql = "SELECT tb_data_bf.*,tb_medicine.* 
FROM tb_data_bf  
INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id2
WHERE tb_data_bf.id ='$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    // echo  $row["medicine_name"];
  }
}
$sql = "SELECT tb_data_bf.*,tb_medicine.* 
FROM tb_data_bf  
INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id3
WHERE tb_data_bf.id ='$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    // echo  $row["medicine_name"];
  }
}
$sql = "SELECT tb_data_bf.*,tb_medicine.* 
FROM tb_data_bf  
INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id4
WHERE tb_data_bf.id ='$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    // echo  $row["medicine_name"];
  }
}
?>
<?php
$sql = "SELECT 
tb_device.*, 
user.*, 
tb_data_bf.*, 
tb_data_lunch.*, 
tb_data_dn.*, 
tb_data_bb.*, 
tb_medicine.*, 
DATE_FORMAT(user.dob, '%d/%m/%Y') AS formatted_dob 
FROM tb_device 
INNER JOIN user ON user.id = tb_device.id
INNER JOIN tb_data_bf ON tb_data_bf.id = user.id
INNER JOIN tb_data_lunch ON tb_data_lunch.id = user.id
INNER JOIN tb_data_dn ON tb_data_dn.id = user.id
INNER JOIN tb_data_bb ON tb_data_bb.id = user.id
INNER JOIN tb_medicine ON tb_medicine.id = user.id
WHERE tb_device.id = '$id'";
$result = $conn->query($sql);   
$row2 = $result->fetch_assoc();

?>

<?php
$sql = "SELECT 
tb_device.*, 
user.*, 

DATE_FORMAT(user.dob, '%d/%m/%Y') AS formatted_dob 
FROM tb_device 
INNER JOIN user ON user.id = tb_device.id

WHERE tb_device.id = '$id'";
$result = $conn->query($sql);   
$row1 = $result->fetch_assoc();

?>

<style>
        .loading-spinner {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(255, 255, 255, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }

    .spinner-border {
        width: 3rem;
        height: 3rem;
    }
</style>


<script>
  function downloadPDF() {
            var element = document.body; // เปลี่ยน document.body เป็นส่วนที่ต้องการ
            var options = {
                filename: 'file.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 4 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            html2pdf().from(element).set(options).save().then(() => {
                window.location.href = 'heart_report.php'; // ไปยังหน้า heart_report.php
            });
        }

        document.addEventListener("DOMContentLoaded", function() {
            // ซ่อน Loading Spinner หลังจากโหลด DOM เสร็จ
            document.getElementById("loadingSpinner").style.display = "none";

            // รอ 5 วินาทีก่อนเรียก downloadPDF
            setTimeout(downloadPDF, 1000);
        });
    </scrip>

<body>

  <div id="loadingSpinner" class="loading-spinner">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
        <p>กำลังโหลดข้อมูล...</p>
    </div>

        
    

        <div class="box-user-erorr">
        
        <div class="box-user-all">
            <div style="width:100%; display: flex; align-items: center;">
        <img style="    width: 100px;
    margin-right: 10px;" src="./image/AI.png" alt="Logo">
                <div style="font-size: 30px;
    font-weight: 600;" class="header-title">
                                        รายงานข้อมูลความดันและชีพจร

                </div>
                </div>
                <hr>
                <div class="box-back-color" style="background-color: #e0e0e0; padding: 20px; padding-left: 50px; border-radius: 10px;">
        <div class="section-title">ข้อมูลผู้ป่วย</div>

<div class="info-row">
    <div class="info-group">
        <p>ชื่อจริง: <?php echo $row1['firstname_th']; ?></p>
    </div>
    <div class="info-group">
        <p>นามสกุล: <?php echo $row1['lastname_th']; ?></p>
    </div>
</div>

<div class="info-row">
    <div class="info-group">
        <p>วัน / เดือน / ปีเกิด: <?php echo $row1['formatted_dob']; ?></p>
    </div>
    <!-- <div class="info-group2" >
        <p>อายุ :20  ปี</p>
    </div> -->
    <div class="info-group">
        <p>เพศ:
            <?php echo ($row1['gender'] == 'male') ? 'ชาย' : 'หญิง'; ?>
        </p>
    </div>
</div>

<div class="info-row">
    <div class="info-group">
        <p>ที่อยู่: <?php echo $row1['address']; ?></p>
    </div>
</div>
<div class="info-row">
    <div class="info-group">
        <p>โรคประจำตัว: <?php echo $row1['chronic_disease']; ?></p>
    </div>
    </div>
</div>

      

        <style>
            .box-text-qrcode-1{
                text-align:center;
                justify-content: center;
                align-items: center; 
                width: 90px;
                margin-bottom: 5px;
                display:flex;
            }
            .box-text-qrcode-All{
        
                width: 100%;
                display:flex;
                justify-content: center;
                align-items: center; 
                gap:30px;
                /* margin-top: 20px ; */
            }
            .box-qrcode-all-1{
                width: 100%;
            }

            .box-qrcode-image-1{
                width: 90px;
    height: 80px;
    border: 1px solid #000;
    margin-bottom: 5px;
    display:flex;
            }
            .box-qrcode-image-1 > img{
             width: 100%;
            }

            @media print {
    .hr-enter {
        page-break-before: always;
    }
}
   
        </style>

        

   
    <!-- <hr> -->

</div>
</div>
<!-- <div class="hr-enter"> </div> -->
 <div style="padding: 25px;">
            <table class="table table-bordered table-hover text-center">
                <thead>
                    <tr>
                        <th>ลำดับ</th>
                        <th>ความดันสูง (Systolic)</th>
                        <th>ความดันต่ำ (Diastolic)</th>
                        <th>ชีพจร (Pulse)</th>
                        <th>วันที่บันทึก</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                

                        // ฟังก์ชันในการแปลงวันที่เป็นภาษาไทย
                        function convertToThaiDate($date) {
                            $thaiMonths = [
                                "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน",
                                "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม",
                                "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
                            ];
                            $timestamp = strtotime($date);
                            $day = date('d', $timestamp); 
                            $month = $thaiMonths[date('n', $timestamp) - 1];
                            $year = date('Y', $timestamp) + 543; 
                            $time = date('H:i', $timestamp); // แสดงเวลาในรูปแบบ 24 ชั่วโมง
                        
                            return "$day$month$year เวลา$time";
                        }
                        
                        $sql = "SELECT * FROM tb_heart ORDER BY date DESC";
                        $result = $conn->query($sql);
                        
                        $heartid = [];
                        $dates = [];
                        $systolic = [];
                        $diastolic = [];
                        $pulse = [];
                        $heartinfo = [];
                    if ($result->num_rows > 0) {
                        $i = 1;
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                            <td hidden>{$row['heart_id']}</td>
                            <td>{$i}</td>
                            <td>{$row['systolic_pressure']} mmHg</td>
                            <td>{$row['diastolic_pressure']} mmHg</td>
                            <td>{$row['pulse_rate']} bpm</td>
                            <td>" . convertToThaiDate($row['date']) . "</td>
                        </tr>";
                        

                            $heartid[] = $row['heart_id'];
                            $dates[] = date('Y-m-d', strtotime($row['date']));
                            $systolic[] = $row['systolic_pressure'];
                            $diastolic[] = $row['diastolic_pressure'];
                            $pulse[] = $row['pulse_rate'];
                            $heartinfo[] = [
                                "วันที่" => $dates,
                                "ค่าความดันสูง" => $systolic,
                                "ค่าความดันต่ำ" => $diastolic,
                                "ค่าชีพจร" => $pulse
                            ];
                            $i++;
                        }
                    } else {
                        echo "<tr>
                                <td colspan='5' class='text-danger'>ไม่มีข้อมูล</td>
                              </tr>";
                    }
                    
                    $conn->close();
                    ?>
                </tbody>
            </table>
            </div>


    <style>
     .filters {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 15px;
        margin-top: 20px;
        padding: 10px 0;
        background-color: #ffffff;
        border-radius: 8px;
    }

    .filters label {
        font-weight: bold;
        color: #333;
    }

    .filters select {
        padding: 5px 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    .chart-container {
        /* display: flex; */
        flex-wrap: wrap;
        justify-content: space-around;
        align-items: flex-start;
        gap: 20px;
        padding: 20px;
    }

    .chart-wrapper {
        background-color: #ffffff;
        border-radius: 8px;
        padding: 20px;
        /* max-width: 500px; */
        flex: 1;
    }

    .chart-wrapper h3 {
        margin-bottom: 20px;
        font-size: 18px;
        color: #555;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    canvas {
        display: block;
        margin: 0 auto;
        max-width: 100%;
        height: auto;
    }

    /* เพิ่มความสวยงามเมื่อหน้าจอเล็ก */
    @media (max-width: 768px) {
        .filters {
            flex-direction: column;
            gap: 10px;
        }

        .chart-container {
            flex-direction: column;
        }

        .chart-wrapper {
            width: 100%;
        }
    }
    
</style>

<style>
@media print {
    body {
        font-size: 14px;
        line-height: 1.5; /* ระยะห่างระหว่างบรรทัด */
        word-wrap: break-word; /* บังคับให้ข้อความตัดคำ */
    }

    .info-row {
        display: block; /* เปลี่ยนจาก flex เพื่อป้องกันการบีบข้อมูล */
        margin-bottom: 10px;
    }

    .info-group {
        margin-bottom: 5px;
    }

    table {
        width: 100%;
        border-collapse: collapse; /* ตัดขอบระหว่างช่องว่างของตาราง */
        font-size: 12px; /* ลดขนาดฟอนต์ตาราง */
    }

    th, td {
        padding: 8px;
        word-wrap: break-word;
    }

    .chart-container, .chart-wrapper {
        page-break-inside: avoid; /* ป้องกันกราฟถูกตัดในระหว่างหน้า */
        width: 100%; /* กำหนดความกว้างเต็มหน้า */
    }

    .ai-box-messenger {
        page-break-before: always; /* ให้ขึ้นหน้าใหม่ */
    }
    canvas {
        width: 100% !important;
        height: auto !important;
    }
}


</style>

<div class="chart-container">
    <div class="chart-wrapper">
    
    <p style="font-weight: 800; " class="text-center text-primary">ภาพรวมความดันโลหิตช่วง15วันล่าสุด</p>
        <canvas style="    height: 500px;
    width: 800px; "  id="healthChart" width="500" height="300"></canvas>
    </div>

    <div class="chart-wrapper">
    
    <p style="font-weight: 800; " class="text-center text-primary">ภาพรวมชีพจรช่วง15วันล่าสุด</p>
        <canvas style="    height: 500px;
    width: 800px; " id="pulseChart" width="500" height="300"></canvas>
    </div>
</div>

  
 

    <style>
        .ai-box-messenger{
            margin-top: 25px;
            border: solid 0.5px;
            padding: 25px;
        }
    </style>


<div class="ai-box-messenger">
    <h4>คำเเนะนำในการดูเเลตัวเองเเละการปรับพฤติกรรมที่เหมาะสม</h4>
    <?php
        $STinfo = json_encode($heartinfo); // แปลงค่า allinfo เป็น JSON string

           $Gen = Gemini("นี่คือรายงานค่าความดันสูง ความดันต่ำ เเละค่าชีพจรในเเต่ละวัน มีข้อมูลตามนี้.$STinfo.ช่วยประเมินโรคที่อาจเกิดขึ้นเเละให้คำเเนะนำในการดูเเลตัวเองเเละการปรับพฤติกรรมที่เหมาะสม");
            //$Gen = Gemini("ทวนค่า.$STinfo.ออกมาอีกที");
            echo str_replace("*","","$Gen");
    ?>

</div>
    
    </div>
        </div>

    
    <script>
// Sample data (replace these with the actual PHP-generated data)
const dates = <?= json_encode($dates); ?>.slice(0, 15);
const systolic = <?= json_encode($systolic); ?>.slice(0, 15);
const diastolic = <?= json_encode($diastolic); ?>.slice(0, 15);
const pulse = <?= json_encode($pulse); ?>.slice(0, 15);


// ฟอร์แมตรูปแบบวันที่ในภาษาไทย
function formatDateInThai(date) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Intl.DateTimeFormat('th-TH', options).format(new Date(date));
}

// ฟังก์ชันเติมตัวเลือกใน <select>
function populateSelectOptions() {
    const days = new Set();
    const months = new Set();
    const years = new Set();

    // ดึงค่าจากวันที่ในตัวแปร dates
    dates.forEach(dateStr => {
        const date = new Date(dateStr);
        days.add(date.getDate());
        months.add(date.getMonth() + 1);
        years.add(date.getFullYear());
    });

    // แปลง Set เป็น Array และเรียงลำดับ
    const sortedDays = Array.from(days).sort((a, b) => a - b);
    const sortedMonths = Array.from(months).sort((a, b) => a - b);
    const sortedYears = Array.from(years).sort((a, b) => a - b);

    // เติมตัวเลือกลงใน select
    const daySelect = document.getElementById('filter-day');
    const monthSelect = document.getElementById('filter-month');
    const yearSelect = document.getElementById('filter-year');

    // ล้างตัวเลือกเก่า
    daySelect.innerHTML = '<option value="">ทุกวัน</option>';
    monthSelect.innerHTML = '<option value="">ทุกเดือน</option>';
    yearSelect.innerHTML = '<option value="">ทุกปี</option>';

    // เติมตัวเลือกใหม่
    sortedDays.forEach(day => {
        const option = document.createElement('option');
        option.value = day;
        option.text = day;
        daySelect.appendChild(option);
    });

    sortedMonths.forEach(month => {
        const option = document.createElement('option');
        option.value = month;
        option.text = new Intl.DateTimeFormat('th-TH', { month: 'long' }).format(new Date(2020, month - 1, 1));
        monthSelect.appendChild(option);
    });

 // เติมตัวเลือกใหม่ใน Select สำหรับปี (เปลี่ยนปี ค.ศ. เป็น พ.ศ.)
sortedYears.forEach(year => {
    const option = document.createElement('option');
    option.value = year; // ยังคงใช้ปี ค.ศ. สำหรับการกรองข้อมูล
    option.text = year + 543; // แสดงปี พ.ศ. ใน dropdown
    yearSelect.appendChild(option);
});

}

// ฟังก์ชันอัปเดตกราฟตามตัวกรอง
function updateChart() {
    const day = document.getElementById('filter-day').value;
    const month = document.getElementById('filter-month').value;
    const year = document.getElementById('filter-year').value;

    const filteredDates = [];
    const filteredSystolic = [];
    const filteredDiastolic = [];
    const filteredPulse = [];

    dates.forEach((dateStr, index) => {
        const date = new Date(dateStr);
        const currentDay = date.getDate();
        const currentMonth = date.getMonth() + 1;
        const currentYear = date.getFullYear();

        if (
            (!day || currentDay == day) &&
            (!month || currentMonth == month) &&
            (!year || currentYear == year)
        ) {
            filteredDates.push(formatDateInThai(dateStr));
            filteredSystolic.push(systolic[index]);
            filteredDiastolic.push(diastolic[index]);
            filteredPulse.push(pulse[index]);
        }
    });

    // อัปเดตข้อมูลในกราฟ
    healthChart.data.labels = filteredDates;
    healthChart.data.datasets[0].data = filteredSystolic;
    healthChart.data.datasets[1].data = filteredDiastolic;
    healthChart.update();

    pulseChart.data.labels = filteredDates;
    pulseChart.data.datasets[0].data = filteredPulse;
    pulseChart.update();
}

// สร้างกราฟ Health Chart
const healthChartCtx = document.getElementById('healthChart').getContext('2d');
const healthChart = new Chart(healthChartCtx, {
    type: 'line',
    data: {
        labels: dates.map(date => formatDateInThai(date)),
        datasets: [
            {
                label: 'ความดันสูง (Systolic)',
                data: systolic,
                borderColor: 'rgba(255, 99, 132, 1)',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderWidth: 2
            },
            {
                label: 'ความดันต่ำ (Diastolic)',
                data: diastolic,
                borderColor: 'rgba(54, 162, 235, 1)',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderWidth: 2
            }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});

// สร้างกราฟ Pulse Chart
const pulseChartCtx = document.getElementById('pulseChart').getContext('2d');
const pulseChart = new Chart(pulseChartCtx, {
    type: 'line',
    data: {
        labels: dates.map(date => formatDateInThai(date)),
        datasets: [
            {
                label: 'ชีพจร (Pulse)',
                data: pulse,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderWidth: 2
            }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});


// Populate filter options on page load
populateSelectOptions();



</script>



</body>

</html>
