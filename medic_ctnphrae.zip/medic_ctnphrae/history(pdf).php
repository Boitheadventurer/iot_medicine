<?php
session_start(); // เริ่มต้น session เพื่อใช้งาน session variable
?>
<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เครื่องจ่ายยาอัตโนมัติ</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;600&display=swap');

    /* General Styling */
    body {
        font-family: "Bai Jamjuree", sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f9f9f9;
        color: #000;
    }

    .document-container {
        width: 210mm;
        height: 297mm;
        margin: 10px auto;
        background: #fff;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        padding: 30px;
        box-sizing: border-box;
        
    }



    hr {
        border: none;
        height: 2px;
        background-color: #000;
    }

    /* Header Section */
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .header img {
        width: 100px;
        margin-right: 10px;
    }

    .header-title {
        font-size: 30px;
        font-weight: 600;
    }

    .date-section {
        text-align: right;
        font-size: 14px;
    }

    /* Patient Info Section */
    .section-title {
        font-size: 18px;
        font-weight: 600;
        margin: 10px 0;
    }

    .info-row {
        display: flex;
        justify-content: space-between;
        margin: 5px 0;
        font-size: 16px;
    }

    .info-row p {
        margin: 5px 0;
    }

    .info-group {
        width: 48%;
    }

    /* Footer */
    .footer {
        margin-top: 20px;
        font-size: 14px;
        text-align: center;
    }

    .container {
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        background-color: white;
        padding: 5px;
    }

    .qrcode-box {
        width: 150px;
        height: 150px;
        border: 1px solid #000;
        margin-bottom: 5px;
    }

    .qrcode-label {
        text-align: center;
        font-size: 14px;
    }

    .info-section {
        font-size: 16px;
        margin-left: 20px;
    }

    .info-section p {
        margin: 10px 0;
    }

    .info-section span {
        font-weight: bold;
    }

    .dotted-line {
        display: inline-block;
        border-bottom: 1px dotted #000;
        width: 250px;
    }

    .qr-image {
        width: 150px;
        height: 150px;
    }

    /* Loading Spinner */
    .loading-spinner {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(255, 255, 255, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }

    .spinner-border {
        width: 3rem;
        height: 3rem;
    }
    @media print {
        .none {
            display: none;
        }

        .document-container {
            width: 100%;
            height: 99vh;
        }

        .info-section {

            margin-right: 250px;
        }
        .gemini-box {
            page-break-inside: avoid; /* หลีกเลี่ยงการแบ่งหน้าใน div */
            margin-bottom: 20px; /* ระยะห่างระหว่างส่วน */
        }

        .gemini-box:last-of-type {
            page-break-after: always; /* แบ่งหน้าเมื่อถึง div สุดท้าย */
        }

        
    }
    </style>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>

    <script>
        function downloadPDF() {
            var element = document.body; // เปลี่ยน document.body เป็นส่วนที่ต้องการ
            var options = {
                filename: 'file.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 4 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            
            
            
            html2pdf().from(element).set(options).save().then(() => {
                window.location.href = 'history.php'; // ไปยังหน้า history.php
            });
        }

        document.addEventListener("DOMContentLoaded", function() {
            // ซ่อน Loading Spinner หลังจากโหลด DOM เสร็จ
            document.getElementById("loadingSpinner").style.display = "none";

            // รอ 1 วินาทีก่อนเรียก downloadPDF
            setTimeout(downloadPDF, 1000);
        });
    </script>
    
</head>

<body>
    <div id="loadingSpinner" class="loading-spinner">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
        <p class="mt-3"> กำลังประมวลผล...</p>
    </div>
    <?php
            include 'php/chk_id.php';   
        ?>
        <!--gemini-->
        <?php 
            function Gemini($prompt) {
                $api_key = "AIzaSyBg-_YMe9T9tyau32USnJ92ziwAX15wj_c";
                $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={$api_key}";
                $data = array(
                    "contents" => array(
                        array(
                            "role" => "user",
                            "parts" => array(
                                array(
                                    "text" => $prompt
                                )
                            )
                        )
                    )
                );
                $json_data = json_encode($data);
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $response = curl_exec($ch);
                curl_close($ch);
                if(curl_errno($ch)) {
                    return 'Curl error: ' . curl_error($ch);
                }
                return json_decode($response, true)["candidates"][0]["content"]["parts"][0]["text"];
            }
        ?>
    <?php
        // สมมติว่ามีการเชื่อมต่อฐานข้อมูล
        // $id = 1; // กำหนดค่า ID ตัวอย่าง
        $sql = "SELECT * FROM tb_device INNER JOIN user ON user.id = tb_device.id WHERE tb_device.id = '$id'";
        $result = $conn->query($sql);   
        $row = $result->fetch_assoc();
    ?>

    
    <!-- เอกสาร -->
    <div class="document-container">
        <!-- Header -->
        <div class="header">
            <div style="display: flex; align-items: center;">
                <img src="./image/AI.png" alt="Logo">
                <div class="header-title">
                    รายงานข้อมูลการจ่ายยา
                </div>
            </div>
            <div class="date-section">


            </div>
        </div>

        <hr>

        <!-- Patient Info -->
        <div style="background-color: #e0e0e0; padding: 20px; padding-left: 50px; border-radius: 10px;">
        <div class="section-title">ข้อมูลผู้ป่วย</div>
        <div class="info-row">
            <div class="info-group">
                <p>ชื่อจริง: <?php echo $row['firstname_th']; ?></p>
            </div>
            <div class="info-group">
                <p>นามสกุล: <?php echo $row['lastname_th']; ?></p>
            </div>
        </div>
        <div class="info-row">
            <div class="info-group">
                <p>ปีเกิด / เดือน / วัน: <?php echo $row['dob']; ?></p>
            </div>
            <div class="info-group">
                <p>เพศ:
                    <?php echo ($row['gender'] == 'male') ? 'ชาย' : 'หญิง'; ?>
                </p>
            </div>
        </div>
        <div class="info-row">
            <div class="info-group">
                <p>ที่อยู่: <?php echo $row['address']; ?></p>
            </div>
            <!-- <div class="info-group">
                <p>หมู่ที่: <?php //echo $row['village']; ?></p>
            </div>
            <div class="info-group">
                <p>หมู่บ้าน: <?php //echo $row['Villages']; ?></p>
            </div>-->
            <!-- <div class="info-group">
                <p>เบอร์โทร: <?php //echo $row['phone']; ?></p>
            </div>  -->
        </div>
        <div class="info-row">
            <div class="info-group">
                <p>โรคประจำตัว: <?php echo $row['chronic_disease']; ?></p>
            </div>
        </div>
</div>

        

        

        <hr>



        <!-- <div class="footer">
            <p>เอกสารนี้จัดทำโดยระบบเครื่องจ่ายยาอัตโนมัติ</p>
        </div> -->

        <div class="container">
        <div class="table-responsive">
                    <?php
                    // กำหนดจำนวนรายการต่อหน้า
                    $items_per_page = isset($_GET['items_per_page']) ? (int)$_GET['items_per_page'] : 10;

                    // รับค่าหน้าปัจจุบันจาก URL (ถ้าไม่มีให้เริ่มที่หน้า 1)
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                    $page = max($page, 1); // ตรวจสอบให้ไม่น้อยกว่า 1

                    // คำนวณตำแหน่งเริ่มต้น
                    $offset = ($page - 1) * $items_per_page;

                    // Query ประวัติการจ่ายยาพร้อมแบ่งหน้า
                    $history_query = "SELECT * , 
                                    m1.medicine_name AS medicine1, 
                                    m2.medicine_name AS medicine2, 
                                    m3.medicine_name AS medicine3, 
                                    m4.medicine_name AS medicine4
                                    FROM tb_data_eat_medicine
                                    LEFT JOIN tb_medicine ON tb_data_eat_medicine.medicine_id = tb_medicine.medicine_id
                                    LEFT JOIN tb_medicine AS m1 ON tb_data_eat_medicine.medicine_id = m1.medicine_id
                                    LEFT JOIN tb_medicine AS m2 ON tb_data_eat_medicine.medicine_id2 = m2.medicine_id
                                    LEFT JOIN tb_medicine AS m3 ON tb_data_eat_medicine.medicine_id3 = m3.medicine_id
                                    LEFT JOIN tb_medicine AS m4 ON tb_data_eat_medicine.medicine_id4 = m4.medicine_id
                                    WHERE tb_data_eat_medicine.device_id = '$id'
                                    ORDER BY tb_data_eat_medicine.time_get DESC
                                    LIMIT $items_per_page OFFSET $offset";
                    $history_result = $conn->query($history_query);

                    //ส่วนดึงชื่อยาส่งให้บอท
                    $Genmedic = "SELECT * FROM tb_medicine WHERE id = '$id'";
                    $Genmedic_re = $conn->query($Genmedic);
                    $med_rows = []; // อาเรย์สำหรับเก็บข้อมูลทุกแถว
                    while ($Med_row = $Genmedic_re->fetch_assoc()) {
                        $med_rows[] = $Med_row; // เก็บข้อมูลแถวลงในอาเรย์
                    }

                    //ดึงโรคประจำตัวส่งบอท
                    $Chro = "SELECT chronic_disease FROM user WHERE id = '$id'";
                    $Chro_re = $conn->query($Chro);
                    if ($Chro_re->num_rows > 0) {
                        $Chro_row = $Chro_re->fetch_assoc();
                        $uchro = $Chro_row['chronic_disease'];
                    } else {
                        $uchro = null;
                    }


                    //นับจำนวนสำเร็จ
                    $Success_query = "SELECT COUNT(*) AS 'total_success'FROM tb_data_eat_medicine WHERE
                    device_id = '$id' AND medicine_get LIKE 'success'";
                    $Success_result = $conn->query($Success_query);
                    $Success = $Success_result->fetch_assoc();

                    //นับจำนวนไม่สำเร็จ
                    $Fail_query = "SELECT COUNT(*) AS 'total_fail'FROM tb_data_eat_medicine WHERE
                            device_id = '$id' AND medicine_get LIKE 'failed'";
                    $Fail_result = $conn->query($Fail_query);
                    $Fail = $Fail_result->fetch_assoc();

                    // Query นับจำนวนรายการทั้งหมด
                    $count_query = "SELECT COUNT(*) AS total_items FROM tb_data_eat_medicine WHERE device_id = '$id'";
                    $count_result = $conn->query($count_query);
                    $total_items = $count_result->fetch_assoc()['total_items'];

                    // คำนวณจำนวนหน้าทั้งหมด
                    $total_pages = ceil($total_items / $items_per_page);
                    ?>
                        <!-- Dropdown เลือกจำนวนแถวแบบไม่ใช้ฟอร์ม -->
                        
                        

    <table class="table table-striped table-bordered text-center ggtable page-break"  id="printableTable">
    <thead>
        <tr>
            <th>ลำดับ</th>
            <th>วันที่ - เวลา</th>
            <th>ชื่อยา</th>
            <th>ผลลัพธ์การจ่ายยา</th>
        </tr>
    </thead>
    <tbody>
    <?php
                    function convertToThaiDate($date) {
                        $thaiMonths = [
                            "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน",
                            "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม",
                            "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
                        ];
                        $timestamp = strtotime($date);
                        $day = date('d', $timestamp); 
                        $month = $thaiMonths[date('n', $timestamp) - 1];
                        $year = date('Y', $timestamp) + 543; 
                        $time = date('H:i', $timestamp); // แสดงเวลาในรูปแบบ 24 ชั่วโมง
                        
                        return "$day $month $year เวลา $time";
                    }

                    $allmedic = [];

                    $history_query = "SELECT tb_data_eat_medicine.*, 
                                        m1.medicine_name AS medicine1, 
                                        m2.medicine_name AS medicine2, 
                                        m3.medicine_name AS medicine3, 
                                        m4.medicine_name AS medicine4
                                    FROM tb_data_eat_medicine
                                    LEFT JOIN tb_medicine AS m1 ON tb_data_eat_medicine.medicine_id = m1.medicine_id
                                    LEFT JOIN tb_medicine AS m2 ON tb_data_eat_medicine.medicine_id2 = m2.medicine_id
                                    LEFT JOIN tb_medicine AS m3 ON tb_data_eat_medicine.medicine_id3 = m3.medicine_id
                                    LEFT JOIN tb_medicine AS m4 ON tb_data_eat_medicine.medicine_id4 = m4.medicine_id
                                    WHERE tb_data_eat_medicine.device_id = '$id'
                                    ORDER BY tb_data_eat_medicine.time_get DESC";

                    $history_result = $conn->query($history_query);
                    $allinfo = [];
                    if ($history_result->num_rows > 0) { 
                        $count = 0;
                        while ($history_row = $history_result->fetch_assoc()) {
                            $count++;
                            $data_id = $history_row['data_id']; // ดึงค่า data_id
                            $datetime = $history_row['time_get']; // วันที่และเวลา
                            $thaiDate = convertToThaiDate($datetime); // ใช้ฟังก์ชันแปลงวันที่เป็นภาษาไทย

                            $medicines = array_filter([
                                $history_row['medicine1'],
                                $history_row['medicine2'],
                                $history_row['medicine3'],
                                $history_row['medicine4']
                            ]);
                            $medicine_list = implode("<br>", $medicines);

                            $medicine_get_result = ($history_row['medicine_get'] == 'success') ? 'สำเร็จ' : 'ไม่สำเร็จ';
                            $allinfo[] = [
                                "วันที่และเวลา" => $thaiDate,
                                "ชื่อยา" => $medicine_list,
                                "ผลลัพธ์การจ่ายยา" => $medicine_get_result
                            ];
                            $cfail = $Fail['total_fail'];
                            echo "<tr>
                                    <td>{$count}</td> <!-- แสดง ID -->
                                    <td>{$thaiDate}</td>
                                    <td>".($medicine_list !== null && $medicine_list !== '' ? $medicine_list : 'ไม่มีข้อมูล')."</td>
                                    <td><b>{$medicine_get_result}</b></td>
                                </tr>";
                        }

                        echo "<tr>
                                <td rowspan='2' colspan='3' style='text-align: center; vertical-align: middle; font-weight: bold;'>สรุปผลการจ่ายยา</td>
                                <td ><b>สำเร็จ : {$Success['total_success']}</b></td>
                            </tr>
                            <tr>
                                <td ><b>ไม่สำเร็จ : {$Fail['total_fail']}</b></td>
                            </tr>";
                    } else {
                        echo "<tr><td colspan='4'>ไม่มีประวัติการจ่ายยา</td></tr>";
                    }
?>

    </tbody>
</table>

<br>
<h4 class="page-break">คำแนะนำ</h4>
<?php
                        $Checkfail = json_encode($cfail); // แปลงค่าเป็น JSON string
                        $STinfo = json_encode($allinfo , JSON_UNESCAPED_UNICODE);  // แปลงค่า allinfo เป็น JSON string
                        $allmedic = json_encode($allmedic , JSON_UNESCAPED_UNICODE);
                        $checkmed = json_encode($med_rows , JSON_UNESCAPED_UNICODE);

                        if($uchro != null){
                        $Genchro = Gemini("ความเสี่ยงของผู้เป็นโรค.$uchro.");
                        $textchro = str_replace("*", "", $Genchro);
                        //echo "<div class='gemini-box'><h5>ความเสี่ยงของผู้เป็นโรค{$uchro}</h5><br><h5>{$textchro}</h5></div>";
                        //echo "<br>";
                        }
                        //บอกวิธีการกินยา
                        // $Med1 = Gemini("ช่วยให้คำเเนะนำในการรับประทานยาเหล่านี้เเละข้อมูลของยา.$checkmed.ให้เว้น1บรรทัดทุกครั้งเมื่อเป็นยาถัดไปหากยาเม็ดไหนไม่มีข้อมูลเข้ามาก็ไม่ต้องอธิบาย");
                        // $textmed = str_replace("*", "", $Med1);
                        // echo "<div class='gemini-box'><h5>คำเเนะนำสำหรับยา</h5><br><h5>{$textmed}</h5></div>";
                        //echo  $checkmed;                        
                        //foreach ($med_rows as $index => $med_row) {
                            // ตรวจสอบว่ามียาข้อมูลในแถวหรือไม่
                            //$medicine_name = isset($med_row['medicine_name']) && !empty($med_row['medicine_name']) ? $med_row['medicine_name'] : null;
                        
                            //if ($medicine_name) {
                                //echo "แถวที่ " . ($index + 1) . ": ";
                                // ส่งคำขอไปยัง Gemini
                                //$Med1 = Gemini("ช่วยให้คำเเนะนำในการรับประทานเเละข้อมูลของยาเหล่านี้.$medicine_name.เเบบที่คนทั่วไปเข้าใจ");
                                //$textmed = str_replace("*", "", $Med1);
                        
                                // แสดงผลคำแนะนำสำหรับยา
                                //echo "<div class='gemini-box'><h5>คำเเนะนำสำหรับยา{$medicine_name}</h5><br><h5>{$textmed}</h5></div>";
                                //echo "<br>";
                            //}
                        //}
                        
                        // ใช้ json_decode เพื่อแปลงกลับมา เเละให้คำเเนะนำการทานยา
                        //echo  $STinfo;
                        if (json_decode($Checkfail) === "0") {
                            $Gen = Gemini("นี่คือรายงานการจ่ายยามีข้อมูลตามนี้.$STinfo.ขอคำเเนะนำในการดูเเลตัวเองเเละการปรับพฤติกรรมที่เหมาะสมเเละสอดคล้องกับยาที่รับประทานขอเป็นประโยค");
                            $text = str_replace("*", "", $Gen);
                            echo "<div class='gemini-box'><h5>สรุปผลเเละคำเเนะนำ</h5><br><h5>{$text}</h5></div>";
                        } else {
                            $Gen = Gemini("นี่คือรายงานการจ่ายยามีข้อมูลตามนี้.$STinfo.ขอผลกระทบจากการรับประทานยาไม่ครบเเละคำเเนะนำในการรับประทานยาเเละการปรับพฤติกรรมที่เหมาะสมเเละสอดคล้องกับยาที่รับประทานขอเป็นประโยค");
                            $text = str_replace("*", "", $Gen);
                            echo "<div class='gemini-box'><h5>สรุปผลเเละคำเเนะนำ</h5><br><h5>{$text}</h5></div>";
                        }
                    ?>

                    <style>
                        /* สไตล์สำหรับกล่อง Gemini */
                        .gemini-box {
                            border: 2px solid #4CAF50; /* เส้นขอบสีเขียว */
                            border-radius: 10px;
                            padding: 15px;
                            margin: 10px 0;
                            background-color: #f9f9f9;
                            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
                            font-family: 'Arial', sans-serif;
                            color: #333;
                        }

                        .gemini-box h5 {
                            margin: 0;
                        }

                        /* บังคับขึ้นหน้าใหม่ก่อนแสดงคำแนะนำเมื่อพิมพ์ */
                        @media print {
                            .page-break {
                                page-break-before: always; /* ขึ้นหน้าใหม่ทุกครั้ง */
                            }
                        }
                    </style>


        </div>
        
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
            integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
        </script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
            integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
        </script>
        <script>
        

        </script>
</body>

</html>