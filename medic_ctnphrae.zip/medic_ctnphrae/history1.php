<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
        body {
            background-color: #e0e0e0;
        }
        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }
        .container {
            background-color: white;
            max-width: 800px;
            width: 90%;
        }
        img {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body>
    <?php
        include 'php/chk_id.php';
        include 'php/navbar.php';

        $user_info = "SELECT * FROM user WHERE id = '$id'";
        $user = $conn->query($user_info);
        $user = $user->fetch_assoc();
    ?>

    <div class="container my-5 shadow p-4 bg-white rounded">
        <!-- โลโก้ -->
        <img src="image/AI.png" alt="Logo" class="mx-auto" width="100px">

        <!-- ตารางประวัติการจ่ายยา -->
        <h2 class="text-center">ข้อมูลการจ่ายยาเครื่อง CTN<?php echo $id ?></h2>
        <div class="text-center">
            <button onclick="printTable()" class="btn btn-primary">ปริ้นตารางนี้</button>
        </div>

        <!-- ข้อมูลผู้ป่วย -->
        <div class="card mt-3">
            <div class="card-body">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>ชื่อจริง</label>
                        <input type="text" class="form-control" name="first_name" value="<?php echo htmlspecialchars($user['firstname_th']); ?>" readonly>
                    </div>
                    <div class="form-group col-md-6">
                        <label>นามสกุล</label>
                        <input type="text" class="form-control" name="last_name" value="<?php echo htmlspecialchars($user['lastname_th']); ?>" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>เดือน/วัน/ปีเกิด</label>
                        <input type="date" class="form-control" name="dob" value="<?php echo htmlspecialchars($user['dob']); ?>" readonly>
                    </div>
                    <div class="form-group col-md-4">
                        <label>เพศ</label>
                        <select class="form-control" name="gender" disabled>
                            <option value="male" <?php if ($user['gender'] == 'male') echo 'selected'; ?>>ชาย</option>
                            <option value="female" <?php if ($user['gender'] == 'female') echo 'selected'; ?>>หญิง</option>
                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label>เบอร์โทรศัพท์</label>
                        <input type="tel" class="form-control" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" readonly>
                    </div>
                </div>
                <div class="form-group">
                    <label>ที่อยู่</label>
                    <textarea class="form-control" name="address" rows="3" readonly><?php echo htmlspecialchars($user['address']); ?></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>รหัสไปรษณีย์</label>
                        <input type="text" class="form-control" name="postal_code" value="<?php echo htmlspecialchars($user['postal_code']); ?>" readonly>
                    </div>
                    <div class="form-group col-md-4">
                        <label>อีเมล</label>
                        <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                    </div>
                    <div class="form-group col-md-4">
                        <label>โรคประจำตัว</label>
                        <input type="text" class="form-control" name="user_detail" value="<?php echo htmlspecialchars($user['user_detail']); ?>" readonly>
                    </div>
                </div>
                <div class="form-group">
                    <label>Line ID</label>
                    <input type="text" class="form-control" name="line_id" value="<?php echo htmlspecialchars($user['line_id']); ?>" readonly>
                </div>
            </div>
        </div>
            </h2>
            <div class="table-responsive">
                    <?php
                    // กำหนดจำนวนรายการต่อหน้า
                    $items_per_page = isset($_GET['items_per_page']) ? (int)$_GET['items_per_page'] : 10;

                    // รับค่าหน้าปัจจุบันจาก URL (ถ้าไม่มีให้เริ่มที่หน้า 1)
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                    $page = max($page, 1); // ตรวจสอบให้ไม่น้อยกว่า 1

                    // คำนวณตำแหน่งเริ่มต้น
                    $offset = ($page - 1) * $items_per_page;

                    // Query ประวัติการจ่ายยาพร้อมแบ่งหน้า
                    $history_query = "SELECT * FROM tb_data_eat_medicine
                                    LEFT JOIN tb_medicine ON tb_data_eat_medicine.medicine_id = tb_medicine.medicine_id
                                    WHERE tb_data_eat_medicine.device_id = '$id'
                                    ORDER BY tb_data_eat_medicine.time_get DESC
                                    LIMIT $items_per_page OFFSET $offset";
                    $history_result = $conn->query($history_query);

                    //นับจำนวนสำเร็จ
                    $Success_query = "SELECT COUNT(*) AS 'total_success'FROM tb_data_eat_medicine WHERE
                    device_id = '$id' AND medicine_get LIKE 'success'";
                    $Success_result = $conn->query($Success_query);
                    $Success = $Success_result->fetch_assoc();

                    //นับจำนวนไม่สำเร็จ
                    $Fail_query = "SELECT COUNT(*) AS 'total_fail'FROM tb_data_eat_medicine WHERE
                            device_id = '$id' AND medicine_get LIKE 'failed'";
                    $Fail_result = $conn->query($Fail_query);
                    $Fail = $Fail_result->fetch_assoc();

                    // Query นับจำนวนรายการทั้งหมด
                    $count_query = "SELECT COUNT(*) AS total_items FROM tb_data_eat_medicine WHERE device_id = '$id'";
                    $count_result = $conn->query($count_query);
                    $total_items = $count_result->fetch_assoc()['total_items'];

                    // คำนวณจำนวนหน้าทั้งหมด
                    $total_pages = ceil($total_items / $items_per_page);
                    ?>
                    <!-- Dropdown เลือกจำนวนแถวแบบไม่ใช้ฟอร์ม -->
                    <div class="my-3">
                        <label for="itemsPerPageSelect">เลือกจำนวนแถวที่ต้องการแสดง:</label>
                        <select id="itemsPerPageSelect" class="form-select" onchange="updateItemsPerPage()">
                            <option value="10" <?php if ($items_per_page == 10) echo 'selected'; ?>>10 แถว</option>
                            <option value="25" <?php if ($items_per_page == 25) echo 'selected'; ?>>25 แถว</option>
                            <option value="50" <?php if ($items_per_page == 50) echo 'selected'; ?>>50 แถว</option>
                            <option value="100" <?php if ($items_per_page == 100) echo 'selected'; ?>>100 แถว</option>
                        </select>
                    </div>

                    <table class="table table-striped table-bordered text-center ggtable" id="printableTable">
                        <thead>
                            <tr>
                                <th scope="col" class="w-25">วันที่ - เวลา</th>
                                <th scope="col" class="w-25">ชื่อยา</th>
                                <th scope="col" class="w-25">ผลลัพธ์การจ่ายยา</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($history_result->num_rows > 0) {
                                while ($history_row = $history_result->fetch_assoc()) {
                                    $date = date('d/m/Y', strtotime($history_row['time_get']));
                                    $time = date('H:i', strtotime($history_row['time_get']));
                                    $medicine_name = $history_row['medicine_name'];
                                    $count = $history_row['medicine_get'];
                                    $detail = $history_row['medicine_detail'];
                                    
                                    echo "<tr>
                                            <td>{$date} {$time}</td>
                                            <td>{$medicine_name} - {$detail}</td>
                                            <td>". ($count == 'success' ? 'สำเร็จ' : 'ไม่สำเร็จ') ."</td>
                                        </tr>";
                                }
                                echo "<tr>
                                <td rowspan='2' colspan='2' style='text-align: center; vertical-align: middle; font-weight: bold;'>สรุปผลการจ่ายยา</td>
                                <td >สำเร็จ : {$Success['total_success']}</td>
                            </tr>
                            <tr>
                                <td >ไม่สำเร็จ : {$Fail['total_fail']}</td>
                            </tr>";
                            } else {
                                echo "<tr><td colspan='3'>ไม่มีประวัติการจ่ายยา</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>

                    <!-- การสร้างปุ่มนำทาง (ก่อนหน้า/ถัดไป) -->
                    <nav>
                        <ul class="pagination justify-content-center">
                            <?php
                            // ปุ่ม "ก่อนหน้า"
                            if ($page > 1) {
                                $prev_page = $page - 1;
                                echo "<li class='page-item'>
                                        <a class='page-link' href='?page={$prev_page}&items_per_page={$items_per_page}'>ก่อนหน้า</a>
                                    </li>";
                            }

                            // แสดงเลขหน้า
                            for ($i = 1; $i <= $total_pages; $i++) {
                                $active = ($i == $page) ? "active" : "";
                                echo "<li class='page-item {$active}'>
                                        <a class='page-link' href='?page={$i}&items_per_page={$items_per_page}'>{$i}</a>
                                    </li>";
                            }

                            // ปุ่ม "ถัดไป"
                            if ($page < $total_pages) {
                                $next_page = $page + 1;
                                echo "<li class='page-item'>
                                        <a class='page-link' href='?page={$next_page}&items_per_page={$items_per_page}'>ถัดไป</a>
                                    </li>";
                            }
                            ?>
                        </ul>
                    </nav>
            </div>
            <script>
                function updateItemsPerPage() {
            const itemsPerPage = document.getElementById('itemsPerPageSelect').value;
            const currentPage = <?php echo $page; ?>; // ค่าเพจปัจจุบันจาก PHP
            window.location.href = `?items_per_page=${itemsPerPage}&page=${currentPage}`;
        }
        function printTable() {
            // เปิดหน้าสำหรับพิมพ์
            var printWindow = window.open('userprint.php', '_blank');
            
            // รอให้หน้าโหลดเสร็จแล้วค่อยสั่งพิมพ์
            printWindow.onload = function() {
                    printWindow.print();
                    printWindow.onafterprint = function() {
                    printWindow.close();
                };
                };
        }
</script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
