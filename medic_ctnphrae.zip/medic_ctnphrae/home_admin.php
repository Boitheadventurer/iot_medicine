<!doctype html>
<html lang="en">

<head>
    <title>เครื่องจ่ายยาอัตโนมัติ</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        body {
            background-color: #e0e0e0;
        }

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .inf {
            margin: 0 0 0 10%;
        }

        .indeximage {
            width: 100%;
            min-width: 250px;
            max-width: 550px;
        }

        .card {
            width: 100%;
            min-width: 250px;
            max-width: 450px;
            margin: 0 auto;
            float: none;
        }

        @media only screen and (max-width: 1000px) {
            .indeximage {
                display: block;
                width: 100%;
                margin: 0 auto;
            }

            .mainsection .row {
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .inf {
                margin: 5% 0;
            }
        }

        @media only screen and (max-width: 560px) {
            .card {
                width: 100%;
                margin: auto;
                align-items: center;
                text-align: center;
            }
        }
    </style>
</head>

<body>
    <?php
    include 'php/chk_id.php';
    include 'php/navbar_admin.php';
    ?>
    <!-- Banner Title -->
    <div class="mainsection text-light bg-dark p-4">
        <div class="row align-items-center">
            <div class="col">
                <div class="inf">
                    <h1 class="font-weight-bold display-4">เครื่องจ่ายยาอัตโนมัติ</h1>
                    <p>
                        โปรเจกต์เครื่องจ่ายยาอัตโนมัติจัดทำขั้นมาเพื่ออำนวยความสะดวกแก่ผู้ที่รับประทานยาประจำหรือคนที่มีโรคประจำตัว ทำให้ให้การรับประทานยาสะดวกมากขั้นด้วยการให้ยาตามเวลาที่กำหนดโดยจะมีการแจ้งเตือนตามการทำงาน
                    </p>
                    <a hidden href="pdf/คู่มือเครื่องจ่ายยา.pdf" type="button" class="btn btn-light shadow" download><i class="ri-info-i"></i> รายละเอียด</a>
                    <a hidden href="https://www.youtube.com/watch?v=yIoUpd4DK3M" target="_blank" type="button" class="btn btn-outline-light shadow"><i class="ri-play-fill"></i> วิธีการใช้งาน</a>
                </div>
            </div>
            <div class="col text-center">
                <img src="image/pill.jpg" alt="โมเดลออกแบบเครื่องจ่ายยา" class="indeximage img-fluid rounded shadow-lg">
            </div>
        </div>
    </div>

    <?php include "./php/conn.php";



    ?>
    <div class="container my-5 shadow p-4 rounded bg-white">
        <h2 class="text-center">รายงานข้อมูลผู้ใช้เครื่อง</h1>
            <div class="table-responsive">
                <table class="table table-striped table-bordered text-center ggtable">
                    <thead>
                        <tr>
                            <th scope="col">ลำดับ</th>
                            <th scope="col" class="w-25">ผู้ใช้งาน</th>
                            <th scope="col" class="w-25">Username - Password</th>
                            <th scope="col" class="w-25">สร้างบัญชีเมื่อ</th>
                            <th scope="col" class="w-25">รายละเอียด</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 0;
                        foreach ($conn->query("SELECT * FROM `tb_device` INNER JOIN user ON tb_device.id = user.id") as $z) { ?>
                            <tr>
                                <td>
                                    CTN<?php echo $z["device_id"]; ?>
                                </td>
                                <td>
                                    <?php echo $z["firstname"] . " " . $z["lastname"]; ?><br>
                                    เบอร์โทร : <?php echo $z["device_detail"]; ?>
                                </td>
                                <td>
                                    Username : <?php echo $z["email"]; ?><br>
                                    Password : <?php echo $z["password"]; ?><br>
                                </td>
                                <td>
                                    <?php 
                                        $date = new DateTime($z["created_at"]);
                                        $th_year = $date->format('Y') + 543;

                                        // อาร์เรย์เดือนภาษาไทย
                                        $th_months = [
                                            1 => "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", 
                                            "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
                                        ];

                                        // ดึงวัน, เดือน, ปี
                                        $day = $date->format('d');
                                        $month = $th_months[(int)$date->format('m')];
                                        $time = $date->format('H:i:s'); // ดึงเวลา ชั่วโมง:นาที:วินาที

                                        // แสดงผล วันที่ เดือน ปี และเวลา
                                        echo $day . " " . $month . " " . $th_year . " <br> " . $time . " น.";
                                    ?>
                                </td>
                                <td>
                                    <!-- ปุ่มสำหรับดูรายละเอียด -->
                                    <a href="detial.php?id=<?php echo $z['id']; ?>" class="btn btn-primary btn-sm">
                                        รายละเอียด
                                    </a>
                                    <!-- ปุ่มใหม่สำหรับไปยังหน้าถัดไป -->
                                    <a href="admin_report.php?id=<?php echo $z['id']; ?>" class="btn btn-info btn-sm">
                                        พิมพ์
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>

            </div>
    </div>






    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>