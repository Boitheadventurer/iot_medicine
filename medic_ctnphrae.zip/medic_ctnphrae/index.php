<!doctype html>
<html lang="en">
    <head>
        <title>เครื่องจ่ายยาอัตโนมัติ</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> 
        <!-- Remix Icon -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
        <!-- Icon Title -->
        <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
            *{
                margin: 0;
                padding: 0;
                font-family: "Bai Jamjuree", sans-serif;
            }
            .mainsection{
                background: linear-gradient(135deg, #f0f4f7, #e0e8ed);
                padding: 50px 0;
            }
            .inf{
                margin: 0 0 0 10%;
            }
            .indeximage{
                width: 100%;
                min-width: 250px;
                max-width: 550px;
                border-radius: 15px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            .btn-custom{
                transition: transform 0.3s ease;
            }
            .btn-custom:hover{
                transform: scale(1.1);
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            }
            @media only screen and (max-width: 1000px){
                .indeximage{
                    display: block;
                    width: 100%;
                    margin: 0 auto;
                }
                .mainsection .row {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    text-align: center;
                }
                .inf {
                    margin: 5% 0;
                }
            }

            /* Style for Footer */
    .footer {
        background-color: #2C3E50;
        color: white;
        padding: 40px 0; /* เพิ่มการเว้นระยะด้านบนและล่าง */
        text-align: center;
        font-size: 1.2rem; /* เพิ่มขนาดฟอนต์ */
    }
    .footer p {
        margin: 10px 0; /* เพิ่มระยะห่างระหว่างบรรทัด */
    }
    .footer a {
        color: white;
        text-decoration: none;
        margin: 0 15px; /* เพิ่มระยะห่างระหว่างลิงก์ */
        font-size: 1.2rem; /* เพิ่มขนาดฟอนต์ของลิงก์ */
    }
    .footer a:hover {
        text-decoration: underline;
    }

    /* ทำให้ footer อยู่ล่างสุด */
    html, body {
        height: 100%;
        margin: 0;
        display: flex;
        flex-direction: column;
    }

    .mainsection {
        flex: 1; /* ทำให้เนื้อหาหลักขยายเต็มพื้นที่ */
    }
        </style>
    </head>
    <body>

        <!-- Nav bar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <h2 class="navbar-brand pl-2">เครื่องจ่ายยา<span class="text-danger">อัตโนมัติ</span></h2>
                <div class="d-flex">
                    <a href="login.php" class="btn btn-outline-danger mr-1 btn-custom" type="button">เข้าสู่ระบบ</a>
                    <a href="signup.php" class="btn btn-danger btn-custom" type="button" hidden>สมัครเข้าใช้งาน</a>
                </div>
            </div>
        </nav>

        <div class="mainsection p-4">
            <div class="row align-items-center">
                <div class="col">
                    <div class="inf">
                        <h1 class="font-weight-bold display-4">เครื่องจ่ายยา<span class="text-danger">อัตโนมัติ</span></h1>
                        <h4 class="font-weight-bold">By CTN Phrae</h4>
                        <p>
                        แผนกเทคนิคคอมพิวเตอร์ วิทยาลัยเทคนิคแพร่ <br>ตั้งอยู่เลขที่ 5 ถนนเหมืองหิต ตำบลในเวียง อำเภอเมืองแพร่ จังหวัดแพร่ รหัสไปรษณีย์ 54000 <br>
                        </p>
                        <a hidden href="pdf/คู่มือเครื่องจ่ายยา.pdf" type="button" class="btn btn-danger shadow btn-custom" download><i class="ri-info-i"></i> รายละเอียด</a>
                        <a hidden href="https://www.youtube.com/watch?v=yIoUpd4DK3M" target="_blank" type="button" class="btn btn-outline-danger shadow btn-custom"><i class="ri-play-fill"></i> วิธีการใช้งาน</a>
                    </div>
                </div>
                <div class="col text-center">
                    <img src="image/d5.png" alt="โมเดลออกแบบเครื่องจ่ายยา" class="indeximage img-fluid rounded shadow-lg">
                </div>
            </div>
        </div>

        <!-- Footer Section -->
        <div class="footer">
            <p>&copy; 2024 เครื่องจ่ายยาอัตโนมัติ | วิทยาลัยเทคนิคแพร่ แผนกเทคนิคคอมพิวเตอร์</p>
            <p>
                <a href="http://ctnphrae.com/">แผนกเทคนิคคอมพิวเตอร์</a>
                |
                <a href="pdf/คู่มือเครื่องจ่ายยา.pdf">ข้อกำหนดการใช้งาน</a>
                |
                <a href="https://www.facebook.com/ctnphrae10">ติดต่อเรา</a>
            </p>
        </div>

        <!-- Optional JavaScript -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
</html>
