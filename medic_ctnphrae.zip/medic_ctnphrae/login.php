<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>เครื่องจ่ายยาอัตโนมัติ</title>
    <!-- Required meta tags -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            font-family: 'Bai Jamjuree', sans-serif;
        }

        body {
            background-color: #f3f4f6;
        }
    </style>
</head>
<body class="bg-gray-100">

    <!-- Container -->
    <div class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-md bg-white p-8 rounded-lg shadow-lg">

            <!-- Logo -->
            <div class="text-center mb-6">
            <img src="image/AI.png" alt="Logo" class="mx-auto" width="100px">
            </div>

            <!-- Heading -->
            <h3 class="text-2xl font-semibold text-center text-gray-700 mb-6">เข้าสู่ระบบ</h3>

            <!-- Login Form -->
            <form method="POST" action="php/chk_login.php">

                <!-- Phone Number -->
                <div class="mb-4">
                    <label for="tel" class="block text-gray-600 font-medium">เบอร์โทรหรืออีเมล</label>
                    <input type="text" class="form-control w-full p-2 border border-gray-300 rounded mt-1" name="tel" required>
                </div>

                <!-- Password -->
                <div class="mb-4">
                    <label for="pasword" class="block text-gray-600 font-medium">รหัสผ่าน</label>
                    <input type="password" class="form-control w-full p-2 border border-gray-300 rounded mt-1" name="pasword" required>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full bg-blue-500 hover:bg-blue-700 text-white py-2 px-4 rounded focus:outline-none focus:shadow-outline">เข้าสู่ระบบ</button>
            </form>

            <!-- Back Button -->
            <div class="mt-4 text-center">
                <a href="index.php" class="text-blue-500 hover:underline text-sm">
                    <i class="ri-arrow-go-back-fill"></i> ย้อนกลับ
                </a>
            </div>

        </div>
    </div>

    <!-- Optional JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>

</body>
</html>
