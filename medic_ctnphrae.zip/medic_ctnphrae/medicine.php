<!doctype html>
<html lang="en">

<head>
    <title>เครื่องจ่ายยาอัตโนมัติ</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        body {
            background-color: #e0e0e0;
        }

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: white;
            max-width: 800px;
            width: 90%;
        }

        .ggtable {
            min-width: 250px;
        }
    </style>

</head>

<body>
    <?php
    include 'php/chk_id.php';
    include 'php/navbar.php';
    ?>

    <!-- Insert Medicine -->
    <?php
    if (isset($_GET['medicine_id'])) {
        $medicine_id = $_GET['medicine_id'];

        $sql = "DELETE FROM tb_medicine WHERE medicine_id = '$medicine_id'";
        $conn->query($sql);
        echo "<script>window.location.href='medicine.php';</script>";
        exit();
    }
    ?>
    <div class="container my-5 shadow p-4 rounded bg-white">
        <h2 class="text-center font-bold text-lg mb-4">
            ตารางข้อมูลยา
            <br>
            <button type="button" class="btn btn-success shadow-sm my-3" data-toggle="modal" data-target="#medicine">
                <i class="ri-play-fill"></i> เพิ่มข้อมูลยา
            </button>
        </h2>
        <div class="table-responsive">
        <table class="table table-hover table-bordered text-center align-middle shadow-sm rounded ggtable">
            <thead class="table-success">
                <tr>
                    <th scope="col" class="w-75">ชื่อยา</th>
                    <th scope="col" class="w-25" hidden>ประเภทการทานยา</th>
                    <th scope="col" class="w-25">การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($conn->query("SELECT * FROM tb_medicine WHERE id = $id") as $z) { ?>
                    <tr>
                        <td>
                            <?php echo $z['medicine_name']; ?>
                        </td>
                        <td hidden>
                            <select class="form-control" name="medicine_detail" onchange="updatemedicine_detail(this, <?php echo $z['medicine_id']; ?>)">
                                <option value="ก่อนอาหาร" <?php echo ($z['medicine_detail'] == 'ก่อนอาหาร') ? 'selected' : ''; ?>>ก่อนอาหาร</option>
                                <option value="หลังอาหาร" <?php echo ($z['medicine_detail'] == 'หลังอาหาร') ? 'selected' : ''; ?>>หลังอาหาร</option>
                            </select>
                        </td>
                        <td>
                            <a href="?id=<?php echo $id; ?>&medicine_id=<?php echo $z['medicine_id']; ?>"
                            class="btn btn-danger btn-sm"
                            onclick="return confirm('คุณต้องการลบข้อมูลยา <?php echo $z['medicine_name']; ?> หรือไม่?');">
                            <i class="ri-delete-bin-line"></i> ลบ
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        </div>
    </div>


    <!-- Modal Insert Medicine -->
    <div class="modal fade" id="medicine" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">จัดการ เพิ่มข้อมูลยา</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="php/chk_medicine.php">

                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="พาราเซตามอล" id="paracetamol">
                            <label class="form-check-label" for="paracetamol">พาราเซตามอล (Paracetamol)</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยารักษาโรคความดันโลหิตสูง" id="amlodipine">
                            <label class="form-check-label" for="amlodipine">
                                แอมโลดิพีน (Amlodipine) - ยารักษาโรคความดันโลหิตสูง
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยารักษาโรคเบาหวาน" id="metformin">
                            <label class="form-check-label" for="metformin">
                                เมตฟอร์มิน (Metformin) - ยารักษาโรคเบาหวาน
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาลดไขมันในเลือด" id="atorvastatin">
                            <label class="form-check-label" for="atorvastatin">
                                อะทอร์วาสแตติน (Atorvastatin) - ยาลดไขมันในเลือด
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาละลายลิ่มเลือด" id="aspirin">
                            <label class="form-check-label" for="aspirin">
                                แอสไพริน (Aspirin) - ยาละลายลิ่มเลือด
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาลดกรดในกระเพาะอาหาร" id="omeprazole">
                            <label class="form-check-label" for="omeprazole">
                                โอเมพราโซล (Omeprazole) - ยาลดกรดในกระเพาะอาหาร
                            </label>
                        </div>

                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="น้ำเกลือแร่" id="saline">
                            <label class="form-check-label" for="saline">
                                น้ำเกลือแร่ (Saline Solution) - ใช้บรรเทาอาการขาดน้ำ
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาฆ่าเชื้อ" id="antiseptic">
                            <label class="form-check-label" for="antiseptic">
                                ยาฆ่าเชื้อ (Antiseptic) - ใช้ล้างแผล
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาแก้ท้องเสีย" id="charcoal">
                            <label class="form-check-label" for="charcoal">
                                ยาแก้ท้องเสีย (Activated Charcoal)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาแก้ไอ" id="cough_syrup">
                            <label class="form-check-label" for="cough_syrup">
                                ยาแก้ไอ (Cough Syrup)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาแก้ปวดข้อ" id="naproxen">
                            <label class="form-check-label" for="naproxen">นาพรอกเซน (Naproxen) - ยาแก้ปวดข้อ</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาลดน้ำตาลในเลือด" id="glipizide">
                            <label class="form-check-label" for="glipizide">กลิพิไซด์ (Glipizide) - ยาลดน้ำตาลในเลือด</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="ยาบำรุงหัวใจ" id="digoxin">
                            <label class="form-check-label" for="digoxin">ดิจอกซิน (Digoxin) - ยาบำรุงหัวใจ</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="mname[]" value="วิตามินรวม" id="multivitamins">
                            <label class="form-check-label" for="multivitamins">วิตามินรวม (Multivitamins)</label>
                        </div>


                        <div id="medicine-container">
                            <h6 class="mt-3">อื่นๆ</h6>
                            <div class="mb-3 d-flex">
                                <input type="text" class="form-control" name="mname[]" placeholder="กรอกชื่อยา">
                                <button type="button" class="btn btn-success btn-sm" onclick="addMedicine()">+</button>
                            </div>
                        </div>
                        <input type="text" class="form-control" hidden name="medicine_detail" value="ก่อนอาหาร">


                        <button type="submit" class="btn btn-success">ยืนยัน เพิ่มข้อมูลยา</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- JavaScript สำหรับเพิ่ม/ลบ ช่องกรอกชื่อยา -->
    <script>
        function updatemedicine_detail(selectElement, medicineId) {
            const medicine_detail = selectElement.value; // ค่าที่เลือกใน selectbox

            // ส่งข้อมูลไปยังไฟล์ PHP โดยใช้ Fetch API
            fetch('php/update_medicine.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `medicine_id=${medicineId}&medicine_detail=${medicine_detail}`
                })
                .then(response => response.text())
                .then(data => {
                    console.log(data); // แสดงข้อความจาก PHP (ใช้สำหรับ debug)
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('เกิดข้อผิดพลาดในการอัปเดตข้อมูล');
                });
        }


        function addMedicine() {
            const container = document.getElementById("medicine-container");

            // สร้าง Row ใหม่
            const div = document.createElement("div");
            div.className = "mb-3 d-flex align-items-center";

            // Input ชื่อยา
            const input = document.createElement("input");
            input.type = "text";
            input.name = "mname[]";
            input.className = "form-control me-2";
            input.placeholder = "กรอกชื่อยา";
            input.required = true;

            // ปุ่มลบ
            const btnRemove = document.createElement("button");
            btnRemove.type = "button";
            btnRemove.className = "btn btn-danger btn-sm";
            btnRemove.innerText = "−";
            btnRemove.onclick = () => container.removeChild(div);

            // ใส่ Input และปุ่มลบใน Row
            div.appendChild(input);
            div.appendChild(btnRemove);

            // เพิ่ม Row ใหม่ลงใน Container
            container.appendChild(div);
        }
    </script>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>