<?php
session_start(); // เริ่มต้น session เพื่อใช้งาน session variable
include 'conn.php'; 
?>

<title>เครื่องจ่ายยาอัตโนมัติ</title>

<?php
if (isset($_POST["tel"]) && isset($_POST["pasword"])) {
    $tel = $_POST["tel"];
    $password = $_POST["pasword"];

    // ป้องกัน SQL Injection ด้วยการใช้ Prepared Statements
    $sql = "SELECT * FROM user WHERE email = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $tel, $password); // "ss" หมายถึงค่า string 2 ตัว
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // ตั้งค่า session เมื่อล็อคอินสำเร็จ
        $_SESSION['id'] = $row['id'];

        // ตรวจสอบบทบาทของผู้ใช้
        if ($row['urole'] == "user") {
            // ผู้ใช้ทั่วไป
            echo "<script>window.location.href='../home.php';</script>";
        } else if ($row['urole'] == "keeper") {
            // ผู้ดูแล
            echo "<script>window.location.href='../home_admin.php';</script>";
        }
    } else {
        // หากไม่พบข้อมูลผู้ใช้
        echo "<script>window.location.href='../index.php'; alert('เบอร์โทร หรือรหัสผ่านไม่ถูกต้อง!');</script>";
    }

    $stmt->close(); // ปิดคำสั่ง SQL
}
?>
