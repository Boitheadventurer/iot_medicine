<?php
include 'chk_id.php';

$search = "SELECT * FROM tb_device LEFT JOIN user ON user.id = tb_device.id WHERE tb_device.id = '$id'";
$result = $conn->query($search);
$row = $result->fetch_assoc();
$did = $row['device_id'];

if (isset($_POST["mname"])) {
    $medicine_names = $_POST['mname']; 
    $medicine_detail = $_POST['medicine_detail']; 

    foreach ($medicine_names as $medicine_name) {
        // ตรวจสอบว่าเป็นค่าว่างหรือไม่
        $medicine_name = trim($medicine_name); // ลบช่องว่างที่ไม่จำเป็น
        if (empty($medicine_name)) {
            continue; // ข้ามข้อมูลที่เป็นค่าว่าง
        }

        // ป้องกัน SQL injection
        $medicine_name = mysqli_real_escape_string($conn, $medicine_name);
        $medicine_detail_safe = mysqli_real_escape_string($conn, $medicine_detail);

        // สร้างคำสั่ง SQL เพื่อบันทึกข้อมูล
        $sql = "INSERT INTO tb_medicine (medicine_name, medicine_detail, id, device_id)
                VALUES ('$medicine_name', '$medicine_detail_safe', '$id', '$did')";

        // ตรวจสอบว่า SQL ทำงานสำเร็จหรือไม่
        if (!mysqli_query($conn, $sql)) {
            echo "<script>alert('บันทึกข้อมูลยา ล้มเหลว: {$medicine_name}'); window.location.href='../home.php';</script>";
            exit; 
        }
    }

    // หากบันทึกสำเร็จทุกตัว
    echo "<script>alert('บันทึกข้อมูลสำเร็จ'); window.location.href='../medicine.php';</script>";
} else {
    echo "<script>alert('ไม่พบข้อมูลยา'); window.location.href='../home.php';</script>";
}
?>
