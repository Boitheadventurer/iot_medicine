<?php
    include 'conn.php';

    // รับค่าจากฟอร์ม
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $first_name_th = $_POST['first_name_th'];
    $last_name_th = $_POST['last_name_th'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $postal_code = $_POST['postal_code'];
    $chronic_disease = $_POST['chronic_disease'];
    $caretaker_name = $_POST['caretaker_name'];
    $caretaker_phone = $_POST['caretaker_phone'];
    $line_id = $_POST['line_id'];
    $pressure = $_POST['pressure'];
    $allergy = $_POST['allergy'];
    $yearold= $_POST['yearold'];
    $telid= $_POST['tel-id'];
    $telkey= $_POST['tel-key'];
    $alert= $_POST['alert'];
    $alert_type= $_POST['alert_type'];
    $selectedValue = isset($_POST['select']) ? $_POST['select'] : null;
    $alert= isset($_POST['alert']) ? $_POST['alert'] : null;
    // รับข้อมูลจากฟอร์ม
    $medicine_time_meal1 = $_POST['medicine_time_meal1'];
    $medicine_list_meal1 = isset($_POST['medicine_list_meal1']) ? implode(", ", $_POST['medicine_list_meal1']) : '';

    $medicine_time_meal2 = $_POST['medicine_time_meal2'];
    $medicine_list_meal2 = isset($_POST['medicine_list_meal2']) ? implode(", ", $_POST['medicine_list_meal2']) : '';


    $medicine_time_meal3 = $_POST['medicine_time_meal3'];
    $medicine_list_meal3 = isset($_POST['medicine_list_meal3']) ? implode(", ", $_POST['medicine_list_meal3']) : '';
    

    $medicine_time_meal4 = $_POST['medicine_time_meal4'];
    $medicine_list_meal4 = isset($_POST['medicine_list_meal4']) ? implode(", ", $_POST['medicine_list_meal4']) : '';

    $qrcodeMachineText = $_POST['qrcodeMachineText'];
    $telText = $_POST['telText'];

    // รับค่าจากฟอร์ม
    $user_login = $_POST['user_login'];
    $password = $_POST['password'];

    // เริ่มการทำงานของ Transaction
    $conn->begin_transaction();

    try {
        // สร้างคำสั่ง SQL เพื่อลงข้อมูลในตาราง user
        $sql_userdata = "INSERT INTO user (firstname, lastname, firstname_th, lastname_th, dob, gender, phone, address, postal_code, chronic_disease, caretaker_name, caretaker_phone, line_id, email, password, urole, user_detail, pressure, allergy,yearold,alert,alert_type)
        VALUES ('$first_name', '$last_name', '$first_name_th', '$last_name_th', '$dob', '$gender', '$phone', '$address', '$postal_code', '$chronic_disease', '$caretaker_name', '$caretaker_phone', '$line_id', '$user_login', '$password', 'user', '$chronic_disease','$pressure', '$allergy','$yearold', '$alert','$alert_type')";

        if ($conn->query($sql_userdata) !== TRUE) {
            throw new Exception("Error inserting into user: " . $conn->error);
        }

        // ดึง user_id ที่เพิ่งเพิ่มเข้ามา
        $user_id = $conn->insert_id;

        // เพิ่มข้อมูลในตาราง tb_device
        $sql_device = "INSERT INTO tb_device (id,device_detail,url1,url2,telegram_id,telegram_key,modesend,mode_sound,mode_setting) VALUES ('$user_id', '$phone', '$qrcodeMachineText','$telText', '$telid', '$telkey','$selectedValue',0,'$alert')";
        if ($conn->query($sql_device) !== TRUE) {
            throw new Exception("Error inserting into tb_device: " . $conn->error);
        }

        // ดึง device_id ที่เพิ่งเพิ่มเข้ามา
        $device_id = $conn->insert_id;

        // ตรวจสอบและเพิ่มข้อมูลใน tb_medicine หากมีค่า
        $medicine_values = [];   

        if (!empty($medicine_list_meal1) && !empty($medicine_time_meal1)) {
            $medicine_values[] = "('$user_id', '$device_id',  '$medicine_list_meal1', 'ก่อนอาหาร')";
        }
        if (!empty($medicine_list_meal2) && !empty($medicine_time_meal2)) {
            $medicine_values[] = "('$user_id', '$device_id',  '$medicine_list_meal2', 'ก่อนอาหาร')";
        }
        if (!empty($medicine_list_meal3) && !empty($medicine_time_meal3)) {
            $medicine_values[] = "('$user_id', '$device_id',  '$medicine_list_meal3', 'ก่อนอาหาร')";
        }
        if (!empty($medicine_list_meal4) && !empty($medicine_time_meal4)) {
            $medicine_values[] = "('$user_id', '$device_id',  '$medicine_list_meal4', 'ก่อนอาหาร')";
        }

        if (!empty($medicine_values)) {
            $sql_medicine = "INSERT INTO tb_medicine (id, device_id, medicine_name, medicine_detail) VALUES " . implode(", ", $medicine_values);
            if ($conn->query($sql_medicine) !== TRUE) {
                throw new Exception("Error inserting into tb_medicine: " . $conn->error);
            }
        }

        // ตรวจสอบและเพิ่มข้อมูลใน tb_data_bf หากมีค่า
        if (!empty($medicine_time_meal1)) {
            $sql_bf = "INSERT INTO tb_data_bf (id, device_id, time_bf, status_alert) VALUES ('$user_id', '$device_id', '$medicine_time_meal1', 'ON')";
            if ($conn->query($sql_bf) !== TRUE) {
                throw new Exception("Error inserting into tb_data_bf: " . $conn->error);
            }
        }

        // ตรวจสอบและเพิ่มข้อมูลใน tb_data_lunch หากมีค่า
        if (!empty($medicine_time_meal2)) {
            $sql_lunch = "INSERT INTO tb_data_lunch (id, device_id, time_lunch, status_alert) VALUES ('$user_id', '$device_id', '$medicine_time_meal2', 'ON')";
            if ($conn->query($sql_lunch) !== TRUE) {
                throw new Exception("Error inserting into tb_data_lunch: " . $conn->error);
            }
        }

        // ตรวจสอบและเพิ่มข้อมูลใน tb_data_dn หากมีค่า
        if (!empty($medicine_time_meal3)) {
            $sql_dn = "INSERT INTO tb_data_dn (id, device_id, time_dn, status_alert) VALUES ('$user_id', '$device_id', '$medicine_time_meal3', 'ON')";
            if ($conn->query($sql_dn) !== TRUE) {
                throw new Exception("Error inserting into tb_data_dn: " . $conn->error);
            }
        }

        // ตรวจสอบและเพิ่มข้อมูลใน tb_data_bb หากมีค่า
        if (!empty($medicine_time_meal4)) {
            $sql_bb = "INSERT INTO tb_data_bb (id, device_id, time_bb, status_alert) VALUES ('$user_id', '$device_id', '$medicine_time_meal4', 'ON')";
            if ($conn->query($sql_bb) !== TRUE) {
                throw new Exception("Error inserting into tb_data_bb: " . $conn->error);
            }
        }

        // คอมมิตการทำงานทั้งหมด
        $conn->commit();
        echo "บันทึกข้อมูลสำเร็จ!";
        header("Location: ../login.php");  // เพิ่มบรรทัดนี้เพื่อกลับไปที่หน้า login.php
        exit();  // คำสั่ง exit() จะหยุดการทำงานของสคริปต์หลังจาก header()
    } catch (Exception $e) {
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }

    // ปิดการเชื่อมต่อฐานข้อมูล
    $conn->close();
?>
