<?php
    $servername = "localhost";
    $username = "ctnphrae_medic";
    $password = "ctnphrae_medic";
    $dbname = "ctnphrae_medic";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect());
    }
     session_start();
    error_reporting(0);
ini_set('display_errors', 0);

?>