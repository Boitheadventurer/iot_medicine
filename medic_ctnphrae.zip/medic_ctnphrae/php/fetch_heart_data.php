<?php
include 'conn.php';

$range = $_GET['range'];
$condition = "";

if ($range !== "all") {
    $days = intval($range);
    $condition = "WHERE date >= DATE_SUB(NOW(), INTERVAL $days DAY)";
}

$sql = "SELECT * FROM tb_heart $condition ORDER BY date DESC";
$result = $conn->query($sql);

$data = [
    'tableData' => [],
    'dates' => [],
    'systolic' => [],
    'diastolic' => [],
    'pulse' => []
];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data['tableData'][] = $row;
        $data['dates'][] = date('d/m/Y', strtotime($row['date']));
        $data['systolic'][] = $row['systolic_pressure'];
        $data['diastolic'][] = $row['diastolic_pressure'];
        $data['pulse'][] = $row['pulse_rate'];
    }
}

echo json_encode($data);
$conn->close();
?>
