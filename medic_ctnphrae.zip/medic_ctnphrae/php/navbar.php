<!-- Nav bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#"><?php echo $row['firstname_th'] . " " . $row['lastname_th']; ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>   
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item nn">
                <a class="nav-link text-dark" href="home.php"><i class="ri-home-4-line"></i> หน้าหลัก</a>
            </li>
            <li class="nav-item nn">
                <a class="nav-link text-dark" href="device.php"><i class="ri-hard-drive-2-line"></i> ข้อมูลเครื่อง</a>
            </li>
            <?php 
                // ตรวจสอบข้อมูลเครื่อง
                $sql = "SELECT * FROM tb_device LEFT JOIN user ON user.id = tb_device.id WHERE tb_device.id = '$id'";
                $result = $conn->query($sql);
                $row = $result->fetch_assoc();
                if ($row >= 1) { ?>
                    <li class="nav-item nn">
                        <a class="nav-link text-dark" href="medicine.php"><i class="ri-capsule-fill"></i> ข้อมูลยา</a>
                    </li>
                <?php } ?>
            <li class="nav-item nn">
                <a class="nav-link text-dark" href="fixtime.php"><i class="ri-pie-chart-2-fill"></i> กำหนดมื้อจ่ายยา</a>
            </li>
            <?php 
                // ตรวจสอบข้อมูลยา
                $sql = "SELECT * FROM tb_medicine LEFT JOIN user ON user.id = tb_medicine.id WHERE tb_medicine.id = '$id'";
                $result = $conn->query($sql);
                $row = $result->fetch_assoc();
                if ($row >= 1) { ?>
                    <li class="nav-item dropdown nn">
                        <a class="nav-link text-dark" href="set_medicine.php"><i class="ri-time-line"></i> ตั้งเวลาจ่ายยา</a> 
                    </li>
                <?php } ?>

            <li class="nav-item nn">
                <a class="nav-link text-dark" href="history.php"><i class="ri-calendar-todo-fill"></i> ประวัติการจ่ายยา</a>
            </li>

            <?php 
           
                if ($row['pressure'] == 1) { ?>
                    <li class="nav-item nn">
                        <a class="nav-link text-dark" href="heart_rate.php"><i class="ri-service-line"></i> ระดับความดัน</a>
                    </li>
                    <li class="nav-item nn">
                        <a class="nav-link text-dark" href="heart_report.php"><i class="ri-line-chart-line"></i> รายงานความดัน</a>
                    </li>
                <?php } ?>

            <li class="nav-item nn">
                <a href="php/logout.php" type="button" class="btn btn-danger"><i class="ri-logout-box-line"></i> ออกจากระบบ</a>
            </li>
        </ul>
    </div>
</nav>
