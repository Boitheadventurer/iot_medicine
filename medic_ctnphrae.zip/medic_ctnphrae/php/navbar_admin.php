<!-- Nav bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="#">ADMIN</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button>   
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">
    <li class="nav-item nn">
        <a class="nav-link text-dark" href="home_admin.php"><i class="ri-home-4-line"></i> หน้าหลัก</a>
    </li>
    <li class="nav-item nn mx-5">
    <a href="signup.php" class="btn btn-danger btn-custom" type="button">สมัครเข้าใช้งาน</a>
    </li>


    <li hidden class="nav-item nn">
        <a class="nav-link text-dark" href="#"><i class="ri-map-pin-user-fill"></i> ข้อมูลผู้ใช้ทั้งหมด</a>
        <!-- User Table -->
    </li>
    <li hidden class="nav-item nn">
        <a class="nav-link text-dark" href="#"><i class="ri-inbox-2-line"></i> ข้อมูลเครื่องทั้งหมด</a>
        <!-- Device Table -->
    </li>
    <li hidden class="nav-item nn">
        <a class="nav-link text-dark" href="#"><i class="ri-capsule-fill"></i> ข้อมูลยาทั้งหมด</a>
        <!-- Medicine Table -->
    </li>
    <li class="nav-item nn">
        <a href="php/logout.php" type="button" class="btn btn-danger"><i class="ri-logout-box-line"></i> ออกจากระบบ</a>
    </li>
    </ul>
</div>
</nav>