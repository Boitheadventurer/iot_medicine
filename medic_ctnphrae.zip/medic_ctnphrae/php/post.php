<?php
    include 'conn.php';

    // ตรวจสอบว่ามีการส่ง status ผ่าน GET หรือไม่
    $id = 21;
    $status = isset($_REQUEST['status']) ? $_REQUEST['status'] : 'unknown';

    // ดีบักค่า status ที่รับมา
    echo "Received status: " . $status . "<br>";

    // แสดงข้อความตามค่าของ status
    if ($status == 'online') {
        echo "ESP8266 is online.";
        $sql_upd = "UPDATE `tb_device` 
        SET `status_online`='online', `time_online`=NOW() 
        WHERE device_id = $id;";
        mysqli_query($conn, $sql_upd);
    
    } elseif ($status == 'offline') {
        $sql_upd = "UPDATE `tb_device` 
        SET `status_online`='offline's
        WHERE device_id = $id;";
        mysqli_query($conn, $sql_upd);
        echo "ESP8266 is offline.";
    } else {
        $sql = "SELECT * FROM `tb_device` WHERE device_id = $id;";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $db_time = $row["time_online"]; // ตัวอย่างข้อมูลเวลาจากฐานข้อมูล

        // สร้าง DateTime object จากเวลาจากฐานข้อมูล
        $db_date = new DateTime($db_time);

        // สร้าง DateTime object สำหรับเวลาปัจจุบัน
        $current_date = new DateTime();

        // หาความแตกต่างระหว่างเวลาในฐานข้อมูลกับเวลาปัจจุบัน
        $interval = $current_date->diff($db_date);

        // แปลงความแตกต่างเป็นวินาที
        $diff_in_seconds = $interval->s + ($interval->i * 60) + ($interval->h * 3600) + ($interval->d * 86400);

        // ถ้าความแตกต่างเป็น 30 วินาที
        if ($diff_in_seconds >= 10) {
            echo "offline";
            $sql_upd = "UPDATE `tb_device` 
            SET `status_online`='offline'
            WHERE device_id = $id;";
            mysqli_query($conn, $sql_upd);
        } else {
            echo "online";
        }
    }








    

    // Get values from ESP8266
    if (isset($_POST["UserID"]) && isset($_POST["meal"]) &&
        isset($_POST["medic_send1"]) && isset($_POST["medic_send2"]) &&
        isset($_POST["medic_send3"]) && isset($_POST["medic_send4"]) &&
        isset($_POST["status"]) && isset($_POST["Count_medicine"]) ) {

        $id     = $_POST["UserID"];                 // UserID
        $meal   = $_POST["meal"];                   // Meal for send data_tb
        $medic1 = $_POST["medic_send1"];
        $medic2 = $_POST["medic_send2"];
        $medic3 = $_POST["medic_send3"];
        $medic4 = $_POST["medic_send4"];
        $stt    = $_POST["status"];                 // Status take medicine
        $count_ = $_POST["Count_medicine"];
        
        if ($medic1 == 0) {
            $medic1 = "NULL";
        }
        if ($medic2 == 0) {
            $medic2 = "NULL";
        }
        if ($medic3 == 0) {
            $medic3 = "NULL";
        }
        if ($medic4 == 0) {
            $medic4 = "NULL";
        }

        // SQL INSERT data with dynamic field name
        $sql = "INSERT INTO tb_data_eat_medicine 
        (device_id, medicine_id, medicine_id2, medicine_id3, medicine_id4, 
        id, medicine_get, count_medicine) 
        VALUES ($id, $medic1, $medic2, $medic3, $medic4, 
        $id, '$stt', 1)";

        // Show response
        if (mysqli_query($conn, $sql)) {
            echo "\nUserID = " . $id . 
                "\nMeal = " . $did1 . 
                "\nStatus = " . $stt;
        } else { 
            echo "\nError: " . $sql . "<br>" . mysqli_error($conn); 
        }

        $sql_upd = "UPDATE tb_device SET count_medicine = $count_ WHERE id = $id";
        if (mysqli_query($conn, $sql_upd)) { 
            echo "\nUserID = " . $id . 
                 "\nCount_Medicine = " . $count_;
        } else { 
            echo "\nเกิดข้อผิดพลาด: " . $sql . "<br>" . mysqli_error($conn); 
        }
    }

    if (isset($_POST["UserID"]) && isset($_POST["Count_medicine"])) {
        $id    = $_POST["UserID"];
        $count = $_POST["Count_medicine"];
        $sql = "UPDATE tb_device SET count_medicine = $count WHERE id = $id";
        if (mysqli_query($conn, $sql)) { 
            echo "\nUserID = " . $id . 
                 "\nCount_Medicine = " . $count;
        } else { 
            echo "\nเกิดข้อผิดพลาด: " . $sql . "<br>" . mysqli_error($conn); 
        }
    }
?> 
