<?php
  include 'chk_id.php';

  $deleteQueries = [
        "DELETE FROM tb_data_bf WHERE id = '$id'",
        "DELETE FROM tb_data_lunch WHERE id = '$id'",
        "DELETE FROM tb_data_dn WHERE id = '$id'",
        "DELETE FROM tb_data_bb WHERE id = '$id'"
    ];

    foreach ($deleteQueries as $query) {
        if (!$conn->query($query)) {
            echo "เกิดข้อผิดพลาด: " . $conn->error;
        }
    }
  
  // ดึง device_id จากฐานข้อมูล
  $sql = "SELECT device_id FROM tb_device WHERE id = $id";
  $stmt = $conn->query($sql);
  $row =  $stmt->fetch_assoc();
  $device_id = $row['device_id'] ?? null;

 
  if (!$device_id) {
      echo "ไม่พบ device_id!";
      exit;
  }
  
  // ตรวจสอบว่ามีการส่งข้อมูลมาหรือไม่
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  
      // สร้าง array สำหรับเก็บข้อมูล
      $meal_times = [];
      $meal_periods = [];
      $medicines = [];
  
      // ดึงข้อมูลจาก POST และแยกเก็บเป็น array
      foreach ($_POST as $key => $value) {
        // echo $key;
        // echo $value;
          if (strpos($key, 'meal_time_') === 0) {
              $index = str_replace('meal_time_', '', $key);
            // print_r($index);
            // break;
              // เก็บข้อมูลใส่ array แยกกัน
              $meal_times[$index] = $_POST['meal_time_' . $index];
              $meal_periods[$index] = $_POST['meal_period_' . $index] ?? '';
              $medicines[$index] = [
                  $_POST['medicine' . '_1_' . $index ] ?? '',
                  $_POST['medicine' . '_2_' . $index ] ?? '',
                  $_POST['medicine' . '_3_' . $index ] ?? '',
                  $_POST['medicine' . '_4_' . $index ] ?? ''
              ];

            //   print_r($medicines);
          }
      }
  
      // Loop ข้อมูลที่เก็บมาและ INSERT ตามตารางที่เหมาะสม
      foreach ($meal_times as $index => $meal_time) {
        $meal_period = $meal_periods[$index];
        $medicine_ids = $medicines[$index];
        if ($meal_period === 'เช้า') {
            $table = 'tb_data_bf';
            $time_column = 'time_bf';
            $sql = " SELECT * FROM `tb_data_bf` WHERE id = $id; ";

            if ($result = mysqli_query($conn, $sql)) {
                $rowcount = mysqli_num_rows($result);
                if($rowcount >= 1){
                    $sql = "DELETE FROM `tb_data_bf` WHERE id = $id";
                    $stmt = $conn->query($sql);
                }
            } else {
                echo "Error: " . mysqli_error($con);
            }
        } elseif ($meal_period === 'กลางวัน') {
            $table = 'tb_data_lunch';
            $time_column = 'time_lunch';
            $sql = " SELECT * FROM `tb_data_lunch` WHERE id = $id; ";
            if ($result = mysqli_query($conn, $sql)) {
              $rowcount = mysqli_num_rows($result);
              if($rowcount >= 1){
                  $sql = "DELETE FROM `tb_data_lunch` WHERE id = $id";
                  $stmt = $conn->query($sql);
              }
          } else {
              echo "Error: " . mysqli_error($con);
          }

        } elseif ($meal_period === 'เย็น') {
            $table = 'tb_data_dn';
            $time_column = 'time_dn';
            $sql = " SELECT * FROM `tb_data_dn` WHERE id = $id; ";
            if ($result = mysqli_query($conn, $sql)) {
              $rowcount = mysqli_num_rows($result);
              if($rowcount >= 1){
                  $sql = "DELETE FROM `tb_data_dn` WHERE id = $id";
                  $stmt = $conn->query($sql);
              }
          } else {
              echo "Error: " . mysqli_error($con);
          }
        } elseif ($meal_period === 'ก่อนนอน') {
            $table = 'tb_data_bb';
            $time_column = 'time_bb';
            $sql = " SELECT * FROM `tb_data_bb` WHERE id = $id; ";
            if ($result = mysqli_query($conn, $sql)) {
              $rowcount = mysqli_num_rows($result);
              if($rowcount >= 1){
                  $sql = "DELETE FROM `tb_data_bb` WHERE id = $id";
                  $stmt = $conn->query($sql);
              }
          } else {
              echo "Error: " . mysqli_error($con);
          }
        } else {
            continue;
        }

        $sql = "INSERT INTO $table 
                ($time_column, medicine_id, medicine_id2, medicine_id3, medicine_id4, device_id, id) 
                VALUES ('$meal_time', $medicine_ids[0], $medicine_ids[1], $medicine_ids[2], $medicine_ids[3], $device_id, $id)";
        // เตรียม statement
        $stmt = $conn->query($sql);

        if ($stmt) {
          // $result = $stmt->fetch_assoc();
          echo "บันทึกข้อมูลเรียบร้อย!";
        } else {
            echo "เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . $conn->error;
        }
    }
 
     echo' <script>
            alert("บันทึกข้อมูลกำหนดเวลาจ่ายยา สำเร็จ!");
            window.location.href = "../total_medicine.php" ;
      </script>';
     
  } else {
      echo "ไม่มีข้อมูลที่ส่งมา!";
  }
  ?>
