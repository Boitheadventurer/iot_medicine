  <!--gemini-->
  <?php
    function Gemini($prompt)
    {
        $api_key = "AIzaSyBg-_YMe9T9tyau32USnJ92ziwAX15wj_c";
        $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={$api_key}";
        $data = array(
            "contents" => array(
                array(
                    "role" => "user",
                    "parts" => array(
                        array(
                            "text" => $prompt
                        )
                    )
                )
            )
        );
        $json_data = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        curl_close($ch);
        if (curl_errno($ch)) {
            return 'Curl error: ' . curl_error($ch);
        }
        return json_decode($response, true)["candidates"][0]["content"]["parts"][0]["text"];
    }

    include 'conn.php';


    // ตรวจสอบว่ามีการส่งข้อมูลจากฟอร์มหรือไม่
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // รับค่าจากฟอร์ม
        $systolic = $_POST['systolic_pressure'];
        $diastolic = $_POST['diastolic_pressure'];
        $pulse = $_POST['pulse_rate'];
        $id = $_POST['id'];
        $Genn = Gemini("นี่คือค่า ความดันสูง ความดันต่ำ เเละค่าชีพจร ตามลำดับ.$systolic .$diastolic .$pulse.ช่วยประเมินสุขภาพจากค่านี้เเละให้คำเเนะนำ");
        $Gen2 = str_replace("*", "", "$Genn");
        $Gen = preg_replace(["/\r/", "/\n/", "/<br\s*\/?>/i"], "", $Gen2);
        // เตรียมคำสั่ง SQL
        $stmt = $conn->prepare("INSERT INTO tb_heart (systolic_pressure, diastolic_pressure, pulse_rate ,heart_report ,id) VALUES (?, ?, ? ,? ,?)");
        $stmt->bind_param("iiisi", $systolic, $diastolic, $pulse, $Gen, $id);


        $firstname = htmlspecialchars($_POST['firstname']);
        $lastname = htmlspecialchars($_POST['lastname']);
        $systolicPressure = htmlspecialchars($_POST['systolic_pressure']);
        $diastolicPressure = htmlspecialchars($_POST['diastolic_pressure']);
        $pulseRate = htmlspecialchars($_POST['pulse_rate']);

        $message = "📊 รายงานสุขภาพ\n"
            . "👤 ชื่อผู้ใช้งาน: $firstname - $lastname\n"
            . "💓 ความดันสูง: $systolicPressure mmHg\n"
            . "💓 ความดันต่ำ: $diastolicPressure mmHg\n"
            . "💓 ชีพจร: $pulseRate bpm";


        $sql = "SELECT * 
        FROM tb_heart 
        LEFT JOIN user ON user.id = tb_heart.id 
        LEFT JOIN tb_device ON tb_device.id = user.id
        WHERE tb_heart.id = '$id' 
        ORDER BY date DESC";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        $token = $row['token_line'];
        $ck = $row['modesend'];
        //echo $ck;

        $token_tel = $row['telegram_key'];
        $id_tel = $row['telegram_id'];

        //echo $token_tel;
        //echo $id_tel;

        if ($ck == 1) {
            sendToTelegram($message, $token_tel, $id_tel);
        } else {
            sendToLine($message, $token);
        }

        // บันทึกข้อมูล
        if ($stmt->execute()) {
            echo "<script>
                alert('บันทึกข้อมูลสำเร็จ!');
                window.location.href = '../home.php?Gen=$id'; // เปลี่ยนเป็นหน้าที่คุณต้องการ
              </script>";
        } else {
            echo "<script>
                alert('เกิดข้อผิดพลาดในการบันทึกข้อมูล');
                window.history.back(); // ย้อนกลับไปที่ฟอร์ม
              </script>";
        }

        // ปิดการเชื่อมต่อ
        $stmt->close();
        $conn->close();
    } else {
        echo "<script>
            alert('ไม่อนุญาตให้เข้าถึงหน้านี้โดยตรง');
            window.location.href = 'index.php'; // เปลี่ยนเป็นหน้าที่คุณต้องการ
          </script>";
    }




    function sendToLine($message, $token_2)
    {
        $token = $token_2; // ใส่ Line Notify Token ของคุณ

        // ส่งข้อมูลไปยัง Line Notify
        $lineNotifyUrl = 'https://notify-api.line.me/api/notify';
        $headers = [
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Bearer ' . $token
        ];
        $data = http_build_query(['message' => $message]);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $lineNotifyUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        // ตรวจสอบผลลัพธ์การส่งข้อมูล
        if ($response) {
            echo "ข้อมูลถูกส่งไปยัง Line Notify แล้ว!";
        } else {
            echo "การส่งข้อมูลล้มเหลว!";
        }
    }
    // ฟังก์ชันส่งข้อความไปยัง Telegram
    function sendToTelegram($message, $token_tel, $id_tel)
    {
        $telegramToken = $token_tel;  // ใส่ Token ของ Telegram Bot
        $chatId =  $id_tel;  // ใส่ Chat ID ของผู้ใช้หรือกลุ่ม

        $telegramUrl = "https://api.telegram.org/bot$telegramToken/sendMessage";
        $data = [
            'chat_id' => $chatId,
            'text' => $message,
            'parse_mode' => 'HTML'  // ถ้าต้องการส่งข้อความในรูปแบบ HTML
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $telegramUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);
    }

    ?>