<?php
    include 'conn.php';

    // ดีบักข้อมูลที่ส่งมาจาก ESP8266
    // print_r($_REQUEST);
    isset($_GET['device']);
    //$a = $_GET['device'];
    $a = $_GET['device'];
    // $a = 3;
    $status = isset($_REQUEST['status']);
    
    // echo "Status: " . $status . "<br>";

    // แสดงข้อความตามค่าของ status
    if ($status == 'online') {
        echo "ESP8266 is online.";
        $sql_upd = "UPDATE `tb_device` 
        SET `status_online`='online', `time_online`=NOW() 
        WHERE id = $a;";
        mysqli_query($conn, $sql_upd);
    
    } elseif ($status == 'offline') {
        $sql_upd = "UPDATE `tb_device` 
        SET `status_online`='offline's
        WHERE id = $a;"; 
        mysqli_query($conn, $sql_upd);
        echo "ESP8266 is offline.";
    } else {
        $sql = "SELECT * FROM `tb_device` WHERE id = $a;";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $db_time = $row["time_online"]; // ตัวอย่างข้อมูลเวลาจากฐานข้อมูล

        // สร้าง DateTime object จากเวลาจากฐานข้อมูล
        $db_date = new DateTime($db_time);

        // สร้าง DateTime object สำหรับเวลาปัจจุบัน
        $current_date = new DateTime();

        // หาความแตกต่างระหว่างเวลาในฐานข้อมูลกับเวลาปัจจุบัน
        $interval = $current_date->diff($db_date);

        // แปลงความแตกต่างเป็นวินาที
        $diff_in_seconds = $interval->s + ($interval->i * 60) + ($interval->h * 3600) + ($interval->d * 86400);

        // ถ้าความแตกต่างเป็น 5 วินาที
        if ($diff_in_seconds >= 5) {
            // echo "offline";
            $sql_upd = "UPDATE `tb_device` 
            SET `status_online`='offline'
            WHERE id = $a;";
            mysqli_query($conn, $sql_upd);
        } else {
            // echo "online";
        }
    }

    // ดึงข้อมูลของอุปกรณ์จากฐานข้อมูล
    $sql = "SELECT * FROM `tb_device` WHERE id = $a;";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response = array(
            "status_online" => $row["status_online"]
        );
    } else {
        $response["error"] = "Device not found.";
    }
    // print_r($row["status_online"]);
    // echo "----------------";
    // ส่งข้อมูลในรูปแบบ JSON
    header('Content-Type: application/json');
    echo json_encode($response);
?>