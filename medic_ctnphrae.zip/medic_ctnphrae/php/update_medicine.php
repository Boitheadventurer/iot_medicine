<?php
include 'chk_id.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicine_id = mysqli_real_escape_string($conn, $_POST['medicine_id']);
    $medicine_detail = mysqli_real_escape_string($conn, $_POST['medicine_detail']);

    // อัปเดตข้อมูลใน tb_medicine
    $sql = "UPDATE tb_medicine SET medicine_detail = '$medicine_detail' WHERE medicine_id = '$medicine_id'";
    if ($conn->query($sql) === TRUE) {
        echo "อัปเดตประเภทการทานยาเรียบร้อยแล้ว";
    } else {
        echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูล: " . $conn->error;
    }
} else {
    echo "ไม่พบข้อมูลที่ส่งมา";
}
?>
