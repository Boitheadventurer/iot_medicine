<?php
include 'php/chk_id.php';
include 'php/navbar.php';

// เก็บข้อมูล meal_time และ meal_period ลงใน array
$meal_times = [];
$meal_periods = [];
foreach ($_GET as $key => $value) {
    if (strpos($key, 'meal_time_') === 0) {
        $index = str_replace('meal_time_', '', $key);
        $meal_times[$index] = $value;
    } elseif (strpos($key, 'meal_period_') === 0) {
        $index = str_replace('meal_period_', '', $key);
        $meal_periods[$index] = $value;
    }
}

// ดึงข้อมูลยาจากฐานข้อมูล
$medicines = [];
$sql = "SELECT medicine_id, medicine_name FROM tb_medicine WHERE id ='$id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $medicines[] = $row;
    }
}

// ดึงจำนวนมื้ออาหารจากฐานข้อมูล
$meal_count = 0;
if (!empty($id)) {
    $query = "SELECT meal_count FROM tb_device WHERE id = '$id'";
    $result = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_assoc($result)) {
        $meal_count = $row['meal_count'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>กำหนดยา</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg"><link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        body {
            background-color: #e0e0e0;
        }

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: #fff;
        }
    </style>
</head>

<body>
    <div class="container my-5 shadow p-4 rounded">
        <h2 class="text-center">กำหนดเวลาจ่ายยาในแต่ละมื้อ</h2>
        <form method="POST" action="php/process.php">
            <?php for ($index = 1; $index <= $meal_count; $index++): ?>
                <div class="row mb-3 align-items-center">
                    <!-- Time Input -->
                    <div class="col-md-2">
                        <label for="time_<?= $index ?>" class="form-label">เวลา</label>
                        <input
                            type="time"
                            class="form-control"
                            id="time_<?= $index ?>"
                            name="meal_time_<?= $index ?>"
                            value="<?= htmlspecialchars($meal_times[$index] ?? '') ?>"
                            required>
                    </div>

                    <!-- Time Range Input -->
                    <div class="col-md-2">
                        <label for="time_range_<?= $index ?>" class="form-label">ช่วงเวลา</label>
                        <select
                            class="form-control time-range-select"
                            id="time_range_<?= $index ?>"
                            name="meal_period_<?= $index ?>"
                            required>
                            <option value="">เลือกช่วงเวลา</option>
                            <option value="เช้า" <?= (isset($meal_periods[$index]) && $meal_periods[$index] === 'เช้า') ? 'selected' : '' ?>>เช้า</option>
                            <option value="กลางวัน" <?= (isset($meal_periods[$index]) && $meal_periods[$index] === 'กลางวัน') ? 'selected' : '' ?>>กลางวัน</option>
                            <option value="เย็น" <?= (isset($meal_periods[$index]) && $meal_periods[$index] === 'เย็น') ? 'selected' : '' ?>>เย็น</option>
                            <option value="ก่อนนอน" <?= (isset($meal_periods[$index]) && $meal_periods[$index] === 'ก่อนนอน') ? 'selected' : '' ?>>ก่อนนอน</option>
                        </select>
                    </div>

                    <!-- Medicines -->
                    <?php for ($medIndex = 1; $medIndex <= 4; $medIndex++): ?>
                        <div class="col-md-2">
                            <label for="medicine_<?= $medIndex ?>_<?= $index ?>" class="form-label">ยา <?= $medIndex ?></label>
                            <select
                                class="form-control"
                                id="medicine_<?= $medIndex ?>_<?= $index ?>"
                                name="medicine_<?= $medIndex ?>_<?= $index ?>">
                                <option value="NULL">-</option>
                                <?php foreach ($medicines as $medicine): ?>
                                    <option value="<?= $medicine['medicine_id'] ?>"><?= $medicine['medicine_name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endfor; ?>
                </div>
            <?php endfor; ?>

            <div class="my-3 text-center">
                <button id="saveButton" class="btn btn-primary" type="submit" name="submit">บันทึกข้อมูลกำหนดจ่ายยา</button>
            </div>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const selects = document.querySelectorAll('.time-range-select');

            // ฟังก์ชันอัปเดตตัวเลือกที่ disabled
            function updateDisabledOptions() {
                const selectedValues = new Set();

                // เก็บค่าที่เลือกทั้งหมด
                selects.forEach(select => {
                    const value = select.value;
                    if (value) selectedValues.add(value);
                });

                // อัปเดตตัวเลือกในแต่ละ select
                selects.forEach(select => {
                    const currentValue = select.value;
                    const options = select.querySelectorAll('option');

                    options.forEach(option => {
                        if (option.value && option.value !== currentValue) {
                            // disabled ถ้าค่านั้นถูกเลือกแล้วใน select อื่น
                            option.disabled = selectedValues.has(option.value);
                        } else {
                            option.disabled = false; // reset ตัวเลือกที่ไม่ซ้ำ
                        }
                    });
                });
            }

            // อัปเดตเมื่อมีการเปลี่ยนค่า
            selects.forEach(select => {
                select.addEventListener('change', updateDisabledOptions);
            });

            // เรียกใช้เมื่อโหลดหน้าเพื่ออัปเดตสถานะ disabled
            updateDisabledOptions();
        });
    </script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>