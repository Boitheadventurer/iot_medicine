<!DOCTYPE html>
<html lang="en">

<head>
    <title>เครื่องจ่ายยาอัตโนมัติ</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: white;
            max-width: 800px;
            width: 90%;
        }

        body {
            background-color: #f3f4f6;
        }
    </style>
</head>

<body>
    <div class="container my-5 rounded shadow">
        <!-- Logo -->
        <div class="text-center">
            <img src="image/AI.png" alt="เครื่องจ่ายยาอัตโนมัติ" class="mx-auto my-3" width="75px">
        </div>
        <h2 class="text-center mb-4">เครื่องจ่ายยา<br>สำหรับผู้สูงอายุ</h2>

        <form action="php/chk_signup.php" method="POST">
            <!-- ข้อมูลผู้ป่วย -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">ข้อมูลผู้ป่วย</div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>ชื่อจริง</label>
                            <input type="text" class="form-control" required name="first_name_th">
                        </div>
                        <div class="form-group col-md-6">
                            <label>นามสกุล</label>
                            <input type="text" class="form-control" required name="last_name_th">
                        </div>
                        <div class="form-group col-md-6" hidden>
                            <label>ชื่อจริง (ภาษาอังกฤษ)</label>
                            <input type="text" class="form-control" id="englishonly1" name="first_name" value="CTN">
                        </div>
                        <div class="form-group col-md-6" hidden>
                            <label>นามสกุล (ภาษาอังกฤษ)</label>
                            <input type="text" class="form-control" id="englishonly2" name="last_name" value="Medicine_IoT">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>วันเกิด</label>
                            <input type="date" class="form-control" name="birthdate" id="birthdate" onchange="calculateAge()" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>อายุ</label>
                            <input type="text" class="form-control" name="yearold" id="yearold" value='' readonly>
                        </div>
                        <div class="form-group col-md-6">
                            <label>เพศ</label>
                            <select class="form-control" name="gender" required>
                                <option value="male">ชาย</option>
                                <option value="female">หญิง</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label>เบอร์โทรศัพท์</label>
                            <input type="tel" class="form-control" name="phone" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>ที่อยู่</label>
                        <textarea class="form-control" name="address" rows="5" required></textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>รหัสไปรษณีย์</label>
                            <input type="text" class="form-control" name="postal_code" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>อีเมล</label>
                            <input type="text" class="form-control" name="email" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>โรคประจำตัว</label>
                            <input type="text" class="form-control" name="chronic_disease" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>ชื่อผู้ดูแล</label>
                            <input type="text" class="form-control" name="caretaker_name" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>เบอร์โทรผู้ดูแล</label>
                            <input type="tel" class="form-control" name="caretaker_phone" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>ประวัติการแพ้ยา</label>
                        <input type="tel" class="form-control" name="allergy">
                    </div>

                    <div class="form-group">
                        <label class="d-block">ประสงค์ให้แจ้งเตือนผ่านช่องทาง</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="select" id="Line" value="0" onclick="generateinputform(1)" required>
                            <label class="form-check-label" for="line">Line Notify</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="select" id="Tel" value="1" onclick="generateinputform(2)" required>
                            <label class="form-check-label" for="tel">Telegram</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="d-block">การแจ้งเตือน</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="alert" id="alert" name="alert" value="1" required>
                            <label class="form-check-label" for="alert">เสียงเตือน</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="alert" name="alert" value="2" required>
                            <label class="form-check-label" for="alert">เสียงพูด</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="alert" name="alert" value="3" required>
                            <label class="form-check-label" for="alert">ทั้งสองแบบ</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="d-block">ประสงค์เพิ่มฟังก์ชันอ่านออกเสียงข้อความ</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="alert_type" name="alert_type" value="1" required>
                            <label class="form-check-label" for="alert_type">ประสงค์(มีค่าบริการรายเดือน เดือนละ 210 บาท)</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="alert_type" name="alert_type" value="2" required>
                            <label class="form-check-label" for="alert_type">ไม่ประสงค์</label>
                        </div>
                    </div>

                    <div class="form-group" id="input-id">
                        <!-- generateinputform -->
                    </div>

                    <div class="form-group">
                        <!-- Label หลัก -->
                        <label class="form-label">บันทึกค่าชีพจร/ความดัน</label>

                        <!-- Checkbox 1 -->
                        <div class="form-check">
                            <input class="form-check-input" type="radio" value="1" name="pressure" id="pressure1" required>
                            <label for="pressure1" class="form-check-label">มี</label>
                        </div>

                        <!-- Checkbox 2 -->
                        <div class="form-check">
                            <input class="form-check-input" type="radio" value="0" name="pressure" id="pressure2" required>
                            <label for="pressure2" class="form-check-label">ไม่มี</label>
                        </div>
                    </div>




                </div>
            </div>

            <!-- จำนวนมื้อยาที่ทานต่อวัน -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">จำนวนมื้อยาที่ทานต่อวัน</div>
                <div class="card-body">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="meals_per_day" value="2" id="meal1" onchange="generateMedicineInputs(1)" required>
                        <label class="form-check-label" for="meal1">1 มื้อ</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="meals_per_day" value="2" id="meal2" onchange="generateMedicineInputs(2)">
                        <label class="form-check-label" for="meal2">2 มื้อ</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="meals_per_day" value="3" id="meal3" onchange="generateMedicineInputs(3)">
                        <label class="form-check-label" for="meal3">3 มื้อ</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="meals_per_day" value="4" id="meal4" onchange="generateMedicineInputs(4)">
                        <label class="form-check-label" for="meal4">4 มื้อ</label>
                    </div>
                </div>
            </div>

            <!-- ฟอร์มยาที่ทานในแต่ละมื้อ -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">ยาที่ทานในแต่ละมื้อ</div>
                <div class="card-body" id="medicineInputs">
                    <!-- ช่อง input สำหรับจำนวนยา, เวลาทานยา และ checkbox จะถูกสร้างที่นี่ -->
                </div>
            </div>

            <script>
                function generateMedicineInputs(meals) {
                    if (!Number.isInteger(meals) || meals <= 0) {
                        console.error(`Invalid meals input: ${meals}`);
                        return;
                    }

                    const container = document.getElementById('medicineInputs');
                    container.innerHTML = ''; // เคลียร์เนื้อหาเดิม

                    for (let i = 1; i <= meals; i++) {
                        const mealDiv = document.createElement('div');
                        mealDiv.className = 'form-group border p-3 mb-3';

                        // หัวข้อมื้อที่
                        const mealTitle = document.createElement('h5');
                        mealTitle.textContent = `มื้อที่ ${i}`;
                        mealDiv.appendChild(mealTitle);

                        // Input เวลาที่ทานยา
                        const timeInput = document.createElement('input');
                        timeInput.type = 'time';
                        timeInput.className = 'form-control mb-3';
                        timeInput.name = `medicine_time_meal${i}`;
                        mealDiv.appendChild(timeInput);

                        // Checkbox รายการยา
                        const medicines = [
                            "ยาลดความดันโลหิต", "ยารักษากระเพาะอาหาร", "ยาลดไขมันในเลือด", "ยารักษาโรคพาร์กินสัน",
                            "ยาควบคุมน้ำตาลในเลือด (เบาหวาน)", "ยาคลายเคลียด/ช่วยให้นอนหลับ", "ยาละลายลิ่มเลือด/ป้องกันการเกิดลิ่มเลือด",
                            "ยาลดการอักเสบ", "ยาโรคหัวใจ", "ยารักษาโรคกระดูกพรุน", "ยาแก้ปวด", "ยาฆ่าเชื้อ"
                        ];

                        const checkboxContainer = document.createElement('div');
                        checkboxContainer.className = 'row mt-3';

                        medicines.forEach((medicine, index) => {
                            const checkboxDiv = document.createElement('div');
                            checkboxDiv.className = 'col-md-4 mx-5';

                            const checkbox = document.createElement('input');
                            checkbox.type = 'checkbox';
                            checkbox.className = 'form-check-input';
                            checkbox.name = `medicine_list_meal${i}[]`;
                            checkbox.value = medicine;
                            checkbox.id = `meal${i}_medicine${index}`;

                            const label = document.createElement('label');
                            label.className = 'form-check-label';
                            label.setAttribute('for', `meal${i}_medicine${index}`);
                            label.textContent = medicine;
                            checkboxDiv.appendChild(checkbox);
                            checkboxDiv.appendChild(label);
                            checkboxContainer.appendChild(checkboxDiv);
                        });

                        mealDiv.appendChild(checkboxContainer);

                        // ส่วนอื่นๆ
                        const otherContainer = document.createElement('div');
                        otherContainer.className = 'mt-4';

                        const otherLabel = document.createElement('h5');
                        otherLabel.textContent = 'อื่นๆ';
                        otherContainer.appendChild(otherLabel);

                        const additionalInput = document.createElement('input');
                        additionalInput.type = 'text';
                        additionalInput.className = 'form-control mb-2';
                        additionalInput.name = `medicine_list_meal${i}[]`;
                        otherContainer.appendChild(additionalInput);

                        const otherInputWrapper = document.createElement('div');
                        otherInputWrapper.className = 'other-inputs';

                        const div = document.createElement("div");
                        div.className = "mb-3 d-flex align-items-center mt-3";

                        const addButton = document.createElement('button');
                        addButton.type = 'button';
                        addButton.className = 'btn btn-primary btn-sm mx-2';
                        addButton.textContent = 'เพิ่มช่อง';
                        addButton.addEventListener('click', () => {
                            const inputGroup = document.createElement('div');
                            inputGroup.className = 'input-group mb-2';

                            const additionalInput = document.createElement('input');
                            additionalInput.type = 'text';
                            additionalInput.className = 'form-control';
                            additionalInput.name = `medicine_list_meal${i}[]`;

                            const removeButton = document.createElement('button');
                            removeButton.type = 'button';
                            removeButton.className = 'btn btn-danger btn-sm';
                            removeButton.textContent = 'ลบ';
                            removeButton.addEventListener('click', () => {
                                if (otherInputWrapper.contains(inputGroup)) {
                                    otherInputWrapper.removeChild(inputGroup);
                                }
                            });

                            inputGroup.appendChild(additionalInput);
                            inputGroup.appendChild(removeButton);
                            otherInputWrapper.appendChild(inputGroup);
                        });

                        div.appendChild(addButton);
                        otherContainer.appendChild(otherInputWrapper);
                        otherContainer.appendChild(div);
                        mealDiv.appendChild(otherContainer);

                        container.appendChild(mealDiv);
                    }
                }

                function calculateAge() {
                    const dateInput = document.getElementById("birthdate").value;
                    if (!dateInput) {
                        document.getElementById("yearold").value = ''; // เคลียร์ค่าอายุหากไม่มีวันที่
                        return;
                    }

                    const today = new Date(); // วันที่ปัจจุบัน
                    const birthday = new Date(dateInput); // วันที่เกิดที่ผู้ใช้เลือก

                    // ตรวจสอบวันที่เกิดไม่ควรเป็นอนาคต
                    if (birthday > today) {
                        alert("วันที่เกิดไม่ควรเป็นวันที่ในอนาคต");
                        document.getElementById("yearold").value = '';
                        return;
                    }

                    // คำนวณอายุเบื้องต้น
                    let age = today.getFullYear() - birthday.getFullYear();

                    // ตรวจสอบวันและเดือนเพื่อปรับอายุให้ถูกต้อง
                    const currentMonth = today.getMonth();
                    const birthMonth = birthday.getMonth();
                    const currentDate = today.getDate();
                    const birthDate = birthday.getDate();

                    if (currentMonth < birthMonth || (currentMonth === birthMonth && currentDate < birthDate)) {
                        age--;
                    }

                    // แสดงผลอายุ
                    document.getElementById("yearold").value = age;
                }

                function generateinputform(p) {

                    const div = document.getElementById('input-id');
                    const qr_box = document.getElementById('boxgen-qrcode');

                    if (p === 1) {

                        div.innerHTML = '';
                        qr_box.innerHTML = '';

                        const label = document.createElement('label');
                        label.innerHTML = 'Line ID';

                        const input_line = document.createElement('input');
                        input_line.type = 'text';
                        input_line.className = 'form-control';
                        input_line.name = 'line_id';
                        input_line.id = 'line_id';
                        input_line.required = true;
                        div.appendChild(label);
                        div.appendChild(input_line);
                        // ------------------ฟอร์ม 2-----------------------
                        const border = document.createElement('div');
                        border.className = 'border p-5 bg-light';

                        const border_label = document.createElement('label');
                        border_label.innerHTML = 'QR Code LINE';
                        border_label.for = 'qrcodeMachineText';
                        border.appendChild(border_label);

                        const input_link = document.createElement('input');
                        input_link.type = 'text';
                        input_link.className = 'form-control';
                        input_link.name = 'qrcodeMachineText';
                        input_link.id = 'userInfoHelp';
                        border.appendChild(input_link);

                        const sm_qr = document.createElement('small');
                        sm_qr.innerHTML = 'ลิงค์การเชิญกลุ่ม LINE';
                        sm_qr.className = 'form-text text-muted';
                        sm_qr.id = 'userInfoHelp';
                        border.appendChild(sm_qr);
                        qr_box.appendChild(border);



                    } else if (p === 2) {

                        div.innerHTML = '';
                        qr_box.innerHTML = '';

                        const label = document.createElement('label');
                        label.innerHTML = 'Telegram ID';
                        div.appendChild(label);

                        const input_line = document.createElement('input');
                        input_line.type = 'text';
                        input_line.className = 'form-control';
                        input_line.name = 'tel-id';
                        input_line.required = true;
                        div.appendChild(input_line);

                        const label_key = document.createElement('label');
                        label_key.className = 'mt-2';
                        label_key.innerHTML = 'Telegram key';
                        div.appendChild(label_key);

                        const input_line_key = document.createElement('input');
                        input_line_key.type = 'text';
                        input_line_key.className = 'form-control';
                        input_line_key.name = 'tel-key';
                        input_line_key.required = true;

                        div.appendChild(input_line_key);

                        // ------------------ฟอร์ม 2-----------------------

                        const border = document.createElement('div');
                        border.className = 'border p-5 bg-light';


                        const link_label = document.createElement('label');
                        link_label.innerHTML = 'QR Code Telegram';
                        link_label.for = 'tel-id';
                        border.appendChild(link_label);

                        const input_link = document.createElement('input');
                        input_link.type = 'text';
                        input_link.className = 'form-control';
                        input_link.name = 'telText';
                        input_link.required = true;
                        border.appendChild(input_link);

                        const sm_qr = document.createElement('small');
                        sm_qr.innerHTML = 'ลิงค์การเชิญกลุ่ม Telegram';
                        sm_qr.className = 'form-text text-muted';
                        sm_qr.id = 'userInfoHelp';

                        border.appendChild(sm_qr);
                        qr_box.appendChild(border);
                    } else {
                        return;
                    }

                }
            </script>

            <div class="card mb-4">
                <div class="card-header bg-primary text-white">QR Code</div>
                <div class="card-body">
                    <div class="d-flex justify-content-center align-items-center">
                        <div class="col-md-6" id="boxgen-qrcode">

                            <!-- generateinputform -->

                        </div>
                    </div>
                </div>
            </div>

            <!-- ข้อมูลผู้ใช้งาน -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">ข้อมูลผู้ใช้งาน</div>
                <div class="card-body">
                    <div class="form-group">
                        <label>ผู้ให้ข้อมูล</label>
                        <input type="text" class="form-control" name="user_info" required>
                    </div>
                    <div class="form-group">
                        <label>เบอร์โทรศัพท์มือถือ</label>
                        <input type="tel" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>ชื่อผู้ใช้งาน</label>
                        <input type="text" class="form-control" name="user_login" required>
                        <small id="userNameHelp" class="form-text text-muted">สำหรับ การเข้าสู่ระบบ</small>
                    </div>
                    <div class="form-group">
                        <label>รหัสผ่าน</label>
                        <input type="password" class="form-control" name="password" required>
                        <small id="passwordHelp" class="form-text text-muted">
                            รหัสผ่านต้องประกอบด้วย: ความยาวอย่างน้อย 8 ตัวอักษร / ตัวอักษรพิมพ์เล็ก (abcd) / ตัวอักษรพิมพ์ใหญ่ (ABCD) / ตัวเลข (1234)
                        </small>
                    </div>
                </div>
            </div>

            <!-- ปุ่มบันทึก -->
            <div class="text-center">
                <button type="submit" class="btn btn-primary mb-4">บันทึกข้อมูล</button>
            </div>
        </form>
    </div>

    <!-- Bootstrap 4 JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $("#englishonly1").keypress(function(event) {
            var ew = event.which;
            if (ew == 32)
                return true;
            if (48 <= ew && ew <= 57)
                return true;
            if (65 <= ew && ew <= 90)
                return true;
            if (97 <= ew && ew <= 122)
                return true;
            return false;
        });
        $("#englishonly2").keypress(function(event) {
            var ew = event.which;
            if (ew == 32)
                return true;
            if (48 <= ew && ew <= 57)
                return true;
            if (65 <= ew && ew <= 90)
                return true;
            if (97 <= ew && ew <= 122)
                return true;
            return false;
        });
    </script>
</body>

</html>