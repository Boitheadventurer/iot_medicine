<?php

include 'php/chk_id.php';
include 'php/navbar.php';

// ดึงข้อมูล startDate และ endDate จากฐานข้อมูล
$sql = "SELECT startDate, endDate FROM tb_device WHERE id = '$id'"; // ดึงข้อมูลแค่แถวเดียว
$result = $conn->query($sql);

$startDate = '';
$endDate = '';

if ($result->num_rows > 0) {
    // ดึงค่าจากฐานข้อมูล
    $row = $result->fetch_assoc();
    $startDate = $row['startDate'];
    $endDate = $row['endDate'];
} else {
    echo "<script>alert('ไม่พบข้อมูล startDate หรือ endDate');</script>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<script>
    alert('บันทึกการตั้งเวลาจ่ายยาสำเร็จ ขณะนี้เครื่องสามารถดำเนินการจ่ายยาได้ตามเวลาที่กำหนด!');
    window.location.href = 'home.php';
    </script>";
}
?>



<!doctype html>
<html lang="en">

<head>
    <title>เวลาจ่ายยา</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        body {
            background-color: #e0e0e0;
        }

        * {
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: white;
            max-width: 1200px;
            width: 90%;
        }

        .ggtable {
            min-width: 450px;
        }

        @media (max-width: 768px) {
            .container {
                max-width: 100%;
                /* ใช้ความกว้างเต็มหน้าจอมือถือ */
                padding: 10px;
            }

            .row {
                display: block;
                /* เปลี่ยนการจัดเรียงจากแนวนอนเป็นแนวตั้ง */
            }

            .col-md-5,
            .col-md-2 {
                width: 100%;
                /* ใช้ความกว้างเต็มหน้าจอ */
                margin-bottom: 15px;
                /* เพิ่มช่องว่างระหว่างส่วน */
            }

            .col-md-2.text-center {
                display: none;
                /* ซ่อนคำว่า "ถึง" สำหรับมือถือ */
            }

            table {
                font-size: 14px;
                /* ลดขนาดตัวอักษร */
            }

            table th,
            table td {
                padding: 8px;
                /* ลด padding ในเซลล์ */
            }

            input[type="text"] {
                width: 90%;
                /* ลดขนาด input field */
                margin: auto;
                /* จัดให้อยู่กึ่งกลาง */
            }

            #saveButton {
                width: 90%;
                /* ปุ่มบันทึกเต็มความกว้าง */
                font-size: 16px;
                /* ขนาดตัวอักษรใหญ่ขึ้น */
            }

            /* กำหนดให้ตารางสามารถเลื่อนข้างได้ */
            .table-responsive-scroll {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                /* สำหรับมือถือ */
            }

            .table {
                min-width: 800px;
                /* กำหนดความกว้างขั้นต่ำ */
            }

            /* ปรับขนาดตัวอักษรในตารางสำหรับมือถือ */
            @media (max-width: 768px) {

                .table th,
                .table td {
                    font-size: 14px;
                    /* ลดขนาดตัวอักษร */
                }
            }

        }
    </style>
</head>

<body>


    <!-- ฟอร์มแสดงข้อมูลและการแก้ไข -->
    <div class="container my-5 shadow p-4 rounded">
        <h2 class="text-center mb-4">สรุปข้อมูลการตั้งค่าจ่ายยา</h2>
        <form method="POST" action="#">
            <div class="row">
                <div class="col-md-5 mb-3">
                    <label for="startDate" class="form-label text-success">วันที่เริ่ม</label>
                    <input id="startDate" name="start_date" type="date" class="form-control" value="<?php echo date('Y-m-d', strtotime($startDate)); ?>" readonly>
                </div>
                <div class="col-md-2 text-center align-self-center mb-3">
                    <label class="form-label text-success">ถึง</label>
                </div>
                <div class="col-md-5 mb-3">
                    <label for="endDate" class="form-label text-success">วันสุดท้าย</label>
                    <input id="endDate" name="end_date" type="date" class="form-control" value="<?php echo date('Y-m-d', strtotime($endDate)); ?>" readonly>
                </div>
            </div>

            <?php
            function getMedicineNames($conn, $table, $id, $medicineAliases)
            {
                // กำหนด SQL Query
                $sql = "
                                    SELECT 
                                        m1.medicine_name AS {$medicineAliases[0]},
                                        m2.medicine_name AS {$medicineAliases[1]},
                                        m3.medicine_name AS {$medicineAliases[2]},
                                        m4.medicine_name AS {$medicineAliases[3]}
                                    FROM $table AS t
                                    LEFT JOIN tb_medicine AS m1 ON t.medicine_id = m1.medicine_id
                                    LEFT JOIN tb_medicine AS m2 ON t.medicine_id2 = m2.medicine_id
                                    LEFT JOIN tb_medicine AS m3 ON t.medicine_id3 = m3.medicine_id
                                    LEFT JOIN tb_medicine AS m4 ON t.medicine_id4 = m4.medicine_id
                                    WHERE t.id = '$id'
                                ";

                // ส่งคำสั่ง Query
                $result = $conn->query($sql);

                // กำหนดค่าเริ่มต้นเป็นค่าว่าง
                $medicineNames = array_fill_keys($medicineAliases, '');

                if ($result && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();

                    // อัปเดตข้อมูลที่พบ
                    foreach ($medicineAliases as $alias) {
                        $medicineNames[$alias] = $row[$alias] ?? '';
                    }
                }

                return $medicineNames;
            }

            // ดึงข้อมูลจากแต่ละตาราง
            $medicineNames1 = getMedicineNames($conn, 'tb_data_bf', $id, ['medicine_name1', 'medicine_name2', 'medicine_name3', 'medicine_name4']);
            $medicineNames2 = getMedicineNames($conn, 'tb_data_lunch', $id, ['medicine_name5', 'medicine_name6', 'medicine_name7', 'medicine_name8']);
            $medicineNames3 = getMedicineNames($conn, 'tb_data_dn', $id, ['medicine_name9', 'medicine_name10', 'medicine_name11', 'medicine_name12']);
            $medicineNames4 = getMedicineNames($conn, 'tb_data_bb', $id, ['medicine_name13', 'medicine_name14', 'medicine_name15', 'medicine_name16']);

            // รวมข้อมูลทั้งหมด
            $allMedicineNames = array_merge($medicineNames1, $medicineNames2, $medicineNames3, $medicineNames4);



            // ฟังก์ชันในการดึงข้อมูลและคืนค่าถ้าไม่มีข้อมูล
            function getTime($conn, $sql)
            {
                $result = $conn->query($sql);
                if ($result && $row = $result->fetch_assoc()) {
                    return reset($row);
                } else {
                    return ""; // คืนค่าว่างถ้าไม่มีข้อมูล
                }
            }

            $sql_bf = "SELECT time_bf FROM tb_data_bf WHERE id = '$id'";
            $time_1 = getTime($conn, $sql_bf);

            $sql_lunch = "SELECT time_lunch FROM tb_data_lunch WHERE id = '$id'";
            $time_2 = getTime($conn, $sql_lunch);

            $sql_dn = "SELECT time_dn FROM tb_data_dn WHERE id = '$id'";
            $time_3 = getTime($conn, $sql_dn);

            $sql_bb = "SELECT time_bb FROM tb_data_bb WHERE id = '$id'";
            $time_4 = getTime($conn, $sql_bb);

            // เก็บข้อมูลไว้ในรูปแบบ array
            $time_array = array(
                "time_bf" => $time_1,
                "time_lunch" => $time_2,
                "time_dn" => $time_3,
                "time_bb" => $time_4
            );
            3
            ?>
            <!-- ตารางข้อมูล -->
            <div class="table-responsive-scroll">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="width: 10%;">มื้อ</th>
                            <th style="width: 13%;">เวลา</th>
                            <th colspan="5">ชื่อยาที่รับประทาน</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>เช้า</td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $time_array["time_bf"]; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames["medicine_name1"]; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames["medicine_name2"]; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames["medicine_name3"]; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames["medicine_name4"]; ?>' readonly></td>
                        </tr>
                        <tr>
                            <td>กลางวัน</td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo  $time_array["time_lunch"]; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name5']; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name6']; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name7']; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name8']; ?>' readonly></td>
                        </tr>
                        <tr>
                            <td>เย็น</td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo  $time_array["time_dn"]; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name9']; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name10']; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name11']; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name12']; ?>' readonly></td>
                        </tr>

                        <tr>

                            <td>ก่อนนอน</td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $time_array["time_bb"]; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name13']; ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name14'] ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name15'] ?>' readonly></td>
                            <td><input type="text" id="time_bf" class="form-control" value='<?php echo $allMedicineNames['medicine_name16'] ?>' readonly></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- ปุ่มบันทึก -->
            <div class="text-center mt-3">
                <button class="btn btn-primary" type="submit">ยืนยันการตั้งเวลาจ่ายยา</button>
            </div>
        </form>
    </div>




    </form>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>