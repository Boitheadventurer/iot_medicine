<?php
include 'php/chk_id.php';
include 'php/navbar.php';



// ดึงข้อมูล meal_count จากฐานข้อมูล
$sql = "SELECT meal_count FROM tb_device WHERE id = '$id'";  // ใช้ LIMIT 1 ถ้าคุณต้องการเพียงค่าเดียว
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $mealCount = $row['meal_count'];
}

// คำนวณ 28 / meal_count
$calculatedDays = round(28 / $mealCount);

if (isset($_POST['submit'])) {
    // รับ   
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];



    // ตรวจสอบว่าข้อมูลไม่ว่างเปล่า
    if (!empty($startDate) && !empty($endDate)) {

        $sql = "UPDATE tb_device SET startDate = '$startDate', endDate = '$endDate' WHERE id = '$id'";
        $stmt = $conn->query($sql);
        if ($stmt) {
            if ($stmt) {
                echo ' <script>
                                alert("ยืนยันวันที่เริ่มต้นจ่ายยา สำเร็จ!");
                                window.location = "time_Medicine_dispensing.php";
                            </script>';
            } else {
                echo "<script>alert('ไม่สามารถเพิ่มข้อมูลได้'); </script>";
            }
        }
    } else {
        echo "<script>alert('กรุณากรอกข้อมูลให้ครบถ้วน!'); </script>";
    }
}

// ปิดการเชื่อมต่อฐานข้อมูล
$conn->close();
?>

<!doctype html>
<html lang="en">

<head>
    <title>จำนวนการจ่ายยา</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');

        body {
            background-color: #e0e0e0;
            margin: 0;
            padding: 0;
            font-family: "Bai Jamjuree", sans-serif;
        }

        .container {
            background-color: white;
            max-width: 800px;
            width: 90%;
            padding: 20px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .ggtable {
            min-width: 450px;
        }

        h2 {
            font-size: 1.5rem;
            text-align: center;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 10px;
            font-size: 1rem;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }

            .ggtable {
                min-width: 100%;
            }

            h2 {
                font-size: 1.2rem;
            }

            .form-label {
                font-size: 0.9rem;
            }

            .form-control {
                width: 100%;
                font-size: 1rem;
            }

            #daysAfter {
                width: 60px;
            }

            .btn {
                font-size: 1rem;
                padding: 12px;
            }

            .mb-3 {
                margin-bottom: 15px;
            }

            .form-control,
            #startDate,
            #endDate {
                font-size: 1rem;
            }

            /* ทำให้ช่อง input แสดงในแนวตั้ง */
            .input-group {
                display: block;
            }

            /* ให้ช่อง input ใหญ่ขึ้นในมือถือ */
            input[type="text"],
            input[type="date"] {
                width: 100%;
                padding: 10px;
                font-size: 1rem;
                margin: 10px 0;
                border: 1px solid #ddd;
                border-radius: 4px;
            }

            .d-flex {
                display: flex;
                flex-direction: column;
                /* จัดองค์ประกอบในแนวตั้ง */
                justify-content: center;
                /* จัดกลางในแนวนอน */
                align-items: center;
                /* จัดกลางในแนวตั้ง */
            }

            .text-center h2 {
                text-align: center;
            }

        }
    </style>
</head>

<body>


    <!-- ฟอร์มแสดงข้อมูลและการแก้ไข -->
    <div class="container my-5 shadow p-4 rounded">
        <div class="text-center d-flex justify-content-center align-items-center flex-column">
            <h2>กำหนดวันที่เริ่มจ่ายยา</h2>
            <div class="my-2">
                <input type="text" id="daysAfter" name="days_after" class="form-control" placeholder="จำนวนวัน" value="<?php echo $calculatedDays; ?>" readonly>
            </div>
        </div>


        <form method="POST" action="">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="startDate" class="form-label text-success">กำหนดวันที่ที่เริ่มจ่าย</label><br>
                    <input id="startDate" name="start_date" type="date" class="form-control" style="width: 100%;" onchange="calculateEndDate()">
                </div>

                <div class="col-md-6 mb-3">
                    <label for="endDate" class="form-label text-success">จ่ายถึงวันที่</label><br>
                    <input id="endDate" name="end_date" type="date" class="form-control" style="width: 100%;" readonly>
                </div>
            </div>

            <div class="mt-3 text-center">
                <button id="saveButton" class="btn btn-primary" type="submit" name="submit">ยืนยันกำหนดวันที่จ่ายยา</button>
            </div>
        </form>
    </div>


    <script>
        function calculateEndDate() {
            const startDateInput = document.getElementById('startDate');
            const daysAfterInput = document.getElementById('daysAfter');
            const endDateInput = document.getElementById('endDate');

            const startDateValue = startDateInput.value;
            const daysAfterValue = parseInt(daysAfterInput.value, 10);

            if (startDateValue && !isNaN(daysAfterValue)) {
                const startDate = new Date(startDateValue);
                startDate.setDate(startDate.getDate() + (daysAfterValue - 1)); // เพิ่มวันตามสูตร
                const endDate = startDate.toISOString().split('T')[0]; // แปลงเป็นรูปแบบ YYYY-MM-DD
                endDateInput.value = endDate;
            } else {
                endDateInput.value = ''; // เคลียร์ค่าในกรณีข้อมูลไม่ครบ
            }
        }
    </script>

    </form>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>