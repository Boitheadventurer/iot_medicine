<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เครื่องจ่ายยาอัตโนมัติ</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Remix Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.min.css">
    <!-- Icon Title -->
    <link rel="icon" type="image/x-icon" href="https://icon-library.com/images/medic-icon/medic-icon-28.jpg">
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;600&display=swap');

    /* General Styling */
    body {
        font-family: "Bai Jamjuree", sans-serif;
        margin: 0;
        padding: 0;
        background-color:rgb(229, 229, 229);
        color: #000;
    }

    .document-container {
        width: 210mm;
        height: 100%;
        margin: auto;
        background: #fff;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        padding: 30px;
        box-sizing: border-box;
    }



    hr {
        border: none;
        height: 2px;
        background-color: #000;
    }

    /* Header Section */
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .header img {
        width: 100px;
        margin-right: 10px;
    }

    .header-title {
        font-size: 20px;
        font-weight: 600;
    }

    .date-section {
        text-align: right;
        font-size: 14px;
    }

    /* Patient Info Section */
    .section-title {
        font-size: 18px;
        font-weight: 600;
        margin: 10px 0;
    }

    .info-row {
        display: flex;
        justify-content: space-between;
        margin: 5px 0;
        font-size: 16px;
    }

    .info-row p {
        margin: 5px 0;
    }

    .info-group {
        width: 48%;
    }

    /* Footer */
    .footer {
        margin-top: 20px;
        font-size: 14px;
        text-align: center;
    }

    .container {
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        background-color: white;
        padding: 5px;
    }

    .qrcode-box {
        width: 150px;
        height: 150px;
        border: 1px solid #000;จำนวนมื้อที่ทานยาต่อวัน
        margin-bottom: 5px;
    }

    .qrcode-label {
        text-align: center;
        font-size: 14px;
    }

    .info-section {
        font-size: 16px;
        margin-left: 20px;
    }

    .info-section p {
        margin: 10px 0;
    }

    .info-section span {
        font-weight: bold;
    }

    .dotted-line {
        display: inline-block;
        border-bottom: 1px dotted #000;
        width: 250px;
    }

    .qr-image {
        width: 150px;
        height: 150px;
    }

    @media print {
        /* @page {
                size: A4; 
                margin: 10mm; 
            } */

        .document-container {
            width: 100%;
            height: 99vh;
        }

        .info-section {

            margin-right: 250px;
        }
    }
    </style>
</head>

<body>
    <?php
            include 'php/chk_id.php';   
            include 'php/navbar.php';
            $count = 0;
        ?>
    <?php
        // $data = [];
        // $sql = "SELECT device_id, medicine_name FROM tb_device
        // INNER JOIN tb_medicine ON tb_medicine.id = tb_device.device_id
        // WHERE tb_device.id = '$id'";
        // $result = $conn->query($sql);
        // if($result->num_rows > 0){
        // while($row = $result->fetch_assoc()){
        //     $data[] = $row;
        // }   
        // }

        $sql = "SELECT tb_data_bf.*,tb_medicine.* 
        FROM tb_data_bf  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id
        WHERE tb_data_bf.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            // echo  $row["medicine_name"];
          }
        }
        $sql = "SELECT tb_data_bf.*,tb_medicine.* 
        FROM tb_data_bf  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id2
        WHERE tb_data_bf.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            // echo  $row["medicine_name"];
          }
        }
        $sql = "SELECT tb_data_bf.*,tb_medicine.* 
        FROM tb_data_bf  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id3
        WHERE tb_data_bf.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            // echo  $row["medicine_name"];
          }
        }
        $sql = "SELECT tb_data_bf.*,tb_medicine.* 
        FROM tb_data_bf  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id4
        WHERE tb_data_bf.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            // echo  $row["medicine_name"];
          }
        }
    ?>
    <?php
        $sql = "SELECT 
        tb_device.*, 
        user.*, 
        tb_data_bf.*, 
        tb_data_lunch.*, 
        tb_data_dn.*, 
        tb_data_bb.*, 
        tb_medicine.*, 
        DATE_FORMAT(user.dob, '%d/%m/%Y') AS formatted_dob 
        FROM tb_device 
        INNER JOIN user ON user.id = tb_device.id
        INNER JOIN tb_data_bf ON tb_data_bf.id = user.id
        INNER JOIN tb_data_lunch ON tb_data_lunch.id = user.id
        INNER JOIN tb_data_dn ON tb_data_dn.id = user.id
        INNER JOIN tb_data_bb ON tb_data_bb.id = user.id
        INNER JOIN tb_medicine ON tb_medicine.id = user.id
        WHERE tb_device.id = '$id'";
        $result = $conn->query($sql);   
        $row2 = $result->fetch_assoc();
        
    ?>

    <?php
        $sql = "SELECT 
        tb_device.*, 
        user.*, 

        DATE_FORMAT(user.dob, '%d/%m/%Y') AS formatted_dob 
        FROM tb_device 
        INNER JOIN user ON user.id = tb_device.id

        WHERE tb_device.id = '$id'";
        $result = $conn->query($sql);   
        $row1 = $result->fetch_assoc();
        
    ?>
    <!-- เอกสาร -->
    <div class="document-container">
        <!-- Header -->
        <div class="header">
            <div style="display: flex; align-items: center;">
                <img src="./image/AI.png" alt="Logo">
                <div class="header-title">
                    เครื่องจ่ายยาสำหรับผู้สูงอายุ
                </div>
            </div>

            <div class="date-section">
                <p>เขียนที่ : …………………………………</p>
                <p>วันที่ : …………………………………</p>
            </div>
        </div>

        <hr>

        <!-- Patient Info -->
        <div class="section-title">ข้อมูลผู้ป่วย</div>

        <div class="info-row">
            <div class="info-group">
                <p>ชื่อจริง: <?php echo $row1['firstname_th']; ?></p>
            </div>
            <div class="info-group">
                <p>นามสกุล: <?php echo $row1['lastname_th']; ?></p>
            </div>
        </div>

        <div class="info-row">
            <div class="info-group">
                <p>วัน/เดือน/ปีเกิด: <?php echo $row1['formatted_dob']; ?></p>
            </div>
            <div class="info-group">
                <p>เพศ:
                    <?php echo ($row1['gender'] == 'male') ? 'ชาย' : 'หญิง'; ?>
                </p>
            </div>
        </div>

        <div class="info-row">
            <div class="info-group">
                <p>บ้านเลขที่: <?php echo $row1['address']; ?></p>
            </div>
            <div class="info-group">
                <p>โรคประจำตัว: <?php echo $row1['chronic_disease']; ?></p>
            </div>
        </div>


        <!-- <div class="info-row">
            <div class="info-group">
                <p>ตำบล: <?php echo $row1['district']; ?></p>
            </div>
            <div class="info-group">
                <p>อำเภอ: <?php echo $row1['canton']; ?></p>
            </div>
            <div class="info-group">
                <p>จังหวัด: <?php echo $row1['province']; ?></p>
            </div>
            <div class="info-group">
                <p>รหัสไปรษณีย์: <?php echo $row1['postal_code']; ?></p>
            </div>
        </div> --> 
        <div class="section-title">ข้อมูลผู้ดูแล</div>
        <div class="info-row">
            <div class="info-group">
                <p>ชื่อผู้ดูแล: <?php echo $row1['caretaker_name']; ?></p>
            </div>
            <div class="info-group">
                <p>เบอร์โทร: <?php echo $row1['caretaker_phone']; ?></p>
            </div>
        </div>
        <div class="info-row">
            <div class="info-group">
                <p>ความเกี่ยวข้อง: <?php echo $row1['relevant']; ?></p>
            </div>
            <div class="info-group">
                <p> Line ID: <?php echo $row1['line_id']; ?></p>
            </div>
        </div>

      
        <hr>
        <?php
    $sql = "SELECT * FROM `tb_device` WHERE id ='$id'";
    $result = mysqli_query($conn, $sql);
    $row3 = mysqli_fetch_assoc($result);
     //$count = 0; for($counts = 0; $counts < $row['meal_count']; $counts++){?>
        
        <div style="display:flex; gap:30px;   align-items: center;">
<div hidden class="section-title">จำนวนมื้อที่ทานยาต่อวัน <?php echo $row3['meal_count'];?> มื้อ</div>
</div>

<div class="section-title">ยาที่ทานในแต่ละมื้อ</div>
<!-- <?php //foreach ($row as $rows): ?> -->
<?php
    $sql = "SELECT * FROM `tb_data_bf` WHERE id ='$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
     if(mysqli_num_rows($result) > 0){ //$count = 0; for($counts = 0; $counts < $row['meal_count']; $counts++){?>
<div class="info-row  d-flex ml-5">
            <div class="info-group ">
                <p>มื้อที่ <?php ++$count ; echo $count ?> </p>
            </div>
            <div class="info-group ">
                <!-- <p>จำนวนยาที่ทาน <?php //echo $row1['all_count']; ?> </p> -->
            </div>
            <div class="info-group ">
            <?php
                $time_bf = $row['time_bf']; // เช่น '08:00:00'
                $date = new DateTime($time_bf);
                $formatted_time = $date->format('H:i') . " น.";
                ?>

                <p>เวลาที่ทานยา <?php echo $formatted_time; ?> </p>
            </div>
        </div>
        <div class="section-title ml-5">ยาที่ต้องรับประทาน</div>
        <div class="info-row ml-5">
            <div class="info-group "> 
            <?php $sql = "SELECT tb_data_bf.*,tb_medicine.* 
        FROM tb_data_bf  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id
        WHERE tb_data_bf.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_bf.*,tb_medicine.* 
        FROM tb_data_bf  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id2
        WHERE tb_data_bf.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_bf.*,tb_medicine.* 
        FROM tb_data_bf  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id3
        WHERE tb_data_bf.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_bf.*,tb_medicine.* 
        FROM tb_data_bf  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bf.medicine_id4
        WHERE tb_data_bf.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        } ?>
            </div>
        </div>

        <hr>

        <?php } ?>
        <!-- <?php //endforeach ?> -->
        <?php
    $sql = "SELECT * FROM `tb_data_lunch` WHERE id ='$id'";
    $result = mysqli_query($conn, $sql);
    
     if(mysqli_num_rows($result) > 0){ //$count = 0; for($counts = 0; $counts < $row['meal_count']; $counts++){
        $row = mysqli_fetch_assoc($result)?>
<div class="info-row  d-flex ml-5">
            <div class="info-group ">
                <p>มื้อที่ <?php ++$count; echo $count ?> </p>
            </div>
            <div class="info-group ">
                <!-- <p>จำนวนยาที่ทาน <?php //echo $row1['all_count']; ?> </p> -->
            </div>
            <div class="info-group ">
            <?php
                $time_bf = $row['time_lunch']; // เช่น '08:00:00'
                $date = new DateTime($time_bf);
                $formatted_time = $date->format('H:i') . " น.";
                ?>

                <p>เวลาที่ทานยา <?php echo $formatted_time; ?> </p>
            </div>
        </div>
        <div class="section-title ml-5">ยาที่ต้องรับประทาน</div>
        <div class="info-row ml-5">
            <div class="info-group "> 
            <?php $sql = "SELECT tb_data_lunch.*,tb_medicine.* 
        FROM tb_data_lunch  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_lunch.medicine_id
        WHERE tb_data_lunch.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_lunch.*,tb_medicine.* 
        FROM tb_data_lunch  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_lunch.medicine_id2
        WHERE tb_data_lunch.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_lunch.*,tb_medicine.* 
        FROM tb_data_lunch  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_lunch.medicine_id3
        WHERE tb_data_lunch.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_lunch.*,tb_medicine.* 
        FROM tb_data_lunch  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_lunch.medicine_id4
        WHERE tb_data_lunch.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        } ?>
            </div>
        </div>

        <?php } ?>

        <!-- มื้อที่3 -->  <hr>
       
<?php
    $sql = "SELECT * FROM `tb_data_dn` WHERE id ='$id'";
    $result = mysqli_query($conn, $sql);
    
     if(mysqli_num_rows($result) > 0){ //$count = 0; for($counts = 0; $counts < $row['meal_count']; $counts++){
        $row = mysqli_fetch_assoc($result)?>
<div class="info-row  d-flex ml-5">
            <div class="info-group ">
                <p>มื้อที่ <?php ++$count ; echo $count ?> </p>
            </div>
            <div class="info-group ">
                <!-- <p>จำนวนยาที่ทาน <?php //echo $row1['all_count']; ?> </p> -->
            </div>
            <div class="info-group ">
            <?php
                $time_bf = $row['time_dn']; // เช่น '08:00:00'
                $date = new DateTime($time_bf);
                $formatted_time = $date->format('H:i') . " น.";
                ?>
                <p>เวลาที่ทานยา <?php echo $formatted_time; ?> </p>
            </div>
        </div>
        <div class="section-title ml-5">ยาที่ต้องรับประทาน</div>
        <div class="info-row ml-5">
            <div class="info-group "> 
            <?php $sql = "SELECT tb_data_dn.*,tb_medicine.* 
        FROM tb_data_dn  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_dn.medicine_id
        WHERE tb_data_dn.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_dn.*,tb_medicine.* 
        FROM tb_data_dn  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_dn.medicine_id2
        WHERE tb_data_dn.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_dn.*,tb_medicine.* 
        FROM tb_data_dn  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_dn.medicine_id3
        WHERE tb_data_dn.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_dn.*,tb_medicine.* 
        FROM tb_data_dn  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_dn.medicine_id4
        WHERE tb_data_dn.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        } ?>
            </div>
        </div>

        <?php } ?>


        <!-- มื้อที่4 -->  <hr>
         
<?php
    $sql = "SELECT * FROM `tb_data_bb` WHERE id ='$id'";
    $result = mysqli_query($conn, $sql);
    
     if(mysqli_num_rows($result) > 0){ //$count = 0; for($counts = 0; $counts < $row['meal_count']; $counts++){
        $row = mysqli_fetch_assoc($result)?>
<div class="info-row  d-flex ml-5">
            <div class="info-group ">
                <p>มื้อที่ <?php ++$count ; echo $count ?> </p>
            </div>
            <div class="info-group ">
                <!-- <p>จำนวนยาที่ทาน <?php //echo $row1['all_count']; ?> </p> -->
            </div>
            <div class="info-group ">
            <?php
                $time_bf = $row['time_bb']; // เช่น '08:00:00'
                $date = new DateTime($time_bf);
                $formatted_time = $date->format('H:i') . " น.";
                ?>

                <p>เวลาที่ทานยา <?php echo $formatted_time; ?> </p>
            </div>
        </div>
        <div class="section-title ml-5">ยาที่ต้องรับประทาน</div>
        <div class="info-row ml-5">
            <div class="info-group "> 
            <?php $sql = "SELECT tb_data_bb.*,tb_medicine.* 
        FROM tb_data_bb  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bb.medicine_id
        WHERE tb_data_bb.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_bb.*,tb_medicine.* 
        FROM tb_data_bb  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bb.medicine_id2
        WHERE tb_data_bb.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_bb.*,tb_medicine.* 
        FROM tb_data_bb  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bb.medicine_id3
        WHERE tb_data_bb.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"] . "<br>";
          }
        }
        $sql = "SELECT tb_data_bb.*,tb_medicine.* 
        FROM tb_data_bb  
        INNER JOIN tb_medicine ON tb_medicine.medicine_id = tb_data_bb.medicine_id4
        WHERE tb_data_bb.id ='$id'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo  $row["medicine_name"];
          }
        } ?>
            </div>
        </div>

        <?php } ?>

        <hr>
        
        <div style="justify-content: space-between; display:flex;">
        <div class="container">
    <div style="display:flex; gap:30px; ;">
        <div >
            <div class="qrcode-box" style=" display: flex; ">

            <?php
        include('phpqrcode/qrlib.php'); 
        $file_name = "qrcode.png";
        $content =  $row1['url1'];
        QRcode::png($content, $file_name, QR_ECLEVEL_L, 10);
        echo "<img src='{$file_name}'>";
        ?>
            </div>
            <div class="qrcode-label">QRCode Line</div>
        </div>
        <div>
            <div class="qrcode-box" style=" display: flex; ">  <?php
        // include('phpqrcode/qrlib.php'); 
        $file_names = "qrcode1.png";
        $content =  "http://medic.ctnphrae.com/login.php";
        QRcode::png($content, $file_names, QR_ECLEVEL_L, 10);
        echo "<img src='{$file_names}'>";
        ?></div>
            <div class="qrcode-label">QRCode เครื่องจ่ายยา</div>
        </div>
    </div>
    <div style="margin-right:-5px;" class="info-section">
        <p><span>ผู้ให้ข้อมูล</span> : <span class="dotted-line"></span></p>
        <p><span>เบอร์โทร</span> : <span class="dotted-line"></span></p>
        <p><span>รหัสผ่าน</span> : <span class="dotted-line"></span></p>
    </div>
</div>
    
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
            integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
        </script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
            integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
        </script>
        <script>

        </script>
</body>

</html>